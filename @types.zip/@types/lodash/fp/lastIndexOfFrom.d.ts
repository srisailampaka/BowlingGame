import { lastIndexOfFrom } from "../fp";
export = lastIndexOfFrom;
