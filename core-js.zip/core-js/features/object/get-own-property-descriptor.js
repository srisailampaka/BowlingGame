module.exports = require('../../es/object/get-own-property-descriptor');
