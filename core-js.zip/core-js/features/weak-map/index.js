module.exports = require('../../es/weak-map');

require('../../modules/esnext.weak-map.from');
require('../../modules/esnext.weak-map.of');
require('../../modules/esnext.weak-map.delete-all');
