module.exports = require('../../es/symbol/replace');
