module.exports = require('../../es/math/tanh');
