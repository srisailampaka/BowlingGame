module.exports = require('../../es/number');

require('../../modules/esnext.number.from-string');
