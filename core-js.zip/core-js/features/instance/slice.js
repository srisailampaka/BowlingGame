module.exports = require('../../es/instance/slice');
