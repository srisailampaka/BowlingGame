import { isArray } from "../fp";
export = isArray;
