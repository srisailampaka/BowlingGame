require('../../modules/es.typed-array.for-each');
