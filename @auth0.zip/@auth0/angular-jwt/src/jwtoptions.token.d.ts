import { InjectionToken } from '@angular/core';
export declare const JWT_OPTIONS: InjectionToken<{}>;
