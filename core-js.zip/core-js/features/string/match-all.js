// TODO: remove from `core-js@4`
require('../../modules/esnext.string.match-all');

module.exports = require('../../es/string/match-all');
