module.exports = require('../../es/number/is-finite');
