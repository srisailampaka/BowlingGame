module.exports = require('../../stable/dom-collections/for-each');
