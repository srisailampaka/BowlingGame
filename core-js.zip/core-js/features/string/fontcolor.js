module.exports = require('../../es/string/fontcolor');
