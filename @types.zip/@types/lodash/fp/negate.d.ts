import { negate } from "../fp";
export = negate;
