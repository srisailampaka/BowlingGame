module.exports = require('../../es/number/constructor');
