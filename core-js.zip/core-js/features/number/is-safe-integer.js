module.exports = require('../../es/number/is-safe-integer');
