import { isArrayLikeObject } from "../fp";
export = isArrayLikeObject;
