module.exports = require('../es/parse-int');
