module.exports = require('../stable/queue-microtask');
