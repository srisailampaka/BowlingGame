export { RestangularModule } from './ngx-restangular.module';
export { Restangular } from './ngx-restangular';
export { RestangularHttp } from './ngx-restangular-http';
