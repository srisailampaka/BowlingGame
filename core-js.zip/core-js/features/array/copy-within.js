module.exports = require('../../es/array/copy-within');
