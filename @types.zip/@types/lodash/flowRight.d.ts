import { flowRight } from "./index";
export = flowRight;
