import { minBy } from "../fp";
export = minBy;
