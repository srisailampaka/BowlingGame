module.exports = require('../../es/regexp/flags');
