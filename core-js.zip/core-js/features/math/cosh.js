module.exports = require('../../es/math/cosh');
