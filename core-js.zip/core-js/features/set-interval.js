module.exports = require('../stable/set-interval');
