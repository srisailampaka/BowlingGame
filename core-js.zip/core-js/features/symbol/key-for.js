module.exports = require('../../es/symbol/key-for');
