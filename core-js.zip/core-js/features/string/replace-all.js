require('../../modules/esnext.string.replace-all');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'replaceAll');
