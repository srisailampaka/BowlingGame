module.exports = require('../../es/math/imul');
