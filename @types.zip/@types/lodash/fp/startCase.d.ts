import { startCase } from "../fp";
export = startCase;
