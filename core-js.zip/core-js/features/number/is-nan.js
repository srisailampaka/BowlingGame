module.exports = require('../../es/number/is-nan');
