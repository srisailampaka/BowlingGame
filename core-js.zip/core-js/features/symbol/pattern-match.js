require('../../modules/esnext.symbol.pattern-match');
var WrappedWellKnownSymbolModule = require('../../internals/wrapped-well-known-symbol');

module.exports = WrappedWellKnownSymbolModule.f('patternMatch');
