module.exports = require('../../es/math/cbrt');
