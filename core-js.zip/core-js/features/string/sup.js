module.exports = require('../../es/string/sup');
