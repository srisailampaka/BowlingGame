require('../../modules/es.typed-array.index-of');
