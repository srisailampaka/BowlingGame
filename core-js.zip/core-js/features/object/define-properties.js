module.exports = require('../../es/object/define-properties');
