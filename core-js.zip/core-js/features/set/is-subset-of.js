require('../../modules/es.set');
require('../../modules/esnext.set.is-subset-of');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Set', 'isSubsetOf');
