module.exports = require('../../es/array/entries');
