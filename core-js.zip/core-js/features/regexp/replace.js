module.exports = require('../../es/regexp/replace');
