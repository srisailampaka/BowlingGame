module.exports = require('../../es/regexp/search');
