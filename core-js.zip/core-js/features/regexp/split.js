module.exports = require('../../es/regexp/split');
