module.exports = require('../../stable/instance/entries');
