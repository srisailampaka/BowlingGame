import { propertyOf } from "../fp";
export = propertyOf;
