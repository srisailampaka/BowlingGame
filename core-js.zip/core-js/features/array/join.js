module.exports = require('../../es/array/join');
