module.exports = require('../../es/symbol/unscopables');
