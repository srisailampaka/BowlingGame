module.exports = require('../../es/instance/map');
