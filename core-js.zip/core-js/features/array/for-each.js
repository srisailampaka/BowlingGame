module.exports = require('../../es/array/for-each');
