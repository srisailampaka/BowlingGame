export declare function RestangularConfigurer(object: any, configuration: any): void;
