module.exports = require('../../es/string/repeat');
