import { __read, __spread } from 'tslib';
import { InjectionToken, Injectable, Inject, Injector, Optional, NgModule, SkipSelf } from '@angular/core';
import { isArray, includes, isUndefined, isNull, isObject, isBoolean, defaults, each, extend, find, has, initial, last, clone, reduce, keys, isEmpty, forEach, map as map$1, bind, union, values, pick, isFunction, isNumber, every, omit, get } from 'lodash';
import { HttpRequest, HttpHeaders, HttpParams, HttpBackend, HttpErrorResponse, HttpResponse, HttpClientModule } from '@angular/common/http';
import { assign } from 'core-js/fn/object';
import { throwError, BehaviorSubject } from 'rxjs';
import { catchError, filter, map } from 'rxjs/operators';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
/** @type {?} */
var RESTANGULAR = new InjectionToken('restangularWithConfig');
/**
 * @param {?} __0
 * @return {?}
 */
function RestangularFactory(_a) {
    var _b = __read(_a, 2), callbackOrServices = _b[0], callback = _b[1];
    /** @type {?} */
    var arrServices = [];
    /** @type {?} */
    var fn = callbackOrServices;
    if (isArray(callbackOrServices)) {
        arrServices = callbackOrServices;
        fn = callback;
    }
    return { fn: fn, arrServices: arrServices };
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
var RestangularHelper = /** @class */ (function () {
    function RestangularHelper() {
    }
    /**
     * @param {?} options
     * @return {?}
     */
    RestangularHelper.createRequest = /**
     * @param {?} options
     * @return {?}
     */
    function (options) {
        /** @type {?} */
        var requestQueryParams = RestangularHelper.createRequestQueryParams(options.params);
        /** @type {?} */
        var requestHeaders = RestangularHelper.createRequestHeaders(options.headers);
        /** @type {?} */
        var methodName = options.method.toUpperCase();
        /** @type {?} */
        var withCredentials = options.withCredentials || false;
        /** @type {?} */
        var request = new HttpRequest(methodName, options.url, options.data, {
            headers: requestHeaders,
            params: requestQueryParams,
            responseType: options.responseType,
            withCredentials: withCredentials
        });
        if (['GET', 'DELETE', 'HEAD', 'JSONP', 'OPTIONS'].indexOf(methodName) >= 0) {
            request = new HttpRequest(methodName, options.url, {
                headers: requestHeaders,
                params: requestQueryParams,
                responseType: options.responseType,
                withCredentials: withCredentials
            });
        }
        return request;
    };
    /**
     * @param {?} queryParams
     * @return {?}
     */
    RestangularHelper.createRequestQueryParams = /**
     * @param {?} queryParams
     * @return {?}
     */
    function (queryParams) {
        /** @type {?} */
        var requestQueryParams = assign({}, queryParams);
        /** @type {?} */
        var search = new HttpParams();
        var _loop_1 = function (key) {
            /** @type {?} */
            var value = requestQueryParams[key];
            if (Array.isArray(value)) {
                value.forEach(function (val) {
                    search = search.append(key, val);
                });
            }
            else {
                if (typeof value === 'object') {
                    value = JSON.stringify(value);
                }
                search = search.append(key, value);
            }
        };
        for (var key in requestQueryParams) {
            _loop_1(key);
        }
        return search;
    };
    /**
     * @param {?} headers
     * @return {?}
     */
    RestangularHelper.createRequestHeaders = /**
     * @param {?} headers
     * @return {?}
     */
    function (headers) {
        for (var key in headers) {
            /** @type {?} */
            var value = headers[key];
            if (typeof value === 'undefined') {
                delete headers[key];
            }
        }
        return new HttpHeaders(assign({}, headers));
    };
    return RestangularHelper;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
var RestangularHttp = /** @class */ (function () {
    function RestangularHttp(http) {
        this.http = http;
    }
    /**
     * @param {?} options
     * @return {?}
     */
    RestangularHttp.prototype.createRequest = /**
     * @param {?} options
     * @return {?}
     */
    function (options) {
        /** @type {?} */
        var request = RestangularHelper.createRequest(options);
        return this.request(request);
    };
    /**
     * @param {?} request
     * @return {?}
     */
    RestangularHttp.prototype.request = /**
     * @param {?} request
     * @return {?}
     */
    function (request) {
        var _this = this;
        return this.http.handle(request)
            .pipe(filter(function (event) { return event instanceof HttpResponse; }), map(function (response) {
            if (!response.ok) {
                return throwError(new HttpErrorResponse(response));
            }
            return response;
        }), map(function (response) {
            response.config = { params: request };
            return response;
        }), catchError(function (err) {
            err.request = request;
            err.data = err.error;
            err.repeatRequest = function (newRequest) {
                return _this.request(newRequest || request);
            };
            return throwError(err);
        }));
    };
    RestangularHttp.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    RestangularHttp.ctorParameters = function () { return [
        { type: HttpBackend }
    ]; };
    return RestangularHttp;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
/**
 * @param {?} object
 * @param {?} configuration
 * @return {?}
 */
function RestangularConfigurer(object, configuration) {
    object.configuration = configuration;
    /**
     * Those are HTTP safe methods for which there is no need to pass any data with the request.
     * @type {?}
     */
    var safeMethods = ['get', 'head', 'options', 'trace', 'getlist'];
    configuration.isSafe = function (operation) {
        return includes(safeMethods, operation.toLowerCase());
    };
    /** @type {?} */
    var absolutePattern = /^https?:\/\//i;
    configuration.isAbsoluteUrl = function (string) {
        return isUndefined(configuration.absoluteUrl) || isNull(configuration.absoluteUrl) ?
            string && absolutePattern.test(string) :
            configuration.absoluteUrl;
    };
    configuration.absoluteUrl = isUndefined(configuration.absoluteUrl) ? true : configuration.absoluteUrl;
    object.setSelfLinkAbsoluteUrl = function (value) {
        configuration.absoluteUrl = value;
    };
    /**
     * This is the BaseURL to be used with Restangular
     */
    configuration.baseUrl = isUndefined(configuration.baseUrl) ? '' : configuration.baseUrl;
    object.setBaseUrl = function (newBaseUrl) {
        configuration.baseUrl = /\/$/.test(newBaseUrl) ?
            newBaseUrl.substring(0, newBaseUrl.length - 1) :
            newBaseUrl;
        return this;
    };
    /**
     * Sets the extra fields to keep from the parents
     */
    configuration.extraFields = configuration.extraFields || [];
    object.setExtraFields = function (newExtraFields) {
        configuration.extraFields = newExtraFields;
        return this;
    };
    /**
     * Some default $http parameter to be used in EVERY call
     **/
    configuration.defaultHttpFields = configuration.defaultHttpFields || {};
    object.setDefaultHttpFields = function (values$$1) {
        configuration.defaultHttpFields = values$$1;
        return this;
    };
    /**
     * Always return plain data, no restangularized object
     **/
    configuration.plainByDefault = configuration.plainByDefault || false;
    object.setPlainByDefault = function (value) {
        configuration.plainByDefault = value === true ? true : false;
        return this;
    };
    configuration.withHttpValues = function (httpLocalConfig, obj) {
        return defaults(obj, httpLocalConfig, configuration.defaultHttpFields);
    };
    configuration.encodeIds = isUndefined(configuration.encodeIds) ? true : configuration.encodeIds;
    object.setEncodeIds = function (encode) {
        configuration.encodeIds = encode;
    };
    configuration.defaultRequestParams = configuration.defaultRequestParams || {
        get: {},
        post: {},
        put: {},
        remove: {},
        common: {}
    };
    object.setDefaultRequestParams = function (param1, param2) {
        /** @type {?} */
        var methods = [];
        /** @type {?} */
        var params = param2 || param1;
        if (!isUndefined(param2)) {
            if (isArray(param1)) {
                methods = param1;
            }
            else {
                methods.push(param1);
            }
        }
        else {
            methods.push('common');
        }
        each(methods, function (method) {
            configuration.defaultRequestParams[method] = params;
        });
        return this;
    };
    object.requestParams = configuration.defaultRequestParams;
    configuration.defaultHeaders = configuration.defaultHeaders || {};
    object.setDefaultHeaders = function (headers) {
        configuration.defaultHeaders = headers;
        object.defaultHeaders = configuration.defaultHeaders;
        return this;
    };
    object.defaultHeaders = configuration.defaultHeaders;
    /**
     * Method overriders response Method
     **/
    configuration.defaultResponseMethod = configuration.defaultResponseMethod || 'promise';
    object.setDefaultResponseMethod = function (method) {
        configuration.defaultResponseMethod = method;
        object.defaultResponseMethod = configuration.defaultResponseMethod;
        return this;
    };
    object.defaultResponseMethod = configuration.defaultResponseMethod;
    /**
     * Method overriders will set which methods are sent via POST with an X-HTTP-Method-Override
     **/
    configuration.methodOverriders = configuration.methodOverriders || [];
    object.setMethodOverriders = function (values$$1) {
        /** @type {?} */
        var overriders = extend([], values$$1);
        if (configuration.isOverridenMethod('delete', overriders)) {
            overriders.push('remove');
        }
        configuration.methodOverriders = overriders;
        return this;
    };
    configuration.jsonp = isUndefined(configuration.jsonp) ? false : configuration.jsonp;
    object.setJsonp = function (active) {
        configuration.jsonp = active;
    };
    configuration.isOverridenMethod = function (method, values$$1) {
        /** @type {?} */
        var search = values$$1 || configuration.methodOverriders;
        return !isUndefined(find(search, function (one) {
            return one.toLowerCase() === method.toLowerCase();
        }));
    };
    /**
     * Sets the URL creator type. For now, only Path is created. In the future we'll have queryParams
     **/
    configuration.urlCreator = configuration.urlCreator || 'path';
    object.setUrlCreator = function (name) {
        if (!has(configuration.urlCreatorFactory, name)) {
            throw new Error('URL Path selected isn\'t valid');
        }
        configuration.urlCreator = name;
        return this;
    };
    /**
     * You can set the restangular fields here. The 3 required fields for Restangular are:
     *
     * id: Id of the element
     * route: name of the route of this element
     * parentResource: the reference to the parent resource
     *
     *  All of this fields except for id, are handled (and created) by Restangular. By default,
     *  the field values will be id, route and parentResource respectively
     */
    configuration.restangularFields = configuration.restangularFields || {
        id: 'id',
        route: 'route',
        parentResource: 'parentResource',
        restangularCollection: 'restangularCollection',
        cannonicalId: '__cannonicalId',
        etag: 'restangularEtag',
        selfLink: 'href',
        get: 'get',
        getList: 'getList',
        put: 'put',
        post: 'post',
        remove: 'remove',
        head: 'head',
        trace: 'trace',
        options: 'options',
        patch: 'patch',
        getRestangularUrl: 'getRestangularUrl',
        getRequestedUrl: 'getRequestedUrl',
        putElement: 'putElement',
        addRestangularMethod: 'addRestangularMethod',
        getParentList: 'getParentList',
        clone: 'clone',
        ids: 'ids',
        httpConfig: '_$httpConfig',
        reqParams: 'reqParams',
        one: 'one',
        all: 'all',
        several: 'several',
        oneUrl: 'oneUrl',
        allUrl: 'allUrl',
        customPUT: 'customPUT',
        customPATCH: 'customPATCH',
        customPOST: 'customPOST',
        customDELETE: 'customDELETE',
        customGET: 'customGET',
        customGETLIST: 'customGETLIST',
        customOperation: 'customOperation',
        doPUT: 'doPUT',
        doPATCH: 'doPATCH',
        doPOST: 'doPOST',
        doDELETE: 'doDELETE',
        doGET: 'doGET',
        doGETLIST: 'doGETLIST',
        fromServer: 'fromServer',
        withConfig: 'withConfig',
        withHttpConfig: 'withHttpConfig',
        singleOne: 'singleOne',
        plain: 'plain',
        save: 'save',
        restangularized: 'restangularized'
    };
    object.setRestangularFields = function (resFields) {
        configuration.restangularFields =
            extend({}, configuration.restangularFields, resFields);
        return this;
    };
    configuration.isRestangularized = function (obj) {
        return !!obj[configuration.restangularFields.restangularized];
    };
    configuration.setFieldToElem = function (field, elem, value) {
        /** @type {?} */
        var properties = field.split('.');
        /** @type {?} */
        var idValue = elem;
        each(initial(properties), function (prop) {
            idValue[prop] = {};
            idValue = idValue[prop];
        });
        /** @type {?} */
        var index = last(properties);
        idValue[index] = value;
        return this;
    };
    configuration.getFieldFromElem = function (field, elem) {
        /** @type {?} */
        var properties = field.split('.');
        /** @type {?} */
        var idValue = elem;
        each(properties, function (prop) {
            if (idValue) {
                idValue = idValue[prop];
            }
        });
        return clone(idValue);
    };
    configuration.setIdToElem = function (elem, id /*, route */) {
        configuration.setFieldToElem(configuration.restangularFields.id, elem, id);
        return this;
    };
    configuration.getIdFromElem = function (elem) {
        return configuration.getFieldFromElem(configuration.restangularFields.id, elem);
    };
    configuration.isValidId = function (elemId) {
        return '' !== elemId && !isUndefined(elemId) && !isNull(elemId);
    };
    configuration.setUrlToElem = function (elem, url /*, route */) {
        configuration.setFieldToElem(configuration.restangularFields.selfLink, elem, url);
        return this;
    };
    configuration.getUrlFromElem = function (elem) {
        return configuration.getFieldFromElem(configuration.restangularFields.selfLink, elem);
    };
    configuration.useCannonicalId = isUndefined(configuration.useCannonicalId) ? false : configuration.useCannonicalId;
    object.setUseCannonicalId = function (value) {
        configuration.useCannonicalId = value;
        return this;
    };
    configuration.getCannonicalIdFromElem = function (elem) {
        /** @type {?} */
        var cannonicalId = elem[configuration.restangularFields.cannonicalId];
        /** @type {?} */
        var actualId = configuration.isValidId(cannonicalId) ? cannonicalId : configuration.getIdFromElem(elem);
        return actualId;
    };
    /**
     * Sets the Response parser. This is used in case your response isn't directly the data.
     * For example if you have a response like {meta: {'meta'}, data: {name: 'Gonto'}}
     * you can extract this data which is the one that needs wrapping
     *
     * The ResponseExtractor is a function that receives the response and the method executed.
     */
    configuration.responseInterceptors = configuration.responseInterceptors ? __spread(configuration.responseInterceptors) : [];
    configuration.defaultResponseInterceptor = function (data /*, operation, what, url, response, subject */) {
        return data || {};
    };
    configuration.responseExtractor = function (data, operation, what, url, response, subject) {
        /** @type {?} */
        var interceptors = clone(configuration.responseInterceptors);
        interceptors.push(configuration.defaultResponseInterceptor);
        /** @type {?} */
        var theData = data;
        each(interceptors, function (interceptor) {
            theData = interceptor(theData, operation, what, url, response, subject);
        });
        return theData;
    };
    object.addResponseInterceptor = function (extractor) {
        configuration.responseInterceptors.push(extractor);
        return this;
    };
    configuration.errorInterceptors = configuration.errorInterceptors ? __spread(configuration.errorInterceptors) : [];
    object.addErrorInterceptor = function (interceptor) {
        configuration.errorInterceptors = __spread([interceptor], configuration.errorInterceptors);
        return this;
    };
    object.setResponseInterceptor = object.addResponseInterceptor;
    object.setResponseExtractor = object.addResponseInterceptor;
    object.setErrorInterceptor = object.addErrorInterceptor;
    /**
     * Response interceptor is called just before resolving promises.
     */
    /**
     * Request interceptor is called before sending an object to the server.
     */
    configuration.requestInterceptors = configuration.requestInterceptors ? __spread(configuration.requestInterceptors) : [];
    configuration.defaultInterceptor = function (element, operation, path, url, headers, params, httpConfig) {
        return {
            element: element,
            headers: headers,
            params: params,
            httpConfig: httpConfig
        };
    };
    configuration.fullRequestInterceptor = function (element, operation, path, url, headers, params, httpConfig) {
        /** @type {?} */
        var interceptors = clone(configuration.requestInterceptors);
        /** @type {?} */
        var defaultRequest = configuration.defaultInterceptor(element, operation, path, url, headers, params, httpConfig);
        return reduce(interceptors, function (request, interceptor) {
            /** @type {?} */
            var returnInterceptor = interceptor(request.element, operation, path, url, request.headers, request.params, request.httpConfig);
            return extend(request, returnInterceptor);
        }, defaultRequest);
    };
    object.addRequestInterceptor = function (interceptor) {
        configuration.requestInterceptors.push(function (elem, operation, path, url, headers, params, httpConfig) {
            return {
                headers: headers,
                params: params,
                element: interceptor(elem, operation, path, url),
                httpConfig: httpConfig
            };
        });
        return this;
    };
    object.setRequestInterceptor = object.addRequestInterceptor;
    object.addFullRequestInterceptor = function (interceptor) {
        configuration.requestInterceptors.push(interceptor);
        return this;
    };
    object.setFullRequestInterceptor = object.addFullRequestInterceptor;
    configuration.onBeforeElemRestangularized = configuration.onBeforeElemRestangularized || function (elem) {
        return elem;
    };
    object.setOnBeforeElemRestangularized = function (post) {
        configuration.onBeforeElemRestangularized = post;
        return this;
    };
    object.setRestangularizePromiseInterceptor = function (interceptor) {
        configuration.restangularizePromiseInterceptor = interceptor;
        return this;
    };
    /**
     * This method is called after an element has been "Restangularized".
     *
     * It receives the element, a boolean indicating if it's an element or a collection
     * and the name of the model
     *
     */
    configuration.onElemRestangularized = configuration.onElemRestangularized || function (elem) {
        return elem;
    };
    object.setOnElemRestangularized = function (post) {
        configuration.onElemRestangularized = post;
        return this;
    };
    configuration.shouldSaveParent = configuration.shouldSaveParent || function () {
        return true;
    };
    object.setParentless = function (values$$1) {
        if (isArray(values$$1)) {
            configuration.shouldSaveParent = function (route) {
                return !includes(values$$1, route);
            };
        }
        else if (isBoolean(values$$1)) {
            configuration.shouldSaveParent = function () {
                return !values$$1;
            };
        }
        return this;
    };
    /**
     * This lets you set a suffix to every request.
     *
     * For example, if your api requires that for JSon requests you do /users/123.json, you can set that
     * in here.
     *
     *
     * By default, the suffix is null
     */
    configuration.suffix = isUndefined(configuration.suffix) ? null : configuration.suffix;
    object.setRequestSuffix = function (newSuffix) {
        configuration.suffix = newSuffix;
        return this;
    };
    /**
     * Add element transformers for certain routes.
     */
    configuration.transformers = configuration.transformers || {};
    object.addElementTransformer = function (type, secondArg, thirdArg) {
        /** @type {?} */
        var isCollection = null;
        /** @type {?} */
        var transformer = null;
        if (arguments.length === 2) {
            transformer = secondArg;
        }
        else {
            transformer = thirdArg;
            isCollection = secondArg;
        }
        /** @type {?} */
        var typeTransformers = configuration.transformers[type];
        if (!typeTransformers) {
            typeTransformers = configuration.transformers[type] = [];
        }
        typeTransformers.push(function (coll, elem) {
            if (isNull(isCollection) || (coll === isCollection)) {
                return transformer(elem);
            }
            return elem;
        });
        return object;
    };
    object.extendCollection = function (route, fn) {
        return object.addElementTransformer(route, true, fn);
    };
    object.extendModel = function (route, fn) {
        return object.addElementTransformer(route, false, fn);
    };
    configuration.transformElem = function (elem, isCollection, route, Restangular, force) {
        if (!force && !configuration.transformLocalElements && !elem[configuration.restangularFields.fromServer]) {
            return elem;
        }
        /** @type {?} */
        var typeTransformers = configuration.transformers[route];
        /** @type {?} */
        var changedElem = elem;
        if (typeTransformers) {
            each(typeTransformers, function (transformer) {
                changedElem = transformer(isCollection, changedElem);
            });
        }
        return configuration.onElemRestangularized(changedElem, isCollection, route, Restangular);
    };
    configuration.transformLocalElements = isUndefined(configuration.transformLocalElements) ?
        false :
        configuration.transformLocalElements;
    object.setTransformOnlyServerElements = function (active) {
        configuration.transformLocalElements = !active;
    };
    configuration.fullResponse = isUndefined(configuration.fullResponse) ? false : configuration.fullResponse;
    object.setFullResponse = function (full) {
        configuration.fullResponse = full;
        return this;
    };
    // Internal values and functions
    configuration.urlCreatorFactory = {};
    /**
     * Base URL Creator. Base prototype for everything related to it
     *
     * @type {?}
     */
    var BaseCreator = function () {
    };
    BaseCreator.prototype.setConfig = function (config) {
        this.config = config;
        return this;
    };
    BaseCreator.prototype.parentsArray = function (current) {
        /** @type {?} */
        var parents = [];
        while (current) {
            parents.push(current);
            current = current[this.config.restangularFields.parentResource];
        }
        return parents.reverse();
    };
    /**
     * @param {?} config
     * @param {?} $http
     * @param {?} url
     * @param {?} configurer
     * @return {?}
     */
    function RestangularResource(config, $http, url, configurer) {
        /** @type {?} */
        var resource = {};
        each(keys(configurer), function (key) {
            /** @type {?} */
            var value = configurer[key];
            // Add default parameters
            value.params = extend({}, value.params, config.defaultRequestParams[value.method.toLowerCase()]);
            // We don't want the ? if no params are there
            if (isEmpty(value.params)) {
                delete value.params;
            }
            if (config.isSafe(value.method)) {
                resource[key] = function () {
                    /** @type {?} */
                    var resultConfig = extend(value, {
                        url: url
                    });
                    return $http.createRequest(resultConfig);
                };
            }
            else {
                resource[key] = function (data) {
                    /** @type {?} */
                    var resultConfig = extend(value, {
                        url: url,
                        data: data
                    });
                    return $http.createRequest(resultConfig);
                };
            }
        });
        return resource;
    }
    BaseCreator.prototype.resource = function (current, $http, localHttpConfig, callHeaders, callParams, what, etag, operation) {
        /** @type {?} */
        var params = defaults(callParams || {}, this.config.defaultRequestParams.common);
        /** @type {?} */
        var headers = defaults(callHeaders || {}, this.config.defaultHeaders);
        if (etag) {
            if (!configuration.isSafe(operation)) {
                headers['If-Match'] = etag;
            }
            else {
                headers['If-None-Match'] = etag;
            }
        }
        /** @type {?} */
        var url = this.base(current);
        if (what) {
            /** @type {?} */
            var add = '';
            if (!/\/$/.test(url)) {
                add += '/';
            }
            add += what;
            url += add;
        }
        if (this.config.suffix &&
            url.indexOf(this.config.suffix, url.length - this.config.suffix.length) === -1 && !this.config.getUrlFromElem(current)) {
            url += this.config.suffix;
        }
        current[this.config.restangularFields.httpConfig] = undefined;
        return RestangularResource(this.config, $http, url, {
            getList: this.config.withHttpValues(localHttpConfig, {
                method: 'GET',
                params: params,
                headers: headers
            }),
            get: this.config.withHttpValues(localHttpConfig, {
                method: 'GET',
                params: params,
                headers: headers
            }),
            jsonp: this.config.withHttpValues(localHttpConfig, {
                method: 'jsonp',
                params: params,
                headers: headers
            }),
            put: this.config.withHttpValues(localHttpConfig, {
                method: 'PUT',
                params: params,
                headers: headers
            }),
            post: this.config.withHttpValues(localHttpConfig, {
                method: 'POST',
                params: params,
                headers: headers
            }),
            remove: this.config.withHttpValues(localHttpConfig, {
                method: 'DELETE',
                params: params,
                headers: headers
            }),
            head: this.config.withHttpValues(localHttpConfig, {
                method: 'HEAD',
                params: params,
                headers: headers
            }),
            trace: this.config.withHttpValues(localHttpConfig, {
                method: 'TRACE',
                params: params,
                headers: headers
            }),
            options: this.config.withHttpValues(localHttpConfig, {
                method: 'OPTIONS',
                params: params,
                headers: headers
            }),
            patch: this.config.withHttpValues(localHttpConfig, {
                method: 'PATCH',
                params: params,
                headers: headers
            })
        });
    };
    /**
     * This is the Path URL creator. It uses Path to show Hierarchy in the Rest API.
     * This means that if you have an Account that then has a set of Buildings, a URL to a building
     * would be /accounts/123/buildings/456
     *
     * @type {?}
     */
    var Path = function () {
    };
    Path.prototype = new BaseCreator();
    Path.prototype.normalizeUrl = function (url) {
        /** @type {?} */
        var parts = /((?:http[s]?:)?\/\/)?(.*)?/.exec(url);
        parts[2] = parts[2].replace(/[\\\/]+/g, '/');
        return (typeof parts[1] !== 'undefined') ? parts[1] + parts[2] : parts[2];
    };
    Path.prototype.base = function (current) {
        /** @type {?} */
        var __this = this;
        return reduce(this.parentsArray(current), function (acum, elem) {
            /** @type {?} */
            var elemUrl;
            /** @type {?} */
            var elemSelfLink = __this.config.getUrlFromElem(elem);
            if (elemSelfLink) {
                if (__this.config.isAbsoluteUrl(elemSelfLink)) {
                    return elemSelfLink;
                }
                else {
                    elemUrl = elemSelfLink;
                }
            }
            else {
                elemUrl = elem[__this.config.restangularFields.route];
                if (elem[__this.config.restangularFields.restangularCollection]) {
                    /** @type {?} */
                    var ids = elem[__this.config.restangularFields.ids];
                    if (ids) {
                        elemUrl += '/' + ids.join(',');
                    }
                }
                else {
                    /** @type {?} */
                    var elemId = void 0;
                    if (__this.config.useCannonicalId) {
                        elemId = __this.config.getCannonicalIdFromElem(elem);
                    }
                    else {
                        elemId = __this.config.getIdFromElem(elem);
                    }
                    if (configuration.isValidId(elemId) && !elem.singleOne) {
                        elemUrl += '/' + (__this.config.encodeIds ? encodeURIComponent(elemId) : elemId);
                    }
                }
            }
            acum = acum.replace(/\/$/, '') + '/' + elemUrl;
            return __this.normalizeUrl(acum);
        }, this.config.baseUrl);
    };
    Path.prototype.fetchUrl = function (current, what) {
        /** @type {?} */
        var baseUrl = this.base(current);
        if (what) {
            baseUrl += '/' + what;
        }
        return baseUrl;
    };
    Path.prototype.fetchRequestedUrl = function (current, what) {
        /** @type {?} */
        var url = this.fetchUrl(current, what);
        /** @type {?} */
        var params = current[configuration.restangularFields.reqParams];
        // From here on and until the end of fetchRequestedUrl,
        // the code has been kindly borrowed from angular.js
        // The reason for such code bloating is coherence:
        //   If the user were to use this for cache management, the
        //   serialization of parameters would need to be identical
        //   to the one done by angular for cache keys to match.
        /**
         * @param {?} obj
         * @return {?}
         */
        function sortedKeys(obj) {
            /** @type {?} */
            var resultKeys = [];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    resultKeys.push(key);
                }
            }
            return resultKeys.sort();
        }
        /**
         * @param {?} obj
         * @param {?=} iterator
         * @param {?=} context
         * @return {?}
         */
        function forEachSorted(obj, iterator, context) {
            /** @type {?} */
            var sortedKeysArray = sortedKeys(obj);
            for (var i = 0; i < sortedKeysArray.length; i++) {
                iterator.call(context, obj[sortedKeysArray[i]], sortedKeysArray[i]);
            }
            return sortedKeysArray;
        }
        /**
         * @param {?} val
         * @param {?=} pctEncodeSpaces
         * @return {?}
         */
        function encodeUriQuery(val, pctEncodeSpaces) {
            return encodeURIComponent(val)
                .replace(/%40/gi, '@')
                .replace(/%3A/gi, ':')
                .replace(/%24/g, '$')
                .replace(/%2C/gi, ',')
                .replace(/%20/g, (pctEncodeSpaces ? '%20' : '+'));
        }
        if (!params) {
            return url + (this.config.suffix || '');
        }
        /** @type {?} */
        var parts = [];
        forEachSorted(params, function (value, key) {
            if (value === null || value === undefined) {
                return;
            }
            if (!isArray(value)) {
                value = [value];
            }
            forEach(value, function (v) {
                if (isObject(v)) {
                    v = JSON.stringify(v);
                }
                parts.push(encodeUriQuery(key) + '=' + encodeUriQuery(v));
            });
        });
        return url + (this.config.suffix || '') + ((url.indexOf('?') === -1) ? '?' : '&') + parts.join('&');
    };
    configuration.urlCreatorFactory.path = Path;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
var Restangular = /** @class */ (function () {
    function Restangular(configObj, injector, http) {
        this.configObj = configObj;
        this.injector = injector;
        this.http = http;
        this.provider = new providerConfig(http);
        /** @type {?} */
        var element = this.provider.$get();
        assign(this, element);
        this.setDefaultConfig();
    }
    /**
     * @return {?}
     */
    Restangular.prototype.setDefaultConfig = /**
     * @return {?}
     */
    function () {
        var _this = this;
        var _a;
        if (!this.configObj || !isFunction(this.configObj.fn)) {
            return;
        }
        /** @type {?} */
        var arrDI = map$1(this.configObj.arrServices, function (services) {
            return _this.injector.get(services);
        });
        (_a = this.configObj).fn.apply(_a, __spread([this.provider], arrDI));
    };
    Restangular.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    Restangular.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Optional }, { type: Inject, args: [RESTANGULAR,] }] },
        { type: Injector },
        { type: RestangularHttp }
    ]; };
    return Restangular;
}());
/**
 * @param {?} $http
 * @return {?}
 */
function providerConfig($http) {
    /** @type {?} */
    var globalConfiguration = {};
    RestangularConfigurer(this, globalConfiguration);
    this.$get = $get;
    /**
     * @return {?}
     */
    function $get() {
        /**
         * @param {?} config
         * @return {?}
         */
        function createServiceForConfiguration(config) {
            /** @type {?} */
            var service = {};
            /** @type {?} */
            var urlHandler = new config.urlCreatorFactory[config.urlCreator]();
            urlHandler.setConfig(config);
            /**
             * @param {?} parent
             * @param {?} elem
             * @param {?} route
             * @param {?} reqParams
             * @param {?} fromServer
             * @return {?}
             */
            function restangularizeBase(parent, elem, route, reqParams, fromServer) {
                elem[config.restangularFields.route] = route;
                elem[config.restangularFields.getRestangularUrl] = bind(urlHandler.fetchUrl, urlHandler, elem);
                elem[config.restangularFields.getRequestedUrl] = bind(urlHandler.fetchRequestedUrl, urlHandler, elem);
                elem[config.restangularFields.addRestangularMethod] = bind(addRestangularMethodFunction, elem);
                elem[config.restangularFields.clone] = bind(copyRestangularizedElement, elem);
                elem[config.restangularFields.reqParams] = isEmpty(reqParams) ? null : reqParams;
                elem[config.restangularFields.withHttpConfig] = bind(withHttpConfig, elem);
                elem[config.restangularFields.plain] = bind(stripRestangular, elem, elem);
                // Tag element as restangularized
                elem[config.restangularFields.restangularized] = true;
                // RequestLess connection
                elem[config.restangularFields.one] = bind(one, elem, elem);
                elem[config.restangularFields.all] = bind(all, elem, elem);
                elem[config.restangularFields.several] = bind(several, elem, elem);
                elem[config.restangularFields.oneUrl] = bind(oneUrl, elem, elem);
                elem[config.restangularFields.allUrl] = bind(allUrl, elem, elem);
                elem[config.restangularFields.fromServer] = !!fromServer;
                if (parent && config.shouldSaveParent(route)) {
                    /** @type {?} */
                    var parentId = config.getIdFromElem(parent);
                    /** @type {?} */
                    var parentUrl = config.getUrlFromElem(parent);
                    /** @type {?} */
                    var restangularFieldsForParent = union(values(pick(config.restangularFields, ['route', 'singleOne', 'parentResource'])), config.extraFields);
                    /** @type {?} */
                    var parentResource = pick(parent, restangularFieldsForParent);
                    if (config.isValidId(parentId)) {
                        config.setIdToElem(parentResource, parentId, route);
                    }
                    if (config.isValidId(parentUrl)) {
                        config.setUrlToElem(parentResource, parentUrl, route);
                    }
                    elem[config.restangularFields.parentResource] = parentResource;
                }
                else {
                    elem[config.restangularFields.parentResource] = null;
                }
                return elem;
            }
            /**
             * @param {?} parent
             * @param {?} route
             * @param {?} id
             * @param {?} singleOne
             * @return {?}
             */
            function one(parent, route, id, singleOne) {
                /** @type {?} */
                var error;
                if (isNumber(route) || isNumber(parent)) {
                    error = 'You\'re creating a Restangular entity with the number ';
                    error += 'instead of the route or the parent. For example, you can\'t call .one(12).';
                    throw new Error(error);
                }
                if (isUndefined(route)) {
                    error = 'You\'re creating a Restangular entity either without the path. ';
                    error += 'For example you can\'t call .one(). Please check if your arguments are valid.';
                    throw new Error(error);
                }
                /** @type {?} */
                var elem = {};
                config.setIdToElem(elem, id, route);
                config.setFieldToElem(config.restangularFields.singleOne, elem, singleOne);
                return restangularizeElem(parent, elem, route, false);
            }
            /**
             * @param {?} parent
             * @param {?} route
             * @return {?}
             */
            function all(parent, route) {
                return restangularizeCollection(parent, [], route, false);
            }
            /**
             * @param {?} parent
             * @param {?} route
             * @return {?}
             */
            function several(parent, route /*, ids */) {
                /** @type {?} */
                var collection = [];
                collection[config.restangularFields.ids] = Array.prototype.splice.call(arguments, 2);
                return restangularizeCollection(parent, collection, route, false);
            }
            /**
             * @param {?} parent
             * @param {?} route
             * @param {?} url
             * @return {?}
             */
            function oneUrl(parent, route, url) {
                if (!route) {
                    throw new Error('Route is mandatory when creating new Restangular objects.');
                }
                /** @type {?} */
                var elem = {};
                config.setUrlToElem(elem, url, route);
                return restangularizeElem(parent, elem, route, false);
            }
            /**
             * @param {?} parent
             * @param {?} route
             * @param {?} url
             * @return {?}
             */
            function allUrl(parent, route, url) {
                if (!route) {
                    throw new Error('Route is mandatory when creating new Restangular objects.');
                }
                /** @type {?} */
                var elem = {};
                config.setUrlToElem(elem, url, route);
                return restangularizeCollection(parent, elem, route, false);
            }
            // Promises
            /**
             * @param {?} subject
             * @param {?} isCollection
             * @param {?} valueToFill
             * @return {?}
             */
            function restangularizeResponse(subject, isCollection, valueToFill) {
                return subject.pipe(filter(function (res) { return !!res; }));
            }
            /**
             * @param {?} subject
             * @param {?} response
             * @param {?} data
             * @param {?} filledValue
             * @return {?}
             */
            function resolvePromise(subject, response, data, filledValue) {
                extend(filledValue, data);
                // Trigger the full response interceptor.
                if (config.fullResponse) {
                    subject.next(extend(response, {
                        data: data
                    }));
                }
                else {
                    subject.next(data);
                }
                subject.complete();
            }
            // Elements
            /**
             * @param {?} elem
             * @return {?}
             */
            function stripRestangular(elem) {
                if (isArray(elem)) {
                    /** @type {?} */
                    var array_1 = [];
                    each(elem, function (value) {
                        array_1.push(config.isRestangularized(value) ? stripRestangular(value) : value);
                    });
                    return array_1;
                }
                else {
                    return omit(elem, values(omit(config.restangularFields, 'id')));
                }
            }
            /**
             * @param {?} elem
             * @return {?}
             */
            function addCustomOperation(elem) {
                elem[config.restangularFields.customOperation] = bind(customFunction, elem);
                /** @type {?} */
                var requestMethods = { get: customFunction, delete: customFunction };
                each(['put', 'patch', 'post'], function (name) {
                    requestMethods[name] = function (operation, element, path, params, headers) {
                        return bind(customFunction, this)(operation, path, params, headers, element);
                    };
                });
                each(requestMethods, function (requestFunc, name) {
                    /** @type {?} */
                    var callOperation = name === 'delete' ? 'remove' : name;
                    each(['do', 'custom'], function (alias) {
                        elem[alias + name.toUpperCase()] = bind(requestFunc, elem, callOperation);
                    });
                });
                elem[config.restangularFields.customGETLIST] = bind(fetchFunction, elem);
                elem[config.restangularFields.doGETLIST] = elem[config.restangularFields.customGETLIST];
            }
            /**
             * @param {?} fromElement
             * @param {?=} toElement
             * @return {?}
             */
            function copyRestangularizedElement(fromElement, toElement) {
                if (toElement === void 0) { toElement = {}; }
                /** @type {?} */
                var copiedElement = assign(toElement, fromElement);
                return restangularizeElem(copiedElement[config.restangularFields.parentResource], copiedElement, copiedElement[config.restangularFields.route], true);
            }
            /**
             * @param {?} parent
             * @param {?} element
             * @param {?} route
             * @param {?=} fromServer
             * @param {?=} collection
             * @param {?=} reqParams
             * @return {?}
             */
            function restangularizeElem(parent, element, route, fromServer, collection, reqParams) {
                /** @type {?} */
                var elem = config.onBeforeElemRestangularized(element, false, route);
                /** @type {?} */
                var localElem = restangularizeBase(parent, elem, route, reqParams, fromServer);
                if (config.useCannonicalId) {
                    localElem[config.restangularFields.cannonicalId] = config.getIdFromElem(localElem);
                }
                if (collection) {
                    localElem[config.restangularFields.getParentList] = function () {
                        return collection;
                    };
                }
                localElem[config.restangularFields.restangularCollection] = false;
                localElem[config.restangularFields.get] = bind(getFunction, localElem);
                localElem[config.restangularFields.getList] = bind(fetchFunction, localElem);
                localElem[config.restangularFields.put] = bind(putFunction, localElem);
                localElem[config.restangularFields.post] = bind(postFunction, localElem);
                localElem[config.restangularFields.remove] = bind(deleteFunction, localElem);
                localElem[config.restangularFields.head] = bind(headFunction, localElem);
                localElem[config.restangularFields.trace] = bind(traceFunction, localElem);
                localElem[config.restangularFields.options] = bind(optionsFunction, localElem);
                localElem[config.restangularFields.patch] = bind(patchFunction, localElem);
                localElem[config.restangularFields.save] = bind(save, localElem);
                addCustomOperation(localElem);
                return config.transformElem(localElem, false, route, service, true);
            }
            /**
             * @param {?} parent
             * @param {?} element
             * @param {?} route
             * @param {?=} fromServer
             * @param {?=} reqParams
             * @return {?}
             */
            function restangularizeCollection(parent, element, route, fromServer, reqParams) {
                /** @type {?} */
                var elem = config.onBeforeElemRestangularized(element, true, route);
                /** @type {?} */
                var localElem = restangularizeBase(parent, elem, route, reqParams, fromServer);
                localElem[config.restangularFields.restangularCollection] = true;
                localElem[config.restangularFields.post] = bind(postFunction, localElem, null);
                localElem[config.restangularFields.remove] = bind(deleteFunction, localElem);
                localElem[config.restangularFields.head] = bind(headFunction, localElem);
                localElem[config.restangularFields.trace] = bind(traceFunction, localElem);
                localElem[config.restangularFields.putElement] = bind(putElementFunction, localElem);
                localElem[config.restangularFields.options] = bind(optionsFunction, localElem);
                localElem[config.restangularFields.patch] = bind(patchFunction, localElem);
                localElem[config.restangularFields.get] = bind(getById, localElem);
                localElem[config.restangularFields.getList] = bind(fetchFunction, localElem, null);
                addCustomOperation(localElem);
                return config.transformElem(localElem, true, route, service, true);
            }
            /**
             * @param {?} parent
             * @param {?} element
             * @param {?} route
             * @return {?}
             */
            function restangularizeCollectionAndElements(parent, element, route) {
                /** @type {?} */
                var collection = restangularizeCollection(parent, element, route, false);
                each(collection, function (elem) {
                    if (elem) {
                        restangularizeElem(parent, elem, route, false);
                    }
                });
                return collection;
            }
            /**
             * @param {?} id
             * @param {?} reqParams
             * @param {?} headers
             * @return {?}
             */
            function getById(id, reqParams, headers) {
                return this.customGET(id.toString(), reqParams, headers);
            }
            /**
             * @param {?} idx
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function putElementFunction(idx, params, headers) {
                /** @type {?} */
                var __this = this;
                /** @type {?} */
                var elemToPut = this[idx];
                /** @type {?} */
                var subject = new BehaviorSubject(null);
                /** @type {?} */
                var filledArray = [];
                filledArray = config.transformElem(filledArray, true, elemToPut[config.restangularFields.route], service);
                elemToPut.put(params, headers)
                    .subscribe(function (serverElem) {
                    /** @type {?} */
                    var newArray = copyRestangularizedElement(__this);
                    newArray[idx] = serverElem;
                    filledArray = newArray;
                    subject.next(newArray);
                }, function (response) {
                    subject.error(response);
                }, function () {
                    subject.complete();
                });
                return restangularizeResponse(subject, true, filledArray);
            }
            /**
             * @param {?} resData
             * @param {?} operation
             * @param {?} route
             * @param {?} fetchUrl
             * @param {?} response
             * @param {?} subject
             * @return {?}
             */
            function parseResponse(resData, operation, route, fetchUrl, response, subject) {
                /** @type {?} */
                var data = config.responseExtractor(resData, operation, route, fetchUrl, response, subject);
                /** @type {?} */
                var etag = response.headers.get('ETag');
                if (data && etag) {
                    data[config.restangularFields.etag] = etag;
                }
                return data;
            }
            /**
             * @param {?} what
             * @param {?} reqParams
             * @param {?} headers
             * @return {?}
             */
            function fetchFunction(what, reqParams, headers) {
                /** @type {?} */
                var __this = this;
                /** @type {?} */
                var subject = new BehaviorSubject(null);
                /** @type {?} */
                var operation = 'getList';
                /** @type {?} */
                var url = urlHandler.fetchUrl(this, what);
                /** @type {?} */
                var whatFetched = what || __this[config.restangularFields.route];
                /** @type {?} */
                var request = config.fullRequestInterceptor(null, operation, whatFetched, url, headers || {}, reqParams || {}, this[config.restangularFields.httpConfig] || {});
                /** @type {?} */
                var filledArray = [];
                filledArray = config.transformElem(filledArray, true, whatFetched, service);
                /** @type {?} */
                var method = 'getList';
                if (config.jsonp) {
                    method = 'jsonp';
                }
                /** @type {?} */
                var okCallback = function (response) {
                    /** @type {?} */
                    var resData = response.body;
                    /** @type {?} */
                    var fullParams = response.config.params;
                    /** @type {?} */
                    var data = parseResponse(resData, operation, whatFetched, url, response, subject);
                    // support empty response for getList() calls (some APIs respond with 204 and empty body)
                    if (isUndefined(data) || '' === data) {
                        data = [];
                    }
                    if (!isArray(data)) {
                        throw new Error('Response for getList SHOULD be an array and not an object or something else');
                    }
                    if (true === config.plainByDefault) {
                        return resolvePromise(subject, response, data, filledArray);
                    }
                    /** @type {?} */
                    var processedData = map$1(data, function (elem) {
                        if (!__this[config.restangularFields.restangularCollection]) {
                            return restangularizeElem(__this, elem, what, true, data);
                        }
                        else {
                            return restangularizeElem(__this[config.restangularFields.parentResource], elem, __this[config.restangularFields.route], true, data);
                        }
                    });
                    processedData = extend(data, processedData);
                    if (!__this[config.restangularFields.restangularCollection]) {
                        resolvePromise(subject, response, restangularizeCollection(__this, processedData, what, true, fullParams), filledArray);
                    }
                    else {
                        resolvePromise(subject, response, restangularizeCollection(__this[config.restangularFields.parentResource], processedData, __this[config.restangularFields.route], true, fullParams), filledArray);
                    }
                };
                urlHandler.resource(this, $http, request.httpConfig, request.headers, request.params, what, this[config.restangularFields.etag], operation)[method]()
                    .subscribe(okCallback, function error(response) {
                    if (response.status === 304 && __this[config.restangularFields.restangularCollection]) {
                        resolvePromise(subject, response, __this, filledArray);
                    }
                    else if (every(config.errorInterceptors, function (cb) {
                        return cb(response, subject, okCallback) !== false;
                    })) {
                        // triggered if no callback returns false
                        subject.error(response);
                    }
                });
                return restangularizeResponse(subject, true, filledArray);
            }
            /**
             * @param {?} httpConfig
             * @return {?}
             */
            function withHttpConfig(httpConfig) {
                this[config.restangularFields.httpConfig] = httpConfig;
                return this;
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function save(params, headers) {
                if (this[config.restangularFields.fromServer]) {
                    return this[config.restangularFields.put](params, headers);
                }
                else {
                    return bind(elemFunction, this)('post', undefined, params, undefined, headers);
                }
            }
            /**
             * @param {?} operation
             * @param {?} what
             * @param {?} params
             * @param {?} obj
             * @param {?} headers
             * @return {?}
             */
            function elemFunction(operation, what, params, obj, headers) {
                /** @type {?} */
                var __this = this;
                /** @type {?} */
                var subject = new BehaviorSubject(null);
                /** @type {?} */
                var resParams = params || {};
                /** @type {?} */
                var route = what || this[config.restangularFields.route];
                /** @type {?} */
                var fetchUrl = urlHandler.fetchUrl(this, what);
                /** @type {?} */
                var callObj = obj || this;
                // fallback to etag on restangular object (since for custom methods we probably don't explicitly specify the etag field)
                /** @type {?} */
                var etag = callObj[config.restangularFields.etag] || (operation !== 'post' ? this[config.restangularFields.etag] : null);
                if (isObject(callObj) && config.isRestangularized(callObj)) {
                    callObj = stripRestangular(callObj);
                }
                /** @type {?} */
                var request = config.fullRequestInterceptor(callObj, operation, route, fetchUrl, headers || {}, resParams || {}, this[config.restangularFields.httpConfig] || {});
                /** @type {?} */
                var filledObject = {};
                filledObject = config.transformElem(filledObject, false, route, service);
                /** @type {?} */
                var okCallback = function (response) {
                    /** @type {?} */
                    var resData = get(response, 'body');
                    /** @type {?} */
                    var fullParams = get(response, 'config.params');
                    /** @type {?} */
                    var elem = parseResponse(resData, operation, route, fetchUrl, response, subject);
                    if (elem) {
                        /** @type {?} */
                        var data = void 0;
                        if (true === config.plainByDefault) {
                            return resolvePromise(subject, response, elem, filledObject);
                        }
                        if (operation === 'post' && !__this[config.restangularFields.restangularCollection]) {
                            data = restangularizeElem(__this[config.restangularFields.parentResource], elem, route, true, null, fullParams);
                            resolvePromise(subject, response, data, filledObject);
                        }
                        else {
                            data = restangularizeElem(__this[config.restangularFields.parentResource], elem, __this[config.restangularFields.route], true, null, fullParams);
                            data[config.restangularFields.singleOne] = __this[config.restangularFields.singleOne];
                            resolvePromise(subject, response, data, filledObject);
                        }
                    }
                    else {
                        resolvePromise(subject, response, undefined, filledObject);
                    }
                };
                /** @type {?} */
                var errorCallback = function (response) {
                    if (response.status === 304 && config.isSafe(operation)) {
                        resolvePromise(subject, response, __this, filledObject);
                    }
                    else if (every(config.errorInterceptors, function (cb) {
                        return cb(response, subject, okCallback) !== false;
                    })) {
                        // triggered if no callback returns false
                        subject.error(response);
                    }
                };
                // Overriding HTTP Method
                /** @type {?} */
                var callOperation = operation;
                /** @type {?} */
                var callHeaders = extend({}, request.headers);
                /** @type {?} */
                var isOverrideOperation = config.isOverridenMethod(operation);
                if (isOverrideOperation) {
                    callOperation = 'post';
                    callHeaders = extend(callHeaders, { 'X-HTTP-Method-Override': operation === 'remove' ? 'DELETE' : operation.toUpperCase() });
                }
                else if (config.jsonp && callOperation === 'get') {
                    callOperation = 'jsonp';
                }
                if (config.isSafe(operation)) {
                    if (isOverrideOperation) {
                        urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation]({}).subscribe(okCallback, errorCallback);
                    }
                    else {
                        urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation]().subscribe(okCallback, errorCallback);
                    }
                }
                else {
                    urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation](request.element).subscribe(okCallback, errorCallback);
                }
                return restangularizeResponse(subject, false, filledObject);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function getFunction(params, headers) {
                return bind(elemFunction, this)('get', undefined, params, undefined, headers);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function deleteFunction(params, headers) {
                return bind(elemFunction, this)('remove', undefined, params, undefined, headers);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function putFunction(params, headers) {
                return bind(elemFunction, this)('put', undefined, params, undefined, headers);
            }
            /**
             * @param {?} what
             * @param {?} elem
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function postFunction(what, elem, params, headers) {
                return bind(elemFunction, this)('post', what, params, elem, headers);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function headFunction(params, headers) {
                return bind(elemFunction, this)('head', undefined, params, undefined, headers);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function traceFunction(params, headers) {
                return bind(elemFunction, this)('trace', undefined, params, undefined, headers);
            }
            /**
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function optionsFunction(params, headers) {
                return bind(elemFunction, this)('options', undefined, params, undefined, headers);
            }
            /**
             * @param {?} elem
             * @param {?} params
             * @param {?} headers
             * @return {?}
             */
            function patchFunction(elem, params, headers) {
                return bind(elemFunction, this)('patch', undefined, params, elem, headers);
            }
            /**
             * @param {?} operation
             * @param {?} path
             * @param {?} params
             * @param {?} headers
             * @param {?} elem
             * @return {?}
             */
            function customFunction(operation, path, params, headers, elem) {
                return bind(elemFunction, this)(operation, path, params, elem, headers);
            }
            /**
             * @param {?} name
             * @param {?} operation
             * @param {?} path
             * @param {?} defaultParams
             * @param {?} defaultHeaders
             * @param {?} defaultElem
             * @return {?}
             */
            function addRestangularMethodFunction(name, operation, path, defaultParams, defaultHeaders, defaultElem) {
                /** @type {?} */
                var bindedFunction;
                if (operation === 'getList') {
                    bindedFunction = bind(fetchFunction, this, path);
                }
                else {
                    bindedFunction = bind(customFunction, this, operation, path);
                }
                /** @type {?} */
                var createdFunction = function (params, headers, elem) {
                    /** @type {?} */
                    var callParams = defaults({
                        params: params,
                        headers: headers,
                        elem: elem
                    }, {
                        params: defaultParams,
                        headers: defaultHeaders,
                        elem: defaultElem
                    });
                    return bindedFunction(callParams.params, callParams.headers, callParams.elem);
                };
                if (config.isSafe(operation)) {
                    this[name] = createdFunction;
                }
                else {
                    this[name] = function (elem, params, headers) {
                        return createdFunction(params, headers, elem);
                    };
                }
            }
            /**
             * @param {?} configurer
             * @return {?}
             */
            function withConfigurationFunction(configurer) {
                /** @type {?} */
                var newConfig = clone(omit(config, 'configuration'));
                RestangularConfigurer(newConfig, newConfig);
                configurer(newConfig);
                return createServiceForConfiguration(newConfig);
            }
            /**
             * @param {?} route
             * @param {?} parent
             * @return {?}
             */
            function toService(route, parent) {
                /** @type {?} */
                var knownCollectionMethods = values(config.restangularFields);
                /** @type {?} */
                var serv = {};
                /** @type {?} */
                var collection = (parent || service).all(route);
                serv.one = bind(one, (parent || service), parent, route);
                serv.all = bind(collection.all, collection);
                serv.post = bind(collection.post, collection);
                serv.getList = bind(collection.getList, collection);
                serv.withHttpConfig = bind(collection.withHttpConfig, collection);
                serv.get = bind(collection.get, collection);
                for (var prop in collection) {
                    if (collection.hasOwnProperty(prop) && isFunction(collection[prop]) && !includes(knownCollectionMethods, prop)) {
                        serv[prop] = bind(collection[prop], collection);
                    }
                }
                return serv;
            }
            RestangularConfigurer(service, config);
            service.copy = bind(copyRestangularizedElement, service);
            service.service = bind(toService, service);
            service.withConfig = bind(withConfigurationFunction, service);
            service.one = bind(one, service, null);
            service.all = bind(all, service, null);
            service.several = bind(several, service, null);
            service.oneUrl = bind(oneUrl, service, null);
            service.allUrl = bind(allUrl, service, null);
            service.stripRestangular = bind(stripRestangular, service);
            service.restangularizeElement = bind(restangularizeElem, service);
            service.restangularizeCollection = bind(restangularizeCollectionAndElements, service);
            return service;
        }
        return createServiceForConfiguration(globalConfiguration);
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
/** @type {?} */
var CONFIG_OBJ = new InjectionToken('configObj');
var RestangularModule = /** @class */ (function () {
    function RestangularModule(parentModule) {
        if (parentModule) {
            throw new Error('RestangularModule is already loaded. Import it in the AppModule only');
        }
    }
    /**
     * @param {?=} config1
     * @param {?=} config2
     * @return {?}
     */
    RestangularModule.forRoot = /**
     * @param {?=} config1
     * @param {?=} config2
     * @return {?}
     */
    function (config1, config2) {
        return {
            ngModule: RestangularModule,
            providers: [
                { provide: CONFIG_OBJ, useValue: [config1, config2] },
                { provide: RESTANGULAR, useFactory: RestangularFactory, deps: [CONFIG_OBJ] },
            ]
        };
    };
    RestangularModule.decorators = [
        { type: NgModule, args: [{
                    imports: [HttpClientModule],
                    providers: [RestangularHttp, Restangular]
                },] },
    ];
    /** @nocollapse */
    RestangularModule.ctorParameters = function () { return [
        { type: RestangularModule, decorators: [{ type: Optional }, { type: SkipSelf }] }
    ]; };
    return RestangularModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */

export { RestangularModule, Restangular, RestangularHttp, RESTANGULAR as ɵb, RestangularFactory as ɵc, CONFIG_OBJ as ɵa };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmd4LXJlc3Rhbmd1bGFyLmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9uZ3gtcmVzdGFuZ3VsYXIvbGliL25neC1yZXN0YW5ndWxhci5jb25maWcudHMiLCJuZzovL25neC1yZXN0YW5ndWxhci9saWIvbmd4LXJlc3Rhbmd1bGFyLWhlbHBlci50cyIsIm5nOi8vbmd4LXJlc3Rhbmd1bGFyL2xpYi9uZ3gtcmVzdGFuZ3VsYXItaHR0cC50cyIsIm5nOi8vbmd4LXJlc3Rhbmd1bGFyL2xpYi9uZ3gtcmVzdGFuZ3VsYXItY29uZmlnLmZhY3RvcnkudHMiLCJuZzovL25neC1yZXN0YW5ndWxhci9saWIvbmd4LXJlc3Rhbmd1bGFyLnRzIiwibmc6Ly9uZ3gtcmVzdGFuZ3VsYXIvbGliL25neC1yZXN0YW5ndWxhci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0aW9uVG9rZW4gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgaXNBcnJheSB9IGZyb20gJ2xvZGFzaCc7XG5cblxuZXhwb3J0IGNvbnN0IFJFU1RBTkdVTEFSID0gbmV3IEluamVjdGlvblRva2VuPHN0cmluZz4oJ3Jlc3Rhbmd1bGFyV2l0aENvbmZpZycpO1xuXG5leHBvcnQgZnVuY3Rpb24gUmVzdGFuZ3VsYXJGYWN0b3J5KFtjYWxsYmFja09yU2VydmljZXMsIGNhbGxiYWNrXSkge1xuICBsZXQgYXJyU2VydmljZXMgPSBbXTtcbiAgbGV0IGZuID0gY2FsbGJhY2tPclNlcnZpY2VzO1xuXG4gIGlmIChpc0FycmF5KGNhbGxiYWNrT3JTZXJ2aWNlcykpIHtcbiAgICBhcnJTZXJ2aWNlcyA9IGNhbGxiYWNrT3JTZXJ2aWNlcztcbiAgICBmbiA9IGNhbGxiYWNrO1xuICB9XG5cbiAgcmV0dXJuIHtmbiwgYXJyU2VydmljZXN9O1xufVxuIiwiaW1wb3J0IHsgSHR0cFJlcXVlc3QsIEh0dHBIZWFkZXJzLCBIdHRwUGFyYW1zIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuXG5pbXBvcnQgeyBhc3NpZ24gfSBmcm9tICdjb3JlLWpzL2ZuL29iamVjdCc7XG5cbmV4cG9ydCBjbGFzcyBSZXN0YW5ndWxhckhlbHBlciB7XG5cbiAgc3RhdGljIGNyZWF0ZVJlcXVlc3Qob3B0aW9ucykge1xuICAgIGNvbnN0IHJlcXVlc3RRdWVyeVBhcmFtcyA9IFJlc3Rhbmd1bGFySGVscGVyLmNyZWF0ZVJlcXVlc3RRdWVyeVBhcmFtcyhvcHRpb25zLnBhcmFtcyk7XG4gICAgY29uc3QgcmVxdWVzdEhlYWRlcnMgPSBSZXN0YW5ndWxhckhlbHBlci5jcmVhdGVSZXF1ZXN0SGVhZGVycyhvcHRpb25zLmhlYWRlcnMpO1xuICAgIGNvbnN0IG1ldGhvZE5hbWUgPSBvcHRpb25zLm1ldGhvZC50b1VwcGVyQ2FzZSgpO1xuICAgIGNvbnN0IHdpdGhDcmVkZW50aWFscyA9IG9wdGlvbnMud2l0aENyZWRlbnRpYWxzIHx8IGZhbHNlO1xuXG4gICAgbGV0IHJlcXVlc3QgPSBuZXcgSHR0cFJlcXVlc3QoXG4gICAgICBtZXRob2ROYW1lLFxuICAgICAgb3B0aW9ucy51cmwsXG4gICAgICBvcHRpb25zLmRhdGEsXG4gICAgICB7XG4gICAgICAgIGhlYWRlcnM6IHJlcXVlc3RIZWFkZXJzLFxuICAgICAgICBwYXJhbXM6IHJlcXVlc3RRdWVyeVBhcmFtcyxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiBvcHRpb25zLnJlc3BvbnNlVHlwZSxcbiAgICAgICAgd2l0aENyZWRlbnRpYWxzXG4gICAgICB9XG4gICAgKTtcblxuICAgIGlmIChbJ0dFVCcsICdERUxFVEUnLCAnSEVBRCcsICdKU09OUCcsICdPUFRJT05TJ10uaW5kZXhPZihtZXRob2ROYW1lKSA+PSAwKSB7XG4gICAgICByZXF1ZXN0ID0gbmV3IEh0dHBSZXF1ZXN0KFxuICAgICAgICBtZXRob2ROYW1lLFxuICAgICAgICBvcHRpb25zLnVybCxcbiAgICAgICAge1xuICAgICAgICAgIGhlYWRlcnM6IHJlcXVlc3RIZWFkZXJzLFxuICAgICAgICAgIHBhcmFtczogcmVxdWVzdFF1ZXJ5UGFyYW1zLFxuICAgICAgICAgIHJlc3BvbnNlVHlwZTogb3B0aW9ucy5yZXNwb25zZVR5cGUsXG4gICAgICAgICAgd2l0aENyZWRlbnRpYWxzXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiByZXF1ZXN0O1xuICB9XG5cbiAgc3RhdGljIGNyZWF0ZVJlcXVlc3RRdWVyeVBhcmFtcyhxdWVyeVBhcmFtcykge1xuICAgIGNvbnN0IHJlcXVlc3RRdWVyeVBhcmFtcyA9IGFzc2lnbih7fSwgcXVlcnlQYXJhbXMpO1xuICAgIGxldCBzZWFyY2g6IEh0dHBQYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpO1xuXG4gICAgZm9yIChjb25zdCBrZXkgaW4gcmVxdWVzdFF1ZXJ5UGFyYW1zKSB7XG4gICAgICBsZXQgdmFsdWU6IGFueSA9IHJlcXVlc3RRdWVyeVBhcmFtc1trZXldO1xuXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgdmFsdWUuZm9yRWFjaChmdW5jdGlvbiAodmFsKSB7XG4gICAgICAgICAgc2VhcmNoID0gc2VhcmNoLmFwcGVuZChrZXksIHZhbCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICB2YWx1ZSA9IEpTT04uc3RyaW5naWZ5KHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBzZWFyY2ggPSBzZWFyY2guYXBwZW5kKGtleSwgdmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzZWFyY2g7XG4gIH1cblxuICBzdGF0aWMgY3JlYXRlUmVxdWVzdEhlYWRlcnMoaGVhZGVycykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGhlYWRlcnMpIHtcbiAgICAgIGNvbnN0IHZhbHVlOiBhbnkgPSBoZWFkZXJzW2tleV07XG4gICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICBkZWxldGUgaGVhZGVyc1trZXldO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgSHR0cEhlYWRlcnMoYXNzaWduKHt9LCBoZWFkZXJzKSk7XG4gIH1cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBCYWNrZW5kLCBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cFJlcXVlc3QsIEh0dHBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcblxuaW1wb3J0IHsgdGhyb3dFcnJvciwgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBSZXN0YW5ndWxhckhlbHBlciB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLWhlbHBlcic7XG5pbXBvcnQgeyBjYXRjaEVycm9yLCBmaWx0ZXIsIG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IEh0dHBFdmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwL3NyYy9yZXNwb25zZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBSZXN0YW5ndWxhckh0dHAge1xuXG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBodHRwOiBIdHRwQmFja2VuZCkge1xuICB9XG5cbiAgY3JlYXRlUmVxdWVzdChvcHRpb25zKTogT2JzZXJ2YWJsZTxIdHRwRXZlbnQ8YW55Pj4ge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBSZXN0YW5ndWxhckhlbHBlci5jcmVhdGVSZXF1ZXN0KG9wdGlvbnMpO1xuXG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChyZXF1ZXN0KTtcbiAgfVxuXG4gIHJlcXVlc3QocmVxdWVzdDogSHR0cFJlcXVlc3Q8YW55Pik6IE9ic2VydmFibGU8SHR0cEV2ZW50PGFueT4+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLmhhbmRsZShyZXF1ZXN0KVxuICAgIC5waXBlKFxuICAgICAgZmlsdGVyKGV2ZW50ID0+IGV2ZW50IGluc3RhbmNlb2YgSHR0cFJlc3BvbnNlKSxcbiAgICAgIG1hcCgocmVzcG9uc2U6IGFueSkgPT4ge1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgcmV0dXJuIHRocm93RXJyb3IobmV3IEh0dHBFcnJvclJlc3BvbnNlKHJlc3BvbnNlKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSksXG4gICAgICBtYXAocmVzcG9uc2UgPT4ge1xuICAgICAgICByZXNwb25zZS5jb25maWcgPSB7cGFyYW1zOiByZXF1ZXN0fTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfSksXG4gICAgICBjYXRjaEVycm9yKGVyciA9PiB7XG4gICAgICAgIGVyci5yZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICAgICAgZXJyLmRhdGEgPSBlcnIuZXJyb3I7XG4gICAgICAgIGVyci5yZXBlYXRSZXF1ZXN0ID0gKG5ld1JlcXVlc3Q/KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChuZXdSZXF1ZXN0IHx8IHJlcXVlc3QpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiB0aHJvd0Vycm9yKGVycik7XG4gICAgICB9KVxuICAgICk7XG4gIH1cbn1cblxuIiwiaW1wb3J0IHtcbiAgaW5jbHVkZXMsXG4gIGlzVW5kZWZpbmVkLFxuICBpc051bGwsXG4gIGlzQXJyYXksXG4gIGlzT2JqZWN0LFxuICBpc0Jvb2xlYW4sXG4gIGRlZmF1bHRzLFxuICBlYWNoLFxuICBleHRlbmQsXG4gIGZpbmQsXG4gIGhhcyxcbiAgaW5pdGlhbCxcbiAgbGFzdCxcbiAgY2xvbmUsXG4gIHJlZHVjZSxcbiAga2V5cyxcbiAgaXNFbXB0eSxcbiAgZm9yRWFjaCxcbn0gZnJvbSAnbG9kYXNoJztcblxuZXhwb3J0IGZ1bmN0aW9uIFJlc3Rhbmd1bGFyQ29uZmlndXJlcihvYmplY3QsIGNvbmZpZ3VyYXRpb24pIHtcbiAgb2JqZWN0LmNvbmZpZ3VyYXRpb24gPSBjb25maWd1cmF0aW9uO1xuXG4gIC8qKlxuICAgKiBUaG9zZSBhcmUgSFRUUCBzYWZlIG1ldGhvZHMgZm9yIHdoaWNoIHRoZXJlIGlzIG5vIG5lZWQgdG8gcGFzcyBhbnkgZGF0YSB3aXRoIHRoZSByZXF1ZXN0LlxuICAgKi9cbiAgY29uc3Qgc2FmZU1ldGhvZHMgPSBbJ2dldCcsICdoZWFkJywgJ29wdGlvbnMnLCAndHJhY2UnLCAnZ2V0bGlzdCddO1xuICBjb25maWd1cmF0aW9uLmlzU2FmZSA9IGZ1bmN0aW9uIChvcGVyYXRpb24pIHtcbiAgICByZXR1cm4gaW5jbHVkZXMoc2FmZU1ldGhvZHMsIG9wZXJhdGlvbi50b0xvd2VyQ2FzZSgpKTtcbiAgfTtcblxuICBjb25zdCBhYnNvbHV0ZVBhdHRlcm4gPSAvXmh0dHBzPzpcXC9cXC8vaTtcbiAgY29uZmlndXJhdGlvbi5pc0Fic29sdXRlVXJsID0gZnVuY3Rpb24gKHN0cmluZykge1xuICAgIHJldHVybiBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLmFic29sdXRlVXJsKSB8fCBpc051bGwoY29uZmlndXJhdGlvbi5hYnNvbHV0ZVVybCkgP1xuICAgICAgc3RyaW5nICYmIGFic29sdXRlUGF0dGVybi50ZXN0KHN0cmluZykgOlxuICAgICAgY29uZmlndXJhdGlvbi5hYnNvbHV0ZVVybDtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmFic29sdXRlVXJsID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5hYnNvbHV0ZVVybCkgPyB0cnVlIDogY29uZmlndXJhdGlvbi5hYnNvbHV0ZVVybDtcbiAgb2JqZWN0LnNldFNlbGZMaW5rQWJzb2x1dGVVcmwgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICBjb25maWd1cmF0aW9uLmFic29sdXRlVXJsID0gdmFsdWU7XG4gIH07XG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSBCYXNlVVJMIHRvIGJlIHVzZWQgd2l0aCBSZXN0YW5ndWxhclxuICAgKi9cbiAgY29uZmlndXJhdGlvbi5iYXNlVXJsID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5iYXNlVXJsKSA/ICcnIDogY29uZmlndXJhdGlvbi5iYXNlVXJsO1xuICBvYmplY3Quc2V0QmFzZVVybCA9IGZ1bmN0aW9uIChuZXdCYXNlVXJsKSB7XG4gICAgY29uZmlndXJhdGlvbi5iYXNlVXJsID0gL1xcLyQvLnRlc3QobmV3QmFzZVVybCkgP1xuICAgICAgbmV3QmFzZVVybC5zdWJzdHJpbmcoMCwgbmV3QmFzZVVybC5sZW5ndGggLSAxKSA6XG4gICAgICBuZXdCYXNlVXJsO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBleHRyYSBmaWVsZHMgdG8ga2VlcCBmcm9tIHRoZSBwYXJlbnRzXG4gICAqL1xuICBjb25maWd1cmF0aW9uLmV4dHJhRmllbGRzID0gY29uZmlndXJhdGlvbi5leHRyYUZpZWxkcyB8fCBbXTtcbiAgb2JqZWN0LnNldEV4dHJhRmllbGRzID0gZnVuY3Rpb24gKG5ld0V4dHJhRmllbGRzKSB7XG4gICAgY29uZmlndXJhdGlvbi5leHRyYUZpZWxkcyA9IG5ld0V4dHJhRmllbGRzO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIC8qKlxuICAgKiBTb21lIGRlZmF1bHQgJGh0dHAgcGFyYW1ldGVyIHRvIGJlIHVzZWQgaW4gRVZFUlkgY2FsbFxuICAgKiovXG4gIGNvbmZpZ3VyYXRpb24uZGVmYXVsdEh0dHBGaWVsZHMgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRIdHRwRmllbGRzIHx8IHt9O1xuICBvYmplY3Quc2V0RGVmYXVsdEh0dHBGaWVsZHMgPSBmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgY29uZmlndXJhdGlvbi5kZWZhdWx0SHR0cEZpZWxkcyA9IHZhbHVlcztcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICAvKipcbiAgICogQWx3YXlzIHJldHVybiBwbGFpbiBkYXRhLCBubyByZXN0YW5ndWxhcml6ZWQgb2JqZWN0XG4gICAqKi9cbiAgY29uZmlndXJhdGlvbi5wbGFpbkJ5RGVmYXVsdCA9IGNvbmZpZ3VyYXRpb24ucGxhaW5CeURlZmF1bHQgfHwgZmFsc2U7XG4gIG9iamVjdC5zZXRQbGFpbkJ5RGVmYXVsdCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIGNvbmZpZ3VyYXRpb24ucGxhaW5CeURlZmF1bHQgPSB2YWx1ZSA9PT0gdHJ1ZSA/IHRydWUgOiBmYWxzZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLndpdGhIdHRwVmFsdWVzID0gZnVuY3Rpb24gKGh0dHBMb2NhbENvbmZpZywgb2JqKSB7XG4gICAgcmV0dXJuIGRlZmF1bHRzKG9iaiwgaHR0cExvY2FsQ29uZmlnLCBjb25maWd1cmF0aW9uLmRlZmF1bHRIdHRwRmllbGRzKTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmVuY29kZUlkcyA9IGlzVW5kZWZpbmVkKGNvbmZpZ3VyYXRpb24uZW5jb2RlSWRzKSA/IHRydWUgOiBjb25maWd1cmF0aW9uLmVuY29kZUlkcztcbiAgb2JqZWN0LnNldEVuY29kZUlkcyA9IGZ1bmN0aW9uIChlbmNvZGUpIHtcbiAgICBjb25maWd1cmF0aW9uLmVuY29kZUlkcyA9IGVuY29kZTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXF1ZXN0UGFyYW1zID0gY29uZmlndXJhdGlvbi5kZWZhdWx0UmVxdWVzdFBhcmFtcyB8fCB7XG4gICAgZ2V0OiB7fSxcbiAgICBwb3N0OiB7fSxcbiAgICBwdXQ6IHt9LFxuICAgIHJlbW92ZToge30sXG4gICAgY29tbW9uOiB7fVxuICB9O1xuXG4gIG9iamVjdC5zZXREZWZhdWx0UmVxdWVzdFBhcmFtcyA9IGZ1bmN0aW9uIChwYXJhbTEsIHBhcmFtMikge1xuICAgIGxldCBtZXRob2RzID0gW107XG4gICAgY29uc3QgcGFyYW1zID0gcGFyYW0yIHx8IHBhcmFtMTtcbiAgICBpZiAoIWlzVW5kZWZpbmVkKHBhcmFtMikpIHtcbiAgICAgIGlmIChpc0FycmF5KHBhcmFtMSkpIHtcbiAgICAgICAgbWV0aG9kcyA9IHBhcmFtMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1ldGhvZHMucHVzaChwYXJhbTEpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBtZXRob2RzLnB1c2goJ2NvbW1vbicpO1xuICAgIH1cblxuICAgIGVhY2gobWV0aG9kcywgZnVuY3Rpb24gKG1ldGhvZCkge1xuICAgICAgY29uZmlndXJhdGlvbi5kZWZhdWx0UmVxdWVzdFBhcmFtc1ttZXRob2RdID0gcGFyYW1zO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIG9iamVjdC5yZXF1ZXN0UGFyYW1zID0gY29uZmlndXJhdGlvbi5kZWZhdWx0UmVxdWVzdFBhcmFtcztcblxuICBjb25maWd1cmF0aW9uLmRlZmF1bHRIZWFkZXJzID0gY29uZmlndXJhdGlvbi5kZWZhdWx0SGVhZGVycyB8fCB7fTtcbiAgb2JqZWN0LnNldERlZmF1bHRIZWFkZXJzID0gZnVuY3Rpb24gKGhlYWRlcnMpIHtcbiAgICBjb25maWd1cmF0aW9uLmRlZmF1bHRIZWFkZXJzID0gaGVhZGVycztcbiAgICBvYmplY3QuZGVmYXVsdEhlYWRlcnMgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRIZWFkZXJzO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIG9iamVjdC5kZWZhdWx0SGVhZGVycyA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdEhlYWRlcnM7XG5cblxuICAvKipcbiAgICogTWV0aG9kIG92ZXJyaWRlcnMgcmVzcG9uc2UgTWV0aG9kXG4gICAqKi9cbiAgY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VNZXRob2QgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXNwb25zZU1ldGhvZCB8fCAncHJvbWlzZSc7XG4gIG9iamVjdC5zZXREZWZhdWx0UmVzcG9uc2VNZXRob2QgPSBmdW5jdGlvbiAobWV0aG9kKSB7XG4gICAgY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VNZXRob2QgPSBtZXRob2Q7XG4gICAgb2JqZWN0LmRlZmF1bHRSZXNwb25zZU1ldGhvZCA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdFJlc3BvbnNlTWV0aG9kO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuICBvYmplY3QuZGVmYXVsdFJlc3BvbnNlTWV0aG9kID0gY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VNZXRob2Q7XG5cbiAgLyoqXG4gICAqIE1ldGhvZCBvdmVycmlkZXJzIHdpbGwgc2V0IHdoaWNoIG1ldGhvZHMgYXJlIHNlbnQgdmlhIFBPU1Qgd2l0aCBhbiBYLUhUVFAtTWV0aG9kLU92ZXJyaWRlXG4gICAqKi9cbiAgY29uZmlndXJhdGlvbi5tZXRob2RPdmVycmlkZXJzID0gY29uZmlndXJhdGlvbi5tZXRob2RPdmVycmlkZXJzIHx8IFtdO1xuICBvYmplY3Quc2V0TWV0aG9kT3ZlcnJpZGVycyA9IGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICBjb25zdCBvdmVycmlkZXJzID0gZXh0ZW5kKFtdLCB2YWx1ZXMpO1xuICAgIGlmIChjb25maWd1cmF0aW9uLmlzT3ZlcnJpZGVuTWV0aG9kKCdkZWxldGUnLCBvdmVycmlkZXJzKSkge1xuICAgICAgb3ZlcnJpZGVycy5wdXNoKCdyZW1vdmUnKTtcbiAgICB9XG4gICAgY29uZmlndXJhdGlvbi5tZXRob2RPdmVycmlkZXJzID0gb3ZlcnJpZGVycztcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmpzb25wID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5qc29ucCkgPyBmYWxzZSA6IGNvbmZpZ3VyYXRpb24uanNvbnA7XG4gIG9iamVjdC5zZXRKc29ucCA9IGZ1bmN0aW9uIChhY3RpdmUpIHtcbiAgICBjb25maWd1cmF0aW9uLmpzb25wID0gYWN0aXZlO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uaXNPdmVycmlkZW5NZXRob2QgPSBmdW5jdGlvbiAobWV0aG9kLCB2YWx1ZXMpIHtcbiAgICBjb25zdCBzZWFyY2ggPSB2YWx1ZXMgfHwgY29uZmlndXJhdGlvbi5tZXRob2RPdmVycmlkZXJzO1xuICAgIHJldHVybiAhaXNVbmRlZmluZWQoZmluZChzZWFyY2gsIGZ1bmN0aW9uIChvbmU6IHN0cmluZykge1xuICAgICAgcmV0dXJuIG9uZS50b0xvd2VyQ2FzZSgpID09PSBtZXRob2QudG9Mb3dlckNhc2UoKTtcbiAgICB9KSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIFVSTCBjcmVhdG9yIHR5cGUuIEZvciBub3csIG9ubHkgUGF0aCBpcyBjcmVhdGVkLiBJbiB0aGUgZnV0dXJlIHdlJ2xsIGhhdmUgcXVlcnlQYXJhbXNcbiAgICoqL1xuICBjb25maWd1cmF0aW9uLnVybENyZWF0b3IgPSBjb25maWd1cmF0aW9uLnVybENyZWF0b3IgfHwgJ3BhdGgnO1xuICBvYmplY3Quc2V0VXJsQ3JlYXRvciA9IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgaWYgKCFoYXMoY29uZmlndXJhdGlvbi51cmxDcmVhdG9yRmFjdG9yeSwgbmFtZSkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVVJMIFBhdGggc2VsZWN0ZWQgaXNuXFwndCB2YWxpZCcpO1xuICAgIH1cblxuICAgIGNvbmZpZ3VyYXRpb24udXJsQ3JlYXRvciA9IG5hbWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFlvdSBjYW4gc2V0IHRoZSByZXN0YW5ndWxhciBmaWVsZHMgaGVyZS4gVGhlIDMgcmVxdWlyZWQgZmllbGRzIGZvciBSZXN0YW5ndWxhciBhcmU6XG4gICAqXG4gICAqIGlkOiBJZCBvZiB0aGUgZWxlbWVudFxuICAgKiByb3V0ZTogbmFtZSBvZiB0aGUgcm91dGUgb2YgdGhpcyBlbGVtZW50XG4gICAqIHBhcmVudFJlc291cmNlOiB0aGUgcmVmZXJlbmNlIHRvIHRoZSBwYXJlbnQgcmVzb3VyY2VcbiAgICpcbiAgICogIEFsbCBvZiB0aGlzIGZpZWxkcyBleGNlcHQgZm9yIGlkLCBhcmUgaGFuZGxlZCAoYW5kIGNyZWF0ZWQpIGJ5IFJlc3Rhbmd1bGFyLiBCeSBkZWZhdWx0LFxuICAgKiAgdGhlIGZpZWxkIHZhbHVlcyB3aWxsIGJlIGlkLCByb3V0ZSBhbmQgcGFyZW50UmVzb3VyY2UgcmVzcGVjdGl2ZWx5XG4gICAqL1xuICBjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzID0gY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcyB8fCB7XG4gICAgaWQ6ICdpZCcsXG4gICAgcm91dGU6ICdyb3V0ZScsXG4gICAgcGFyZW50UmVzb3VyY2U6ICdwYXJlbnRSZXNvdXJjZScsXG4gICAgcmVzdGFuZ3VsYXJDb2xsZWN0aW9uOiAncmVzdGFuZ3VsYXJDb2xsZWN0aW9uJyxcbiAgICBjYW5ub25pY2FsSWQ6ICdfX2Nhbm5vbmljYWxJZCcsXG4gICAgZXRhZzogJ3Jlc3Rhbmd1bGFyRXRhZycsXG4gICAgc2VsZkxpbms6ICdocmVmJyxcbiAgICBnZXQ6ICdnZXQnLFxuICAgIGdldExpc3Q6ICdnZXRMaXN0JyxcbiAgICBwdXQ6ICdwdXQnLFxuICAgIHBvc3Q6ICdwb3N0JyxcbiAgICByZW1vdmU6ICdyZW1vdmUnLFxuICAgIGhlYWQ6ICdoZWFkJyxcbiAgICB0cmFjZTogJ3RyYWNlJyxcbiAgICBvcHRpb25zOiAnb3B0aW9ucycsXG4gICAgcGF0Y2g6ICdwYXRjaCcsXG4gICAgZ2V0UmVzdGFuZ3VsYXJVcmw6ICdnZXRSZXN0YW5ndWxhclVybCcsXG4gICAgZ2V0UmVxdWVzdGVkVXJsOiAnZ2V0UmVxdWVzdGVkVXJsJyxcbiAgICBwdXRFbGVtZW50OiAncHV0RWxlbWVudCcsXG4gICAgYWRkUmVzdGFuZ3VsYXJNZXRob2Q6ICdhZGRSZXN0YW5ndWxhck1ldGhvZCcsXG4gICAgZ2V0UGFyZW50TGlzdDogJ2dldFBhcmVudExpc3QnLFxuICAgIGNsb25lOiAnY2xvbmUnLFxuICAgIGlkczogJ2lkcycsXG4gICAgaHR0cENvbmZpZzogJ18kaHR0cENvbmZpZycsXG4gICAgcmVxUGFyYW1zOiAncmVxUGFyYW1zJyxcbiAgICBvbmU6ICdvbmUnLFxuICAgIGFsbDogJ2FsbCcsXG4gICAgc2V2ZXJhbDogJ3NldmVyYWwnLFxuICAgIG9uZVVybDogJ29uZVVybCcsXG4gICAgYWxsVXJsOiAnYWxsVXJsJyxcbiAgICBjdXN0b21QVVQ6ICdjdXN0b21QVVQnLFxuICAgIGN1c3RvbVBBVENIOiAnY3VzdG9tUEFUQ0gnLFxuICAgIGN1c3RvbVBPU1Q6ICdjdXN0b21QT1NUJyxcbiAgICBjdXN0b21ERUxFVEU6ICdjdXN0b21ERUxFVEUnLFxuICAgIGN1c3RvbUdFVDogJ2N1c3RvbUdFVCcsXG4gICAgY3VzdG9tR0VUTElTVDogJ2N1c3RvbUdFVExJU1QnLFxuICAgIGN1c3RvbU9wZXJhdGlvbjogJ2N1c3RvbU9wZXJhdGlvbicsXG4gICAgZG9QVVQ6ICdkb1BVVCcsXG4gICAgZG9QQVRDSDogJ2RvUEFUQ0gnLFxuICAgIGRvUE9TVDogJ2RvUE9TVCcsXG4gICAgZG9ERUxFVEU6ICdkb0RFTEVURScsXG4gICAgZG9HRVQ6ICdkb0dFVCcsXG4gICAgZG9HRVRMSVNUOiAnZG9HRVRMSVNUJyxcbiAgICBmcm9tU2VydmVyOiAnZnJvbVNlcnZlcicsXG4gICAgd2l0aENvbmZpZzogJ3dpdGhDb25maWcnLFxuICAgIHdpdGhIdHRwQ29uZmlnOiAnd2l0aEh0dHBDb25maWcnLFxuICAgIHNpbmdsZU9uZTogJ3NpbmdsZU9uZScsXG4gICAgcGxhaW46ICdwbGFpbicsXG4gICAgc2F2ZTogJ3NhdmUnLFxuICAgIHJlc3Rhbmd1bGFyaXplZDogJ3Jlc3Rhbmd1bGFyaXplZCdcbiAgfTtcbiAgb2JqZWN0LnNldFJlc3Rhbmd1bGFyRmllbGRzID0gZnVuY3Rpb24gKHJlc0ZpZWxkcykge1xuICAgIGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMgPVxuICAgICAgZXh0ZW5kKHt9LCBjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzLCByZXNGaWVsZHMpO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uaXNSZXN0YW5ndWxhcml6ZWQgPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgcmV0dXJuICEhb2JqW2NvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMucmVzdGFuZ3VsYXJpemVkXTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLnNldEZpZWxkVG9FbGVtID0gZnVuY3Rpb24gKGZpZWxkLCBlbGVtLCB2YWx1ZSkge1xuICAgIGNvbnN0IHByb3BlcnRpZXMgPSBmaWVsZC5zcGxpdCgnLicpO1xuICAgIGxldCBpZFZhbHVlID0gZWxlbTtcbiAgICBlYWNoKGluaXRpYWwocHJvcGVydGllcyksIGZ1bmN0aW9uIChwcm9wOiBhbnkpIHtcbiAgICAgIGlkVmFsdWVbcHJvcF0gPSB7fTtcbiAgICAgIGlkVmFsdWUgPSBpZFZhbHVlW3Byb3BdO1xuICAgIH0pO1xuICAgIGNvbnN0IGluZGV4OiBhbnkgPSBsYXN0KHByb3BlcnRpZXMpO1xuICAgIGlkVmFsdWVbaW5kZXhdID0gdmFsdWU7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5nZXRGaWVsZEZyb21FbGVtID0gZnVuY3Rpb24gKGZpZWxkLCBlbGVtKSB7XG4gICAgY29uc3QgcHJvcGVydGllcyA9IGZpZWxkLnNwbGl0KCcuJyk7XG4gICAgbGV0IGlkVmFsdWU6IGFueSA9IGVsZW07XG4gICAgZWFjaChwcm9wZXJ0aWVzLCBmdW5jdGlvbiAocHJvcCkge1xuICAgICAgaWYgKGlkVmFsdWUpIHtcbiAgICAgICAgaWRWYWx1ZSA9IGlkVmFsdWVbcHJvcF07XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGNsb25lKGlkVmFsdWUpO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uc2V0SWRUb0VsZW0gPSBmdW5jdGlvbiAoZWxlbSwgaWQgLyosIHJvdXRlICovKSB7XG4gICAgY29uZmlndXJhdGlvbi5zZXRGaWVsZFRvRWxlbShjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzLmlkLCBlbGVtLCBpZCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5nZXRJZEZyb21FbGVtID0gZnVuY3Rpb24gKGVsZW0pIHtcbiAgICByZXR1cm4gY29uZmlndXJhdGlvbi5nZXRGaWVsZEZyb21FbGVtKGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMuaWQsIGVsZW0pO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uaXNWYWxpZElkID0gZnVuY3Rpb24gKGVsZW1JZCkge1xuICAgIHJldHVybiAnJyAhPT0gZWxlbUlkICYmICFpc1VuZGVmaW5lZChlbGVtSWQpICYmICFpc051bGwoZWxlbUlkKTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLnNldFVybFRvRWxlbSA9IGZ1bmN0aW9uIChlbGVtLCB1cmwgLyosIHJvdXRlICovKSB7XG4gICAgY29uZmlndXJhdGlvbi5zZXRGaWVsZFRvRWxlbShjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzLnNlbGZMaW5rLCBlbGVtLCB1cmwpO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZ2V0VXJsRnJvbUVsZW0gPSBmdW5jdGlvbiAoZWxlbSkge1xuICAgIHJldHVybiBjb25maWd1cmF0aW9uLmdldEZpZWxkRnJvbUVsZW0oY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5zZWxmTGluaywgZWxlbSk7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi51c2VDYW5ub25pY2FsSWQgPSBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLnVzZUNhbm5vbmljYWxJZCkgPyBmYWxzZSA6IGNvbmZpZ3VyYXRpb24udXNlQ2Fubm9uaWNhbElkO1xuICBvYmplY3Quc2V0VXNlQ2Fubm9uaWNhbElkID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgY29uZmlndXJhdGlvbi51c2VDYW5ub25pY2FsSWQgPSB2YWx1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmdldENhbm5vbmljYWxJZEZyb21FbGVtID0gZnVuY3Rpb24gKGVsZW0pIHtcbiAgICBjb25zdCBjYW5ub25pY2FsSWQgPSBlbGVtW2NvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMuY2Fubm9uaWNhbElkXTtcbiAgICBjb25zdCBhY3R1YWxJZCA9IGNvbmZpZ3VyYXRpb24uaXNWYWxpZElkKGNhbm5vbmljYWxJZCkgPyBjYW5ub25pY2FsSWQgOiBjb25maWd1cmF0aW9uLmdldElkRnJvbUVsZW0oZWxlbSk7XG4gICAgcmV0dXJuIGFjdHVhbElkO1xuICB9O1xuXG4gIC8qKlxuICAgKiBTZXRzIHRoZSBSZXNwb25zZSBwYXJzZXIuIFRoaXMgaXMgdXNlZCBpbiBjYXNlIHlvdXIgcmVzcG9uc2UgaXNuJ3QgZGlyZWN0bHkgdGhlIGRhdGEuXG4gICAqIEZvciBleGFtcGxlIGlmIHlvdSBoYXZlIGEgcmVzcG9uc2UgbGlrZSB7bWV0YTogeydtZXRhJ30sIGRhdGE6IHtuYW1lOiAnR29udG8nfX1cbiAgICogeW91IGNhbiBleHRyYWN0IHRoaXMgZGF0YSB3aGljaCBpcyB0aGUgb25lIHRoYXQgbmVlZHMgd3JhcHBpbmdcbiAgICpcbiAgICogVGhlIFJlc3BvbnNlRXh0cmFjdG9yIGlzIGEgZnVuY3Rpb24gdGhhdCByZWNlaXZlcyB0aGUgcmVzcG9uc2UgYW5kIHRoZSBtZXRob2QgZXhlY3V0ZWQuXG4gICAqL1xuXG4gIGNvbmZpZ3VyYXRpb24ucmVzcG9uc2VJbnRlcmNlcHRvcnMgPSBjb25maWd1cmF0aW9uLnJlc3BvbnNlSW50ZXJjZXB0b3JzID8gWy4uLmNvbmZpZ3VyYXRpb24ucmVzcG9uc2VJbnRlcmNlcHRvcnNdIDogW107XG5cbiAgY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VJbnRlcmNlcHRvciA9IGZ1bmN0aW9uIChkYXRhIC8qLCBvcGVyYXRpb24sIHdoYXQsIHVybCwgcmVzcG9uc2UsIHN1YmplY3QgKi8pIHtcbiAgICByZXR1cm4gZGF0YSB8fCB7fTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLnJlc3BvbnNlRXh0cmFjdG9yID0gZnVuY3Rpb24gKGRhdGEsIG9wZXJhdGlvbiwgd2hhdCwgdXJsLCByZXNwb25zZSwgc3ViamVjdCkge1xuICAgIGNvbnN0IGludGVyY2VwdG9ycyA9IGNsb25lKGNvbmZpZ3VyYXRpb24ucmVzcG9uc2VJbnRlcmNlcHRvcnMpO1xuICAgIGludGVyY2VwdG9ycy5wdXNoKGNvbmZpZ3VyYXRpb24uZGVmYXVsdFJlc3BvbnNlSW50ZXJjZXB0b3IpO1xuICAgIGxldCB0aGVEYXRhID0gZGF0YTtcbiAgICBlYWNoKGludGVyY2VwdG9ycywgZnVuY3Rpb24gKGludGVyY2VwdG9yOiBhbnkpIHtcbiAgICAgIHRoZURhdGEgPSBpbnRlcmNlcHRvcih0aGVEYXRhLCBvcGVyYXRpb24sXG4gICAgICAgIHdoYXQsIHVybCwgcmVzcG9uc2UsIHN1YmplY3QpO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGVEYXRhO1xuICB9O1xuXG4gIG9iamVjdC5hZGRSZXNwb25zZUludGVyY2VwdG9yID0gZnVuY3Rpb24gKGV4dHJhY3Rvcikge1xuICAgIGNvbmZpZ3VyYXRpb24ucmVzcG9uc2VJbnRlcmNlcHRvcnMucHVzaChleHRyYWN0b3IpO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZXJyb3JJbnRlcmNlcHRvcnMgPSBjb25maWd1cmF0aW9uLmVycm9ySW50ZXJjZXB0b3JzID8gWy4uLmNvbmZpZ3VyYXRpb24uZXJyb3JJbnRlcmNlcHRvcnNdIDogW107XG4gIG9iamVjdC5hZGRFcnJvckludGVyY2VwdG9yID0gZnVuY3Rpb24gKGludGVyY2VwdG9yKSB7XG4gICAgY29uZmlndXJhdGlvbi5lcnJvckludGVyY2VwdG9ycyA9IFtpbnRlcmNlcHRvciwgLi4uY29uZmlndXJhdGlvbi5lcnJvckludGVyY2VwdG9yc107XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgb2JqZWN0LnNldFJlc3BvbnNlSW50ZXJjZXB0b3IgPSBvYmplY3QuYWRkUmVzcG9uc2VJbnRlcmNlcHRvcjtcbiAgb2JqZWN0LnNldFJlc3BvbnNlRXh0cmFjdG9yID0gb2JqZWN0LmFkZFJlc3BvbnNlSW50ZXJjZXB0b3I7XG4gIG9iamVjdC5zZXRFcnJvckludGVyY2VwdG9yID0gb2JqZWN0LmFkZEVycm9ySW50ZXJjZXB0b3I7XG5cbiAgLyoqXG4gICAqIFJlc3BvbnNlIGludGVyY2VwdG9yIGlzIGNhbGxlZCBqdXN0IGJlZm9yZSByZXNvbHZpbmcgcHJvbWlzZXMuXG4gICAqL1xuXG5cbiAgLyoqXG4gICAqIFJlcXVlc3QgaW50ZXJjZXB0b3IgaXMgY2FsbGVkIGJlZm9yZSBzZW5kaW5nIGFuIG9iamVjdCB0byB0aGUgc2VydmVyLlxuICAgKi9cbiAgY29uZmlndXJhdGlvbi5yZXF1ZXN0SW50ZXJjZXB0b3JzID0gY29uZmlndXJhdGlvbi5yZXF1ZXN0SW50ZXJjZXB0b3JzID8gWy4uLmNvbmZpZ3VyYXRpb24ucmVxdWVzdEludGVyY2VwdG9yc10gOiBbXTtcblxuICBjb25maWd1cmF0aW9uLmRlZmF1bHRJbnRlcmNlcHRvciA9IGZ1bmN0aW9uIChlbGVtZW50LCBvcGVyYXRpb24sIHBhdGgsIHVybCwgaGVhZGVycywgcGFyYW1zLCBodHRwQ29uZmlnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGVsZW1lbnQ6IGVsZW1lbnQsXG4gICAgICBoZWFkZXJzOiBoZWFkZXJzLFxuICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICBodHRwQ29uZmlnOiBodHRwQ29uZmlnXG4gICAgfTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoZWxlbWVudCwgb3BlcmF0aW9uLCBwYXRoLCB1cmwsIGhlYWRlcnMsIHBhcmFtcywgaHR0cENvbmZpZykge1xuICAgIGNvbnN0IGludGVyY2VwdG9ycyA9IGNsb25lKGNvbmZpZ3VyYXRpb24ucmVxdWVzdEludGVyY2VwdG9ycyk7XG4gICAgY29uc3QgZGVmYXVsdFJlcXVlc3QgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRJbnRlcmNlcHRvcihlbGVtZW50LCBvcGVyYXRpb24sIHBhdGgsIHVybCwgaGVhZGVycywgcGFyYW1zLCBodHRwQ29uZmlnKTtcbiAgICByZXR1cm4gcmVkdWNlKGludGVyY2VwdG9ycywgZnVuY3Rpb24gKHJlcXVlc3Q6IGFueSwgaW50ZXJjZXB0b3I6IGFueSkge1xuXG4gICAgICBjb25zdCByZXR1cm5JbnRlcmNlcHRvcjogYW55ID0gaW50ZXJjZXB0b3IoXG4gICAgICAgIHJlcXVlc3QuZWxlbWVudCxcbiAgICAgICAgb3BlcmF0aW9uLFxuICAgICAgICBwYXRoLFxuICAgICAgICB1cmwsXG4gICAgICAgIHJlcXVlc3QuaGVhZGVycyxcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMsXG4gICAgICAgIHJlcXVlc3QuaHR0cENvbmZpZ1xuICAgICAgKTtcbiAgICAgIHJldHVybiBleHRlbmQocmVxdWVzdCwgcmV0dXJuSW50ZXJjZXB0b3IpO1xuICAgIH0sIGRlZmF1bHRSZXF1ZXN0KTtcbiAgfTtcblxuICBvYmplY3QuYWRkUmVxdWVzdEludGVyY2VwdG9yID0gZnVuY3Rpb24gKGludGVyY2VwdG9yKSB7XG4gICAgY29uZmlndXJhdGlvbi5yZXF1ZXN0SW50ZXJjZXB0b3JzLnB1c2goZnVuY3Rpb24gKGVsZW0sIG9wZXJhdGlvbiwgcGF0aCwgdXJsLCBoZWFkZXJzLCBwYXJhbXMsIGh0dHBDb25maWcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXG4gICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICBlbGVtZW50OiBpbnRlcmNlcHRvcihlbGVtLCBvcGVyYXRpb24sIHBhdGgsIHVybCksXG4gICAgICAgIGh0dHBDb25maWc6IGh0dHBDb25maWdcbiAgICAgIH07XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgb2JqZWN0LnNldFJlcXVlc3RJbnRlcmNlcHRvciA9IG9iamVjdC5hZGRSZXF1ZXN0SW50ZXJjZXB0b3I7XG5cbiAgb2JqZWN0LmFkZEZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoaW50ZXJjZXB0b3IpIHtcbiAgICBjb25maWd1cmF0aW9uLnJlcXVlc3RJbnRlcmNlcHRvcnMucHVzaChpbnRlcmNlcHRvcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgb2JqZWN0LnNldEZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3IgPSBvYmplY3QuYWRkRnVsbFJlcXVlc3RJbnRlcmNlcHRvcjtcblxuICBjb25maWd1cmF0aW9uLm9uQmVmb3JlRWxlbVJlc3Rhbmd1bGFyaXplZCA9IGNvbmZpZ3VyYXRpb24ub25CZWZvcmVFbGVtUmVzdGFuZ3VsYXJpemVkIHx8IGZ1bmN0aW9uIChlbGVtKSB7XG4gICAgcmV0dXJuIGVsZW07XG4gIH07XG4gIG9iamVjdC5zZXRPbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQgPSBmdW5jdGlvbiAocG9zdCkge1xuICAgIGNvbmZpZ3VyYXRpb24ub25CZWZvcmVFbGVtUmVzdGFuZ3VsYXJpemVkID0gcG9zdDtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBvYmplY3Quc2V0UmVzdGFuZ3VsYXJpemVQcm9taXNlSW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoaW50ZXJjZXB0b3IpIHtcbiAgICBjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyaXplUHJvbWlzZUludGVyY2VwdG9yID0gaW50ZXJjZXB0b3I7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFRoaXMgbWV0aG9kIGlzIGNhbGxlZCBhZnRlciBhbiBlbGVtZW50IGhhcyBiZWVuIFwiUmVzdGFuZ3VsYXJpemVkXCIuXG4gICAqXG4gICAqIEl0IHJlY2VpdmVzIHRoZSBlbGVtZW50LCBhIGJvb2xlYW4gaW5kaWNhdGluZyBpZiBpdCdzIGFuIGVsZW1lbnQgb3IgYSBjb2xsZWN0aW9uXG4gICAqIGFuZCB0aGUgbmFtZSBvZiB0aGUgbW9kZWxcbiAgICpcbiAgICovXG4gIGNvbmZpZ3VyYXRpb24ub25FbGVtUmVzdGFuZ3VsYXJpemVkID0gY29uZmlndXJhdGlvbi5vbkVsZW1SZXN0YW5ndWxhcml6ZWQgfHwgZnVuY3Rpb24gKGVsZW0pIHtcbiAgICByZXR1cm4gZWxlbTtcbiAgfTtcbiAgb2JqZWN0LnNldE9uRWxlbVJlc3Rhbmd1bGFyaXplZCA9IGZ1bmN0aW9uIChwb3N0KSB7XG4gICAgY29uZmlndXJhdGlvbi5vbkVsZW1SZXN0YW5ndWxhcml6ZWQgPSBwb3N0O1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uc2hvdWxkU2F2ZVBhcmVudCA9IGNvbmZpZ3VyYXRpb24uc2hvdWxkU2F2ZVBhcmVudCB8fCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG4gIG9iamVjdC5zZXRQYXJlbnRsZXNzID0gZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIGlmIChpc0FycmF5KHZhbHVlcykpIHtcbiAgICAgIGNvbmZpZ3VyYXRpb24uc2hvdWxkU2F2ZVBhcmVudCA9IGZ1bmN0aW9uIChyb3V0ZSkge1xuICAgICAgICByZXR1cm4gIWluY2x1ZGVzKHZhbHVlcywgcm91dGUpO1xuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKGlzQm9vbGVhbih2YWx1ZXMpKSB7XG4gICAgICBjb25maWd1cmF0aW9uLnNob3VsZFNhdmVQYXJlbnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAhdmFsdWVzO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFRoaXMgbGV0cyB5b3Ugc2V0IGEgc3VmZml4IHRvIGV2ZXJ5IHJlcXVlc3QuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBpZiB5b3VyIGFwaSByZXF1aXJlcyB0aGF0IGZvciBKU29uIHJlcXVlc3RzIHlvdSBkbyAvdXNlcnMvMTIzLmpzb24sIHlvdSBjYW4gc2V0IHRoYXRcbiAgICogaW4gaGVyZS5cbiAgICpcbiAgICpcbiAgICogQnkgZGVmYXVsdCwgdGhlIHN1ZmZpeCBpcyBudWxsXG4gICAqL1xuICBjb25maWd1cmF0aW9uLnN1ZmZpeCA9IGlzVW5kZWZpbmVkKGNvbmZpZ3VyYXRpb24uc3VmZml4KSA/IG51bGwgOiBjb25maWd1cmF0aW9uLnN1ZmZpeDtcbiAgb2JqZWN0LnNldFJlcXVlc3RTdWZmaXggPSBmdW5jdGlvbiAobmV3U3VmZml4KSB7XG4gICAgY29uZmlndXJhdGlvbi5zdWZmaXggPSBuZXdTdWZmaXg7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIEFkZCBlbGVtZW50IHRyYW5zZm9ybWVycyBmb3IgY2VydGFpbiByb3V0ZXMuXG4gICAqL1xuICBjb25maWd1cmF0aW9uLnRyYW5zZm9ybWVycyA9IGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtZXJzIHx8IHt9O1xuICBvYmplY3QuYWRkRWxlbWVudFRyYW5zZm9ybWVyID0gZnVuY3Rpb24gKHR5cGUsIHNlY29uZEFyZywgdGhpcmRBcmcpIHtcbiAgICBsZXQgaXNDb2xsZWN0aW9uID0gbnVsbDtcbiAgICBsZXQgdHJhbnNmb3JtZXIgPSBudWxsO1xuICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAyKSB7XG4gICAgICB0cmFuc2Zvcm1lciA9IHNlY29uZEFyZztcbiAgICB9IGVsc2Uge1xuICAgICAgdHJhbnNmb3JtZXIgPSB0aGlyZEFyZztcbiAgICAgIGlzQ29sbGVjdGlvbiA9IHNlY29uZEFyZztcbiAgICB9XG5cbiAgICBsZXQgdHlwZVRyYW5zZm9ybWVycyA9IGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtZXJzW3R5cGVdO1xuICAgIGlmICghdHlwZVRyYW5zZm9ybWVycykge1xuICAgICAgdHlwZVRyYW5zZm9ybWVycyA9IGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtZXJzW3R5cGVdID0gW107XG4gICAgfVxuXG4gICAgdHlwZVRyYW5zZm9ybWVycy5wdXNoKGZ1bmN0aW9uIChjb2xsLCBlbGVtKSB7XG4gICAgICBpZiAoaXNOdWxsKGlzQ29sbGVjdGlvbikgfHwgKGNvbGwgPT09IGlzQ29sbGVjdGlvbikpIHtcbiAgICAgICAgcmV0dXJuIHRyYW5zZm9ybWVyKGVsZW0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGVsZW07XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb2JqZWN0O1xuICB9O1xuXG4gIG9iamVjdC5leHRlbmRDb2xsZWN0aW9uID0gZnVuY3Rpb24gKHJvdXRlLCBmbikge1xuICAgIHJldHVybiBvYmplY3QuYWRkRWxlbWVudFRyYW5zZm9ybWVyKHJvdXRlLCB0cnVlLCBmbik7XG4gIH07XG5cbiAgb2JqZWN0LmV4dGVuZE1vZGVsID0gZnVuY3Rpb24gKHJvdXRlLCBmbikge1xuICAgIHJldHVybiBvYmplY3QuYWRkRWxlbWVudFRyYW5zZm9ybWVyKHJvdXRlLCBmYWxzZSwgZm4pO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtRWxlbSA9IGZ1bmN0aW9uIChlbGVtLCBpc0NvbGxlY3Rpb24sIHJvdXRlLCBSZXN0YW5ndWxhciwgZm9yY2UpIHtcbiAgICBpZiAoIWZvcmNlICYmICFjb25maWd1cmF0aW9uLnRyYW5zZm9ybUxvY2FsRWxlbWVudHMgJiYgIWVsZW1bY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5mcm9tU2VydmVyXSkge1xuICAgICAgcmV0dXJuIGVsZW07XG4gICAgfVxuICAgIGNvbnN0IHR5cGVUcmFuc2Zvcm1lcnMgPSBjb25maWd1cmF0aW9uLnRyYW5zZm9ybWVyc1tyb3V0ZV07XG4gICAgbGV0IGNoYW5nZWRFbGVtID0gZWxlbTtcbiAgICBpZiAodHlwZVRyYW5zZm9ybWVycykge1xuICAgICAgZWFjaCh0eXBlVHJhbnNmb3JtZXJzLCBmdW5jdGlvbiAodHJhbnNmb3JtZXI6IChpc0NvbGxlY3Rpb246IGJvb2xlYW4sIGNoYW5nZWRFbGVtOiBhbnkpID0+IGFueSkge1xuICAgICAgICBjaGFuZ2VkRWxlbSA9IHRyYW5zZm9ybWVyKGlzQ29sbGVjdGlvbiwgY2hhbmdlZEVsZW0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBjb25maWd1cmF0aW9uLm9uRWxlbVJlc3Rhbmd1bGFyaXplZChjaGFuZ2VkRWxlbSwgaXNDb2xsZWN0aW9uLCByb3V0ZSwgUmVzdGFuZ3VsYXIpO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtTG9jYWxFbGVtZW50cyA9IGlzVW5kZWZpbmVkKGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtTG9jYWxFbGVtZW50cykgP1xuICAgIGZhbHNlIDpcbiAgICBjb25maWd1cmF0aW9uLnRyYW5zZm9ybUxvY2FsRWxlbWVudHM7XG5cbiAgb2JqZWN0LnNldFRyYW5zZm9ybU9ubHlTZXJ2ZXJFbGVtZW50cyA9IGZ1bmN0aW9uIChhY3RpdmUpIHtcbiAgICBjb25maWd1cmF0aW9uLnRyYW5zZm9ybUxvY2FsRWxlbWVudHMgPSAhYWN0aXZlO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZnVsbFJlc3BvbnNlID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5mdWxsUmVzcG9uc2UpID8gZmFsc2UgOiBjb25maWd1cmF0aW9uLmZ1bGxSZXNwb25zZTtcbiAgb2JqZWN0LnNldEZ1bGxSZXNwb25zZSA9IGZ1bmN0aW9uIChmdWxsKSB7XG4gICAgY29uZmlndXJhdGlvbi5mdWxsUmVzcG9uc2UgPSBmdWxsO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG5cbiAgLy8gSW50ZXJuYWwgdmFsdWVzIGFuZCBmdW5jdGlvbnNcbiAgY29uZmlndXJhdGlvbi51cmxDcmVhdG9yRmFjdG9yeSA9IHt9O1xuXG4gIC8qKlxuICAgKiBCYXNlIFVSTCBDcmVhdG9yLiBCYXNlIHByb3RvdHlwZSBmb3IgZXZlcnl0aGluZyByZWxhdGVkIHRvIGl0XG4gICAqKi9cblxuICBjb25zdCBCYXNlQ3JlYXRvciA9IGZ1bmN0aW9uICgpIHtcbiAgfTtcblxuICBCYXNlQ3JlYXRvci5wcm90b3R5cGUuc2V0Q29uZmlnID0gZnVuY3Rpb24gKGNvbmZpZykge1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIEJhc2VDcmVhdG9yLnByb3RvdHlwZS5wYXJlbnRzQXJyYXkgPSBmdW5jdGlvbiAoY3VycmVudCkge1xuICAgIGNvbnN0IHBhcmVudHMgPSBbXTtcbiAgICB3aGlsZSAoY3VycmVudCkge1xuICAgICAgcGFyZW50cy5wdXNoKGN1cnJlbnQpO1xuICAgICAgY3VycmVudCA9IGN1cnJlbnRbdGhpcy5jb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdO1xuICAgIH1cbiAgICByZXR1cm4gcGFyZW50cy5yZXZlcnNlKCk7XG4gIH07XG5cbiAgZnVuY3Rpb24gUmVzdGFuZ3VsYXJSZXNvdXJjZShjb25maWcsICRodHRwLCB1cmwsIGNvbmZpZ3VyZXIpIHtcbiAgICBjb25zdCByZXNvdXJjZSA9IHt9O1xuICAgIGVhY2goa2V5cyhjb25maWd1cmVyKSwgZnVuY3Rpb24gKGtleSkge1xuICAgICAgY29uc3QgdmFsdWUgPSBjb25maWd1cmVyW2tleV07XG5cbiAgICAgIC8vIEFkZCBkZWZhdWx0IHBhcmFtZXRlcnNcbiAgICAgIHZhbHVlLnBhcmFtcyA9IGV4dGVuZCh7fSwgdmFsdWUucGFyYW1zLCBjb25maWcuZGVmYXVsdFJlcXVlc3RQYXJhbXNbdmFsdWUubWV0aG9kLnRvTG93ZXJDYXNlKCldKTtcbiAgICAgIC8vIFdlIGRvbid0IHdhbnQgdGhlID8gaWYgbm8gcGFyYW1zIGFyZSB0aGVyZVxuICAgICAgaWYgKGlzRW1wdHkodmFsdWUucGFyYW1zKSkge1xuICAgICAgICBkZWxldGUgdmFsdWUucGFyYW1zO1xuICAgICAgfVxuXG4gICAgICBpZiAoY29uZmlnLmlzU2FmZSh2YWx1ZS5tZXRob2QpKSB7XG5cbiAgICAgICAgcmVzb3VyY2Vba2V5XSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBjb25zdCByZXN1bHRDb25maWcgPSBleHRlbmQodmFsdWUsIHtcbiAgICAgICAgICAgIHVybDogdXJsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuICRodHRwLmNyZWF0ZVJlcXVlc3QocmVzdWx0Q29uZmlnKTtcbiAgICAgICAgfTtcblxuICAgICAgfSBlbHNlIHtcblxuICAgICAgICByZXNvdXJjZVtrZXldID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICBjb25zdCByZXN1bHRDb25maWcgPSBleHRlbmQodmFsdWUsIHtcbiAgICAgICAgICAgIHVybDogdXJsLFxuICAgICAgICAgICAgZGF0YTogZGF0YVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiAkaHR0cC5jcmVhdGVSZXF1ZXN0KHJlc3VsdENvbmZpZyk7XG4gICAgICAgIH07XG5cbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiByZXNvdXJjZTtcbiAgfVxuXG4gIEJhc2VDcmVhdG9yLnByb3RvdHlwZS5yZXNvdXJjZSA9IGZ1bmN0aW9uIChjdXJyZW50LCAkaHR0cCwgbG9jYWxIdHRwQ29uZmlnLCBjYWxsSGVhZGVycywgY2FsbFBhcmFtcywgd2hhdCwgZXRhZywgb3BlcmF0aW9uKSB7XG4gICAgY29uc3QgcGFyYW1zID0gZGVmYXVsdHMoY2FsbFBhcmFtcyB8fCB7fSwgdGhpcy5jb25maWcuZGVmYXVsdFJlcXVlc3RQYXJhbXMuY29tbW9uKTtcbiAgICBjb25zdCBoZWFkZXJzID0gZGVmYXVsdHMoY2FsbEhlYWRlcnMgfHwge30sIHRoaXMuY29uZmlnLmRlZmF1bHRIZWFkZXJzKTtcblxuICAgIGlmIChldGFnKSB7XG4gICAgICBpZiAoIWNvbmZpZ3VyYXRpb24uaXNTYWZlKG9wZXJhdGlvbikpIHtcbiAgICAgICAgaGVhZGVyc1snSWYtTWF0Y2gnXSA9IGV0YWc7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoZWFkZXJzWydJZi1Ob25lLU1hdGNoJ10gPSBldGFnO1xuICAgICAgfVxuICAgIH1cblxuICAgIGxldCB1cmwgPSB0aGlzLmJhc2UoY3VycmVudCk7XG5cbiAgICBpZiAod2hhdCkge1xuICAgICAgbGV0IGFkZCA9ICcnO1xuICAgICAgaWYgKCEvXFwvJC8udGVzdCh1cmwpKSB7XG4gICAgICAgIGFkZCArPSAnLyc7XG4gICAgICB9XG4gICAgICBhZGQgKz0gd2hhdDtcbiAgICAgIHVybCArPSBhZGQ7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuY29uZmlnLnN1ZmZpeCAmJlxuICAgICAgdXJsLmluZGV4T2YodGhpcy5jb25maWcuc3VmZml4LCB1cmwubGVuZ3RoIC0gdGhpcy5jb25maWcuc3VmZml4Lmxlbmd0aCkgPT09IC0xICYmICF0aGlzLmNvbmZpZy5nZXRVcmxGcm9tRWxlbShjdXJyZW50KSkge1xuICAgICAgdXJsICs9IHRoaXMuY29uZmlnLnN1ZmZpeDtcbiAgICB9XG5cbiAgICBjdXJyZW50W3RoaXMuY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmh0dHBDb25maWddID0gdW5kZWZpbmVkO1xuXG4gICAgcmV0dXJuIFJlc3Rhbmd1bGFyUmVzb3VyY2UodGhpcy5jb25maWcsICRodHRwLCB1cmwsIHtcbiAgICAgIGdldExpc3Q6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgZ2V0OiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIGpzb25wOiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdqc29ucCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgcHV0OiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIHBvc3Q6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIHJlbW92ZTogdGhpcy5jb25maWcud2l0aEh0dHBWYWx1ZXMobG9jYWxIdHRwQ29uZmlnLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXG4gICAgICAgIH0pLFxuXG4gICAgICBoZWFkOiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdIRUFEJyxcbiAgICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXG4gICAgICAgIH0pLFxuXG4gICAgICB0cmFjZTogdGhpcy5jb25maWcud2l0aEh0dHBWYWx1ZXMobG9jYWxIdHRwQ29uZmlnLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiAnVFJBQ0UnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIG9wdGlvbnM6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ09QVElPTlMnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIHBhdGNoOiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KVxuICAgIH0pO1xuICB9O1xuXG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSBQYXRoIFVSTCBjcmVhdG9yLiBJdCB1c2VzIFBhdGggdG8gc2hvdyBIaWVyYXJjaHkgaW4gdGhlIFJlc3QgQVBJLlxuICAgKiBUaGlzIG1lYW5zIHRoYXQgaWYgeW91IGhhdmUgYW4gQWNjb3VudCB0aGF0IHRoZW4gaGFzIGEgc2V0IG9mIEJ1aWxkaW5ncywgYSBVUkwgdG8gYSBidWlsZGluZ1xuICAgKiB3b3VsZCBiZSAvYWNjb3VudHMvMTIzL2J1aWxkaW5ncy80NTZcbiAgICoqL1xuICBjb25zdCBQYXRoID0gZnVuY3Rpb24gKCkge1xuICB9O1xuXG4gIFBhdGgucHJvdG90eXBlID0gbmV3IEJhc2VDcmVhdG9yKCk7XG5cbiAgUGF0aC5wcm90b3R5cGUubm9ybWFsaXplVXJsID0gZnVuY3Rpb24gKHVybCkge1xuICAgIGNvbnN0IHBhcnRzID0gLygoPzpodHRwW3NdPzopP1xcL1xcLyk/KC4qKT8vLmV4ZWModXJsKTtcbiAgICBwYXJ0c1syXSA9IHBhcnRzWzJdLnJlcGxhY2UoL1tcXFxcXFwvXSsvZywgJy8nKTtcbiAgICByZXR1cm4gKHR5cGVvZiBwYXJ0c1sxXSAhPT0gJ3VuZGVmaW5lZCcpID8gcGFydHNbMV0gKyBwYXJ0c1syXSA6IHBhcnRzWzJdO1xuICB9O1xuXG4gIFBhdGgucHJvdG90eXBlLmJhc2UgPSBmdW5jdGlvbiAoY3VycmVudCkge1xuICAgIGNvbnN0IF9fdGhpcyA9IHRoaXM7XG4gICAgcmV0dXJuIHJlZHVjZSh0aGlzLnBhcmVudHNBcnJheShjdXJyZW50KSwgZnVuY3Rpb24gKGFjdW06IGFueSwgZWxlbTogYW55KSB7XG4gICAgICBsZXQgZWxlbVVybDtcbiAgICAgIGNvbnN0IGVsZW1TZWxmTGluayA9IF9fdGhpcy5jb25maWcuZ2V0VXJsRnJvbUVsZW0oZWxlbSk7XG4gICAgICBpZiAoZWxlbVNlbGZMaW5rKSB7XG4gICAgICAgIGlmIChfX3RoaXMuY29uZmlnLmlzQWJzb2x1dGVVcmwoZWxlbVNlbGZMaW5rKSkge1xuICAgICAgICAgIHJldHVybiBlbGVtU2VsZkxpbms7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZWxlbVVybCA9IGVsZW1TZWxmTGluaztcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZWxlbVVybCA9IGVsZW1bX190aGlzLmNvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yb3V0ZV07XG5cbiAgICAgICAgaWYgKGVsZW1bX190aGlzLmNvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dKSB7XG4gICAgICAgICAgY29uc3QgaWRzID0gZWxlbVtfX3RoaXMuY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmlkc107XG4gICAgICAgICAgaWYgKGlkcykge1xuICAgICAgICAgICAgZWxlbVVybCArPSAnLycgKyBpZHMuam9pbignLCcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsZXQgZWxlbUlkOiBhbnk7XG4gICAgICAgICAgaWYgKF9fdGhpcy5jb25maWcudXNlQ2Fubm9uaWNhbElkKSB7XG4gICAgICAgICAgICBlbGVtSWQgPSBfX3RoaXMuY29uZmlnLmdldENhbm5vbmljYWxJZEZyb21FbGVtKGVsZW0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBlbGVtSWQgPSBfX3RoaXMuY29uZmlnLmdldElkRnJvbUVsZW0oZWxlbSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGNvbmZpZ3VyYXRpb24uaXNWYWxpZElkKGVsZW1JZCkgJiYgIWVsZW0uc2luZ2xlT25lKSB7XG4gICAgICAgICAgICBlbGVtVXJsICs9ICcvJyArIChfX3RoaXMuY29uZmlnLmVuY29kZUlkcyA/IGVuY29kZVVSSUNvbXBvbmVudChlbGVtSWQpIDogZWxlbUlkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGFjdW0gPSBhY3VtLnJlcGxhY2UoL1xcLyQvLCAnJykgKyAnLycgKyBlbGVtVXJsO1xuICAgICAgcmV0dXJuIF9fdGhpcy5ub3JtYWxpemVVcmwoYWN1bSk7XG5cbiAgICB9LCB0aGlzLmNvbmZpZy5iYXNlVXJsKTtcbiAgfTtcblxuXG4gIFBhdGgucHJvdG90eXBlLmZldGNoVXJsID0gZnVuY3Rpb24gKGN1cnJlbnQsIHdoYXQpIHtcbiAgICBsZXQgYmFzZVVybCA9IHRoaXMuYmFzZShjdXJyZW50KTtcbiAgICBpZiAod2hhdCkge1xuICAgICAgYmFzZVVybCArPSAnLycgKyB3aGF0O1xuICAgIH1cbiAgICByZXR1cm4gYmFzZVVybDtcbiAgfTtcblxuICBQYXRoLnByb3RvdHlwZS5mZXRjaFJlcXVlc3RlZFVybCA9IGZ1bmN0aW9uIChjdXJyZW50LCB3aGF0KSB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5mZXRjaFVybChjdXJyZW50LCB3aGF0KTtcbiAgICBjb25zdCBwYXJhbXMgPSBjdXJyZW50W2NvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMucmVxUGFyYW1zXTtcblxuICAgIC8vIEZyb20gaGVyZSBvbiBhbmQgdW50aWwgdGhlIGVuZCBvZiBmZXRjaFJlcXVlc3RlZFVybCxcbiAgICAvLyB0aGUgY29kZSBoYXMgYmVlbiBraW5kbHkgYm9ycm93ZWQgZnJvbSBhbmd1bGFyLmpzXG4gICAgLy8gVGhlIHJlYXNvbiBmb3Igc3VjaCBjb2RlIGJsb2F0aW5nIGlzIGNvaGVyZW5jZTpcbiAgICAvLyAgIElmIHRoZSB1c2VyIHdlcmUgdG8gdXNlIHRoaXMgZm9yIGNhY2hlIG1hbmFnZW1lbnQsIHRoZVxuICAgIC8vICAgc2VyaWFsaXphdGlvbiBvZiBwYXJhbWV0ZXJzIHdvdWxkIG5lZWQgdG8gYmUgaWRlbnRpY2FsXG4gICAgLy8gICB0byB0aGUgb25lIGRvbmUgYnkgYW5ndWxhciBmb3IgY2FjaGUga2V5cyB0byBtYXRjaC5cbiAgICBmdW5jdGlvbiBzb3J0ZWRLZXlzKG9iaikge1xuICAgICAgY29uc3QgcmVzdWx0S2V5cyA9IFtdO1xuICAgICAgZm9yIChjb25zdCBrZXkgaW4gb2JqKSB7XG4gICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgIHJlc3VsdEtleXMucHVzaChrZXkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0S2V5cy5zb3J0KCk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gZm9yRWFjaFNvcnRlZChvYmosIGl0ZXJhdG9yPywgY29udGV4dD8pIHtcbiAgICAgIGNvbnN0IHNvcnRlZEtleXNBcnJheSA9IHNvcnRlZEtleXMob2JqKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc29ydGVkS2V5c0FycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGl0ZXJhdG9yLmNhbGwoY29udGV4dCwgb2JqW3NvcnRlZEtleXNBcnJheVtpXV0sIHNvcnRlZEtleXNBcnJheVtpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gc29ydGVkS2V5c0FycmF5O1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGVuY29kZVVyaVF1ZXJ5KHZhbCwgcGN0RW5jb2RlU3BhY2VzPykge1xuICAgICAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudCh2YWwpXG4gICAgICAucmVwbGFjZSgvJTQwL2dpLCAnQCcpXG4gICAgICAucmVwbGFjZSgvJTNBL2dpLCAnOicpXG4gICAgICAucmVwbGFjZSgvJTI0L2csICckJylcbiAgICAgIC5yZXBsYWNlKC8lMkMvZ2ksICcsJylcbiAgICAgIC5yZXBsYWNlKC8lMjAvZywgKHBjdEVuY29kZVNwYWNlcyA/ICclMjAnIDogJysnKSk7XG4gICAgfVxuXG4gICAgaWYgKCFwYXJhbXMpIHtcbiAgICAgIHJldHVybiB1cmwgKyAodGhpcy5jb25maWcuc3VmZml4IHx8ICcnKTtcbiAgICB9XG5cbiAgICBjb25zdCBwYXJ0cyA9IFtdO1xuICAgIGZvckVhY2hTb3J0ZWQocGFyYW1zLCBmdW5jdGlvbiAodmFsdWUsIGtleSkge1xuICAgICAgaWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKCFpc0FycmF5KHZhbHVlKSkge1xuICAgICAgICB2YWx1ZSA9IFt2YWx1ZV07XG4gICAgICB9XG5cbiAgICAgIGZvckVhY2godmFsdWUsIGZ1bmN0aW9uICh2KSB7XG4gICAgICAgIGlmIChpc09iamVjdCh2KSkge1xuICAgICAgICAgIHYgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICAgICAgfVxuICAgICAgICBwYXJ0cy5wdXNoKGVuY29kZVVyaVF1ZXJ5KGtleSkgKyAnPScgKyBlbmNvZGVVcmlRdWVyeSh2KSk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHJldHVybiB1cmwgKyAodGhpcy5jb25maWcuc3VmZml4IHx8ICcnKSArICgodXJsLmluZGV4T2YoJz8nKSA9PT0gLTEpID8gJz8nIDogJyYnKSArIHBhcnRzLmpvaW4oJyYnKTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLnVybENyZWF0b3JGYWN0b3J5LnBhdGggPSBQYXRoO1xufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgSW5qZWN0LCBJbmplY3RvciwgT3B0aW9uYWwsIFR5cGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGFzc2lnbiB9IGZyb20gJ2NvcmUtanMvZm4vb2JqZWN0JztcbmltcG9ydCB7XG4gIG1hcCxcbiAgYmluZCxcbiAgdW5pb24sXG4gIHZhbHVlcyxcbiAgcGljayxcbiAgaXNFbXB0eSxcbiAgaXNGdW5jdGlvbixcbiAgaXNOdW1iZXIsXG4gIGlzVW5kZWZpbmVkLFxuICBpc0FycmF5LFxuICBpc09iamVjdCxcbiAgZXh0ZW5kLFxuICBlYWNoLFxuICBldmVyeSxcbiAgb21pdCxcbiAgZ2V0LFxuICBkZWZhdWx0cyxcbiAgY2xvbmUsXG4gIGluY2x1ZGVzXG59IGZyb20gJ2xvZGFzaCc7XG5cbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuXG5pbXBvcnQgeyBSRVNUQU5HVUxBUiB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLmNvbmZpZyc7XG5pbXBvcnQgeyBSZXN0YW5ndWxhckh0dHAgfSBmcm9tICcuL25neC1yZXN0YW5ndWxhci1odHRwJztcbmltcG9ydCB7IFJlc3Rhbmd1bGFyQ29uZmlndXJlciB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLWNvbmZpZy5mYWN0b3J5JztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFJlc3Rhbmd1bGFyIHtcbiAgcHJvdmlkZXI6IHtcbiAgICBzZXRCYXNlVXJsOiBhbnksXG4gICAgc2V0RGVmYXVsdEhlYWRlcnM6IGFueSxcbiAgICBjb25maWd1cmF0aW9uOiBhbnksXG4gICAgc2V0U2VsZkxpbmtBYnNvbHV0ZVVybDogYW55LFxuICAgIHNldEV4dHJhRmllbGRzOiBhbnksXG4gICAgc2V0RGVmYXVsdEh0dHBGaWVsZHM6IGFueSxcbiAgICBzZXRQbGFpbkJ5RGVmYXVsdDogYW55LFxuICAgIHNldEVuY29kZUlkczogYW55LFxuICAgIHNldERlZmF1bHRSZXF1ZXN0UGFyYW1zOiBhbnksXG4gICAgcmVxdWVzdFBhcmFtczogYW55LFxuICAgIGRlZmF1bHRIZWFkZXJzOiBhbnksXG4gICAgc2V0RGVmYXVsdFJlc3BvbnNlTWV0aG9kOiBhbnksXG4gICAgZGVmYXVsdFJlc3BvbnNlTWV0aG9kOiBhbnksXG4gICAgc2V0TWV0aG9kT3ZlcnJpZGVyczogYW55LFxuICAgIHNldEpzb25wOiBhbnksXG4gICAgc2V0VXJsQ3JlYXRvcjogYW55LFxuICAgIHNldFJlc3Rhbmd1bGFyRmllbGRzOiBhbnksXG4gICAgc2V0VXNlQ2Fubm9uaWNhbElkOiBhbnksXG4gICAgYWRkUmVzcG9uc2VJbnRlcmNlcHRvcjogYW55LFxuICAgIGFkZEVycm9ySW50ZXJjZXB0b3I6IGFueSxcbiAgICBzZXRSZXNwb25zZUludGVyY2VwdG9yOiBhbnksXG4gICAgc2V0UmVzcG9uc2VFeHRyYWN0b3I6IGFueSxcbiAgICBzZXRFcnJvckludGVyY2VwdG9yOiBhbnksXG4gICAgYWRkUmVxdWVzdEludGVyY2VwdG9yOiBhbnksXG4gICAgc2V0UmVxdWVzdEludGVyY2VwdG9yOiBhbnksXG4gICAgc2V0RnVsbFJlcXVlc3RJbnRlcmNlcHRvcjogYW55LFxuICAgIGFkZEZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3I6IGFueSxcbiAgICBzZXRPbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQ6IGFueSxcbiAgICBzZXRSZXN0YW5ndWxhcml6ZVByb21pc2VJbnRlcmNlcHRvcjogYW55LFxuICAgIHNldE9uRWxlbVJlc3Rhbmd1bGFyaXplZDogYW55LFxuICAgIHNldFBhcmVudGxlc3M6IGFueSxcbiAgICBzZXRSZXF1ZXN0U3VmZml4OiBhbnksXG4gICAgYWRkRWxlbWVudFRyYW5zZm9ybWVyOiBhbnksXG4gICAgZXh0ZW5kQ29sbGVjdGlvbjogYW55LFxuICAgIGV4dGVuZE1vZGVsOiBhbnksXG4gICAgc2V0VHJhbnNmb3JtT25seVNlcnZlckVsZW1lbnRzOiBhbnksXG4gICAgc2V0RnVsbFJlc3BvbnNlOiBhbnksXG4gICAgJGdldDogYW55XG4gIH07XG4gIGFkZEVsZW1lbnRUcmFuc2Zvcm1lcjogYW55O1xuICBleHRlbmRDb2xsZWN0aW9uOiBhbnk7XG4gIGV4dGVuZE1vZGVsOiBhbnk7XG4gIGNvcHk7XG4gIGNvbmZpZ3VyYXRpb247XG4gIHNlcnZpY2U7XG4gIGlkO1xuICByb3V0ZTtcbiAgcGFyZW50UmVzb3VyY2U7XG4gIHJlc3Rhbmd1bGFyQ29sbGVjdGlvbjtcbiAgY2Fubm9uaWNhbElkO1xuICBldGFnO1xuICBzZWxmTGluaztcbiAgZ2V0O1xuICBnZXRMaXN0O1xuICBwdXQ7XG4gIHBvc3Q7XG4gIHJlbW92ZTtcbiAgaGVhZDtcbiAgdHJhY2U7XG4gIG9wdGlvbnM7XG4gIHBhdGNoO1xuICBnZXRSZXN0YW5ndWxhclVybDtcbiAgZ2V0UmVxdWVzdGVkVXJsO1xuICBwdXRFbGVtZW50O1xuICBhZGRSZXN0YW5ndWxhck1ldGhvZDtcbiAgZ2V0UGFyZW50TGlzdDtcbiAgY2xvbmU7XG4gIGlkcztcbiAgaHR0cENvbmZpZztcbiAgcmVxUGFyYW1zO1xuICBvbmU7XG4gIGFsbDtcbiAgc2V2ZXJhbDtcbiAgb25lVXJsO1xuICBhbGxVcmw7XG4gIGN1c3RvbVBVVDtcbiAgY3VzdG9tUEFUQ0g7XG4gIGN1c3RvbVBPU1Q7XG4gIGN1c3RvbURFTEVURTtcbiAgY3VzdG9tR0VUO1xuICBjdXN0b21HRVRMSVNUO1xuICBjdXN0b21PcGVyYXRpb247XG4gIGRvUFVUO1xuICBkb1BBVENIO1xuICBkb1BPU1Q7XG4gIGRvREVMRVRFO1xuICBkb0dFVDtcbiAgZG9HRVRMSVNUO1xuICBmcm9tU2VydmVyO1xuICB3aXRoQ29uZmlnO1xuICB3aXRoSHR0cENvbmZpZztcbiAgc2luZ2xlT25lO1xuICBwbGFpbjtcbiAgc2F2ZTtcbiAgcmVzdGFuZ3VsYXJpemVkO1xuICByZXN0YW5ndWxhcml6ZUVsZW1lbnQ7XG4gIHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBAT3B0aW9uYWwoKSBASW5qZWN0KFJFU1RBTkdVTEFSKSBwdWJsaWMgY29uZmlnT2JqLFxuICAgIHByaXZhdGUgaW5qZWN0b3I6IEluamVjdG9yLFxuICAgIHByaXZhdGUgaHR0cDogUmVzdGFuZ3VsYXJIdHRwXG4gICkge1xuICAgIHRoaXMucHJvdmlkZXIgPSBuZXcgcHJvdmlkZXJDb25maWcoaHR0cCk7XG4gICAgY29uc3QgZWxlbWVudCA9IHRoaXMucHJvdmlkZXIuJGdldCgpO1xuICAgIGFzc2lnbih0aGlzLCBlbGVtZW50KTtcblxuICAgIHRoaXMuc2V0RGVmYXVsdENvbmZpZygpO1xuICB9XG5cbiAgc2V0RGVmYXVsdENvbmZpZygpIHtcbiAgICBpZiAoIXRoaXMuY29uZmlnT2JqIHx8ICFpc0Z1bmN0aW9uKHRoaXMuY29uZmlnT2JqLmZuKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGFyckRJID0gbWFwKHRoaXMuY29uZmlnT2JqLmFyclNlcnZpY2VzLCAoc2VydmljZXM6IFR5cGU8YW55PikgPT4ge1xuICAgICAgcmV0dXJuIHRoaXMuaW5qZWN0b3IuZ2V0KHNlcnZpY2VzKTtcbiAgICB9KTtcblxuICAgIHRoaXMuY29uZmlnT2JqLmZuKC4uLlt0aGlzLnByb3ZpZGVyLCAuLi5hcnJESV0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHByb3ZpZGVyQ29uZmlnKCRodHRwKSB7XG4gIGNvbnN0IGdsb2JhbENvbmZpZ3VyYXRpb24gPSB7fTtcblxuICBSZXN0YW5ndWxhckNvbmZpZ3VyZXIodGhpcywgZ2xvYmFsQ29uZmlndXJhdGlvbik7XG5cbiAgdGhpcy4kZ2V0ID0gJGdldDtcblxuICBmdW5jdGlvbiAkZ2V0KCkge1xuXG4gICAgZnVuY3Rpb24gY3JlYXRlU2VydmljZUZvckNvbmZpZ3VyYXRpb24oY29uZmlnKSB7XG4gICAgICBjb25zdCBzZXJ2aWNlOiBhbnkgPSB7fTtcblxuICAgICAgY29uc3QgdXJsSGFuZGxlciA9IG5ldyBjb25maWcudXJsQ3JlYXRvckZhY3RvcnlbY29uZmlnLnVybENyZWF0b3JdKCk7XG4gICAgICB1cmxIYW5kbGVyLnNldENvbmZpZyhjb25maWcpO1xuXG4gICAgICBmdW5jdGlvbiByZXN0YW5ndWxhcml6ZUJhc2UocGFyZW50LCBlbGVtLCByb3V0ZSwgcmVxUGFyYW1zLCBmcm9tU2VydmVyKSB7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXSA9IHJvdXRlO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRSZXN0YW5ndWxhclVybF0gPSBiaW5kKHVybEhhbmRsZXIuZmV0Y2hVcmwsIHVybEhhbmRsZXIsIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRSZXF1ZXN0ZWRVcmxdID0gYmluZCh1cmxIYW5kbGVyLmZldGNoUmVxdWVzdGVkVXJsLCB1cmxIYW5kbGVyLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuYWRkUmVzdGFuZ3VsYXJNZXRob2RdID0gYmluZChhZGRSZXN0YW5ndWxhck1ldGhvZEZ1bmN0aW9uLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuY2xvbmVdID0gYmluZChjb3B5UmVzdGFuZ3VsYXJpemVkRWxlbWVudCwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlcVBhcmFtc10gPSBpc0VtcHR5KHJlcVBhcmFtcykgPyBudWxsIDogcmVxUGFyYW1zO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy53aXRoSHR0cENvbmZpZ10gPSBiaW5kKHdpdGhIdHRwQ29uZmlnLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGxhaW5dID0gYmluZChzdHJpcFJlc3Rhbmd1bGFyLCBlbGVtLCBlbGVtKTtcblxuICAgICAgICAvLyBUYWcgZWxlbWVudCBhcyByZXN0YW5ndWxhcml6ZWRcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVzdGFuZ3VsYXJpemVkXSA9IHRydWU7XG5cbiAgICAgICAgLy8gUmVxdWVzdExlc3MgY29ubmVjdGlvblxuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5vbmVdID0gYmluZChvbmUsIGVsZW0sIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5hbGxdID0gYmluZChhbGwsIGVsZW0sIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5zZXZlcmFsXSA9IGJpbmQoc2V2ZXJhbCwgZWxlbSwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLm9uZVVybF0gPSBiaW5kKG9uZVVybCwgZWxlbSwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmFsbFVybF0gPSBiaW5kKGFsbFVybCwgZWxlbSwgZWxlbSk7XG5cbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZnJvbVNlcnZlcl0gPSAhIWZyb21TZXJ2ZXI7XG5cbiAgICAgICAgaWYgKHBhcmVudCAmJiBjb25maWcuc2hvdWxkU2F2ZVBhcmVudChyb3V0ZSkpIHtcbiAgICAgICAgICBjb25zdCBwYXJlbnRJZCA9IGNvbmZpZy5nZXRJZEZyb21FbGVtKHBhcmVudCk7XG4gICAgICAgICAgY29uc3QgcGFyZW50VXJsID0gY29uZmlnLmdldFVybEZyb21FbGVtKHBhcmVudCk7XG5cbiAgICAgICAgICBjb25zdCByZXN0YW5ndWxhckZpZWxkc0ZvclBhcmVudCA9IHVuaW9uKFxuICAgICAgICAgICAgdmFsdWVzKHBpY2soY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLCBbJ3JvdXRlJywgJ3NpbmdsZU9uZScsICdwYXJlbnRSZXNvdXJjZSddKSksXG4gICAgICAgICAgICBjb25maWcuZXh0cmFGaWVsZHNcbiAgICAgICAgICApO1xuICAgICAgICAgIGNvbnN0IHBhcmVudFJlc291cmNlID0gcGljayhwYXJlbnQsIHJlc3Rhbmd1bGFyRmllbGRzRm9yUGFyZW50KTtcblxuICAgICAgICAgIGlmIChjb25maWcuaXNWYWxpZElkKHBhcmVudElkKSkge1xuICAgICAgICAgICAgY29uZmlnLnNldElkVG9FbGVtKHBhcmVudFJlc291cmNlLCBwYXJlbnRJZCwgcm91dGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY29uZmlnLmlzVmFsaWRJZChwYXJlbnRVcmwpKSB7XG4gICAgICAgICAgICBjb25maWcuc2V0VXJsVG9FbGVtKHBhcmVudFJlc291cmNlLCBwYXJlbnRVcmwsIHJvdXRlKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV0gPSBwYXJlbnRSZXNvdXJjZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV0gPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlbGVtO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBvbmUocGFyZW50LCByb3V0ZSwgaWQsIHNpbmdsZU9uZSkge1xuICAgICAgICBsZXQgZXJyb3I7XG4gICAgICAgIGlmIChpc051bWJlcihyb3V0ZSkgfHwgaXNOdW1iZXIocGFyZW50KSkge1xuICAgICAgICAgIGVycm9yID0gJ1lvdVxcJ3JlIGNyZWF0aW5nIGEgUmVzdGFuZ3VsYXIgZW50aXR5IHdpdGggdGhlIG51bWJlciAnO1xuICAgICAgICAgIGVycm9yICs9ICdpbnN0ZWFkIG9mIHRoZSByb3V0ZSBvciB0aGUgcGFyZW50LiBGb3IgZXhhbXBsZSwgeW91IGNhblxcJ3QgY2FsbCAub25lKDEyKS4nO1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzVW5kZWZpbmVkKHJvdXRlKSkge1xuICAgICAgICAgIGVycm9yID0gJ1lvdVxcJ3JlIGNyZWF0aW5nIGEgUmVzdGFuZ3VsYXIgZW50aXR5IGVpdGhlciB3aXRob3V0IHRoZSBwYXRoLiAnO1xuICAgICAgICAgIGVycm9yICs9ICdGb3IgZXhhbXBsZSB5b3UgY2FuXFwndCBjYWxsIC5vbmUoKS4gUGxlYXNlIGNoZWNrIGlmIHlvdXIgYXJndW1lbnRzIGFyZSB2YWxpZC4nO1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZWxlbSA9IHt9O1xuICAgICAgICBjb25maWcuc2V0SWRUb0VsZW0oZWxlbSwgaWQsIHJvdXRlKTtcbiAgICAgICAgY29uZmlnLnNldEZpZWxkVG9FbGVtKGNvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5zaW5nbGVPbmUsIGVsZW0sIHNpbmdsZU9uZSk7XG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUVsZW0ocGFyZW50LCBlbGVtLCByb3V0ZSwgZmFsc2UpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBhbGwocGFyZW50LCByb3V0ZSkge1xuICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uKHBhcmVudCwgW10sIHJvdXRlLCBmYWxzZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHNldmVyYWwocGFyZW50LCByb3V0ZSAvKiwgaWRzICovKSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBbXTtcbiAgICAgICAgY29sbGVjdGlvbltjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaWRzXSA9IEFycmF5LnByb3RvdHlwZS5zcGxpY2UuY2FsbChhcmd1bWVudHMsIDIpO1xuICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uKHBhcmVudCwgY29sbGVjdGlvbiwgcm91dGUsIGZhbHNlKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gb25lVXJsKHBhcmVudCwgcm91dGUsIHVybCkge1xuICAgICAgICBpZiAoIXJvdXRlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdSb3V0ZSBpcyBtYW5kYXRvcnkgd2hlbiBjcmVhdGluZyBuZXcgUmVzdGFuZ3VsYXIgb2JqZWN0cy4nKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBlbGVtID0ge307XG4gICAgICAgIGNvbmZpZy5zZXRVcmxUb0VsZW0oZWxlbSwgdXJsLCByb3V0ZSk7XG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUVsZW0ocGFyZW50LCBlbGVtLCByb3V0ZSwgZmFsc2UpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBhbGxVcmwocGFyZW50LCByb3V0ZSwgdXJsKSB7XG4gICAgICAgIGlmICghcm91dGUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JvdXRlIGlzIG1hbmRhdG9yeSB3aGVuIGNyZWF0aW5nIG5ldyBSZXN0YW5ndWxhciBvYmplY3RzLicpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGVsZW0gPSB7fTtcbiAgICAgICAgY29uZmlnLnNldFVybFRvRWxlbShlbGVtLCB1cmwsIHJvdXRlKTtcbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbihwYXJlbnQsIGVsZW0sIHJvdXRlLCBmYWxzZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIFByb21pc2VzXG4gICAgICBmdW5jdGlvbiByZXN0YW5ndWxhcml6ZVJlc3BvbnNlKHN1YmplY3QsIGlzQ29sbGVjdGlvbiwgdmFsdWVUb0ZpbGwpIHtcbiAgICAgICAgcmV0dXJuIHN1YmplY3QucGlwZShmaWx0ZXIocmVzID0+ICEhcmVzKSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBkYXRhLCBmaWxsZWRWYWx1ZSkge1xuICAgICAgICBleHRlbmQoZmlsbGVkVmFsdWUsIGRhdGEpO1xuXG4gICAgICAgIC8vIFRyaWdnZXIgdGhlIGZ1bGwgcmVzcG9uc2UgaW50ZXJjZXB0b3IuXG4gICAgICAgIGlmIChjb25maWcuZnVsbFJlc3BvbnNlKSB7XG4gICAgICAgICAgc3ViamVjdC5uZXh0KGV4dGVuZChyZXNwb25zZSwge1xuICAgICAgICAgICAgZGF0YTogZGF0YVxuICAgICAgICAgIH0pKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdWJqZWN0Lm5leHQoZGF0YSk7XG4gICAgICAgIH1cblxuICAgICAgICBzdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIEVsZW1lbnRzXG4gICAgICBmdW5jdGlvbiBzdHJpcFJlc3Rhbmd1bGFyKGVsZW0pIHtcbiAgICAgICAgaWYgKGlzQXJyYXkoZWxlbSkpIHtcbiAgICAgICAgICBjb25zdCBhcnJheSA9IFtdO1xuICAgICAgICAgIGVhY2goZWxlbSwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBhcnJheS5wdXNoKGNvbmZpZy5pc1Jlc3Rhbmd1bGFyaXplZCh2YWx1ZSkgPyBzdHJpcFJlc3Rhbmd1bGFyKHZhbHVlKSA6IHZhbHVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIG9taXQoZWxlbSwgdmFsdWVzKG9taXQoY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLCAnaWQnKSkpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGFkZEN1c3RvbU9wZXJhdGlvbihlbGVtKSB7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmN1c3RvbU9wZXJhdGlvbl0gPSBiaW5kKGN1c3RvbUZ1bmN0aW9uLCBlbGVtKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdE1ldGhvZHMgPSB7Z2V0OiBjdXN0b21GdW5jdGlvbiwgZGVsZXRlOiBjdXN0b21GdW5jdGlvbn07XG4gICAgICAgIGVhY2goWydwdXQnLCAncGF0Y2gnLCAncG9zdCddLCBmdW5jdGlvbiAobmFtZSkge1xuICAgICAgICAgIHJlcXVlc3RNZXRob2RzW25hbWVdID0gZnVuY3Rpb24gKG9wZXJhdGlvbiwgZWxlbWVudCwgcGF0aCwgcGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgICAgICByZXR1cm4gYmluZChjdXN0b21GdW5jdGlvbiwgdGhpcykob3BlcmF0aW9uLCBwYXRoLCBwYXJhbXMsIGhlYWRlcnMsIGVsZW1lbnQpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgICBlYWNoKHJlcXVlc3RNZXRob2RzLCBmdW5jdGlvbiAocmVxdWVzdEZ1bmMsIG5hbWUpIHtcbiAgICAgICAgICBjb25zdCBjYWxsT3BlcmF0aW9uID0gbmFtZSA9PT0gJ2RlbGV0ZScgPyAncmVtb3ZlJyA6IG5hbWU7XG4gICAgICAgICAgZWFjaChbJ2RvJywgJ2N1c3RvbSddLCBmdW5jdGlvbiAoYWxpYXMpIHtcbiAgICAgICAgICAgIGVsZW1bYWxpYXMgKyBuYW1lLnRvVXBwZXJDYXNlKCldID0gYmluZChyZXF1ZXN0RnVuYywgZWxlbSwgY2FsbE9wZXJhdGlvbik7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5jdXN0b21HRVRMSVNUXSA9IGJpbmQoZmV0Y2hGdW5jdGlvbiwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmRvR0VUTElTVF0gPSBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5jdXN0b21HRVRMSVNUXTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gY29weVJlc3Rhbmd1bGFyaXplZEVsZW1lbnQoZnJvbUVsZW1lbnQsIHRvRWxlbWVudCA9IHt9KSB7XG4gICAgICAgIGNvbnN0IGNvcGllZEVsZW1lbnQgPSBhc3NpZ24odG9FbGVtZW50LCBmcm9tRWxlbWVudCk7XG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUVsZW0oY29waWVkRWxlbWVudFtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdLFxuICAgICAgICAgIGNvcGllZEVsZW1lbnQsIGNvcGllZEVsZW1lbnRbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXSwgdHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHJlc3Rhbmd1bGFyaXplRWxlbShwYXJlbnQsIGVsZW1lbnQsIHJvdXRlLCBmcm9tU2VydmVyPywgY29sbGVjdGlvbj8sIHJlcVBhcmFtcz8pIHtcbiAgICAgICAgY29uc3QgZWxlbSA9IGNvbmZpZy5vbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQoZWxlbWVudCwgZmFsc2UsIHJvdXRlKTtcblxuICAgICAgICBjb25zdCBsb2NhbEVsZW0gPSByZXN0YW5ndWxhcml6ZUJhc2UocGFyZW50LCBlbGVtLCByb3V0ZSwgcmVxUGFyYW1zLCBmcm9tU2VydmVyKTtcblxuICAgICAgICBpZiAoY29uZmlnLnVzZUNhbm5vbmljYWxJZCkge1xuICAgICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuY2Fubm9uaWNhbElkXSA9IGNvbmZpZy5nZXRJZEZyb21FbGVtKGxvY2FsRWxlbSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY29sbGVjdGlvbikge1xuICAgICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZ2V0UGFyZW50TGlzdF0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29sbGVjdGlvbjtcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dID0gZmFsc2U7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZ2V0XSA9IGJpbmQoZ2V0RnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZ2V0TGlzdF0gPSBiaW5kKGZldGNoRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucHV0XSA9IGJpbmQocHV0RnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucG9zdF0gPSBiaW5kKHBvc3RGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZW1vdmVdID0gYmluZChkZWxldGVGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5oZWFkXSA9IGJpbmQoaGVhZEZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnRyYWNlXSA9IGJpbmQodHJhY2VGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5vcHRpb25zXSA9IGJpbmQob3B0aW9uc0Z1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhdGNoXSA9IGJpbmQocGF0Y2hGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5zYXZlXSA9IGJpbmQoc2F2ZSwgbG9jYWxFbGVtKTtcblxuICAgICAgICBhZGRDdXN0b21PcGVyYXRpb24obG9jYWxFbGVtKTtcbiAgICAgICAgcmV0dXJuIGNvbmZpZy50cmFuc2Zvcm1FbGVtKGxvY2FsRWxlbSwgZmFsc2UsIHJvdXRlLCBzZXJ2aWNlLCB0cnVlKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uKHBhcmVudCwgZWxlbWVudCwgcm91dGUsIGZyb21TZXJ2ZXI/LCByZXFQYXJhbXM/KSB7XG4gICAgICAgIGNvbnN0IGVsZW0gPSBjb25maWcub25CZWZvcmVFbGVtUmVzdGFuZ3VsYXJpemVkKGVsZW1lbnQsIHRydWUsIHJvdXRlKTtcblxuICAgICAgICBjb25zdCBsb2NhbEVsZW0gPSByZXN0YW5ndWxhcml6ZUJhc2UocGFyZW50LCBlbGVtLCByb3V0ZSwgcmVxUGFyYW1zLCBmcm9tU2VydmVyKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dID0gdHJ1ZTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wb3N0XSA9IGJpbmQocG9zdEZ1bmN0aW9uLCBsb2NhbEVsZW0sIG51bGwpO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlbW92ZV0gPSBiaW5kKGRlbGV0ZUZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmhlYWRdID0gYmluZChoZWFkRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMudHJhY2VdID0gYmluZCh0cmFjZUZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnB1dEVsZW1lbnRdID0gYmluZChwdXRFbGVtZW50RnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMub3B0aW9uc10gPSBiaW5kKG9wdGlvbnNGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXRjaF0gPSBiaW5kKHBhdGNoRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZ2V0XSA9IGJpbmQoZ2V0QnlJZCwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRMaXN0XSA9IGJpbmQoZmV0Y2hGdW5jdGlvbiwgbG9jYWxFbGVtLCBudWxsKTtcblxuICAgICAgICBhZGRDdXN0b21PcGVyYXRpb24obG9jYWxFbGVtKTtcbiAgICAgICAgcmV0dXJuIGNvbmZpZy50cmFuc2Zvcm1FbGVtKGxvY2FsRWxlbSwgdHJ1ZSwgcm91dGUsIHNlcnZpY2UsIHRydWUpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb25BbmRFbGVtZW50cyhwYXJlbnQsIGVsZW1lbnQsIHJvdXRlKSB7XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24ocGFyZW50LCBlbGVtZW50LCByb3V0ZSwgZmFsc2UpO1xuICAgICAgICBlYWNoKGNvbGxlY3Rpb24sIGZ1bmN0aW9uIChlbGVtKSB7XG4gICAgICAgICAgaWYgKGVsZW0pIHtcbiAgICAgICAgICAgIHJlc3Rhbmd1bGFyaXplRWxlbShwYXJlbnQsIGVsZW0sIHJvdXRlLCBmYWxzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGNvbGxlY3Rpb247XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGdldEJ5SWQoaWQsIHJlcVBhcmFtcywgaGVhZGVycykge1xuICAgICAgICByZXR1cm4gdGhpcy5jdXN0b21HRVQoaWQudG9TdHJpbmcoKSwgcmVxUGFyYW1zLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcHV0RWxlbWVudEZ1bmN0aW9uKGlkeCwgcGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIGNvbnN0IF9fdGhpcyA9IHRoaXM7XG4gICAgICAgIGNvbnN0IGVsZW1Ub1B1dCA9IHRoaXNbaWR4XTtcbiAgICAgICAgY29uc3Qgc3ViamVjdCA9IG5ldyBCZWhhdmlvclN1YmplY3QobnVsbCk7XG4gICAgICAgIGxldCBmaWxsZWRBcnJheSA9IFtdO1xuICAgICAgICBmaWxsZWRBcnJheSA9IGNvbmZpZy50cmFuc2Zvcm1FbGVtKGZpbGxlZEFycmF5LCB0cnVlLCBlbGVtVG9QdXRbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXSwgc2VydmljZSk7XG5cbiAgICAgICAgZWxlbVRvUHV0LnB1dChwYXJhbXMsIGhlYWRlcnMpXG4gICAgICAgIC5zdWJzY3JpYmUoZnVuY3Rpb24gKHNlcnZlckVsZW0pIHtcbiAgICAgICAgICBjb25zdCBuZXdBcnJheSA9IGNvcHlSZXN0YW5ndWxhcml6ZWRFbGVtZW50KF9fdGhpcyk7XG4gICAgICAgICAgbmV3QXJyYXlbaWR4XSA9IHNlcnZlckVsZW07XG4gICAgICAgICAgZmlsbGVkQXJyYXkgPSBuZXdBcnJheTtcbiAgICAgICAgICBzdWJqZWN0Lm5leHQobmV3QXJyYXkpO1xuICAgICAgICB9LCBmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICBzdWJqZWN0LmVycm9yKHJlc3BvbnNlKTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHN1YmplY3QuY29tcGxldGUoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplUmVzcG9uc2Uoc3ViamVjdCwgdHJ1ZSwgZmlsbGVkQXJyYXkpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBwYXJzZVJlc3BvbnNlKHJlc0RhdGEsIG9wZXJhdGlvbiwgcm91dGUsIGZldGNoVXJsLCByZXNwb25zZSwgc3ViamVjdCkge1xuICAgICAgICBjb25zdCBkYXRhID0gY29uZmlnLnJlc3BvbnNlRXh0cmFjdG9yKHJlc0RhdGEsIG9wZXJhdGlvbiwgcm91dGUsIGZldGNoVXJsLCByZXNwb25zZSwgc3ViamVjdCk7XG4gICAgICAgIGNvbnN0IGV0YWcgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnRVRhZycpO1xuICAgICAgICBpZiAoZGF0YSAmJiBldGFnKSB7XG4gICAgICAgICAgZGF0YVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZXRhZ10gPSBldGFnO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBmZXRjaEZ1bmN0aW9uKHdoYXQsIHJlcVBhcmFtcywgaGVhZGVycykge1xuICAgICAgICBjb25zdCBfX3RoaXMgPSB0aGlzO1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdChudWxsKTtcbiAgICAgICAgY29uc3Qgb3BlcmF0aW9uID0gJ2dldExpc3QnO1xuICAgICAgICBjb25zdCB1cmwgPSB1cmxIYW5kbGVyLmZldGNoVXJsKHRoaXMsIHdoYXQpO1xuICAgICAgICBjb25zdCB3aGF0RmV0Y2hlZCA9IHdoYXQgfHwgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yb3V0ZV07XG5cbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IGNvbmZpZy5mdWxsUmVxdWVzdEludGVyY2VwdG9yKG51bGwsIG9wZXJhdGlvbixcbiAgICAgICAgICB3aGF0RmV0Y2hlZCwgdXJsLCBoZWFkZXJzIHx8IHt9LCByZXFQYXJhbXMgfHwge30sIHRoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmh0dHBDb25maWddIHx8IHt9KTtcblxuICAgICAgICBsZXQgZmlsbGVkQXJyYXkgPSBbXTtcbiAgICAgICAgZmlsbGVkQXJyYXkgPSBjb25maWcudHJhbnNmb3JtRWxlbShmaWxsZWRBcnJheSwgdHJ1ZSwgd2hhdEZldGNoZWQsIHNlcnZpY2UpO1xuXG4gICAgICAgIGxldCBtZXRob2QgPSAnZ2V0TGlzdCc7XG5cbiAgICAgICAgaWYgKGNvbmZpZy5qc29ucCkge1xuICAgICAgICAgIG1ldGhvZCA9ICdqc29ucCc7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBva0NhbGxiYWNrID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgY29uc3QgcmVzRGF0YSA9IHJlc3BvbnNlLmJvZHk7XG4gICAgICAgICAgY29uc3QgZnVsbFBhcmFtcyA9IHJlc3BvbnNlLmNvbmZpZy5wYXJhbXM7XG4gICAgICAgICAgbGV0IGRhdGEgPSBwYXJzZVJlc3BvbnNlKHJlc0RhdGEsIG9wZXJhdGlvbiwgd2hhdEZldGNoZWQsIHVybCwgcmVzcG9uc2UsIHN1YmplY3QpO1xuXG4gICAgICAgICAgLy8gc3VwcG9ydCBlbXB0eSByZXNwb25zZSBmb3IgZ2V0TGlzdCgpIGNhbGxzIChzb21lIEFQSXMgcmVzcG9uZCB3aXRoIDIwNCBhbmQgZW1wdHkgYm9keSlcbiAgICAgICAgICBpZiAoaXNVbmRlZmluZWQoZGF0YSkgfHwgJycgPT09IGRhdGEpIHtcbiAgICAgICAgICAgIGRhdGEgPSBbXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFpc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Jlc3BvbnNlIGZvciBnZXRMaXN0IFNIT1VMRCBiZSBhbiBhcnJheSBhbmQgbm90IGFuIG9iamVjdCBvciBzb21ldGhpbmcgZWxzZScpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICh0cnVlID09PSBjb25maWcucGxhaW5CeURlZmF1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZShzdWJqZWN0LCByZXNwb25zZSwgZGF0YSwgZmlsbGVkQXJyYXkpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGxldCBwcm9jZXNzZWREYXRhID0gbWFwKGRhdGEsIGZ1bmN0aW9uIChlbGVtKSB7XG4gICAgICAgICAgICBpZiAoIV9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVzdGFuZ3VsYXJDb2xsZWN0aW9uXSkge1xuICAgICAgICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVFbGVtKF9fdGhpcywgZWxlbSwgd2hhdCwgdHJ1ZSwgZGF0YSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVFbGVtKF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdLFxuICAgICAgICAgICAgICAgIGVsZW0sIF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdLCB0cnVlLCBkYXRhKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIHByb2Nlc3NlZERhdGEgPSBleHRlbmQoZGF0YSwgcHJvY2Vzc2VkRGF0YSk7XG5cbiAgICAgICAgICBpZiAoIV9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVzdGFuZ3VsYXJDb2xsZWN0aW9uXSkge1xuICAgICAgICAgICAgcmVzb2x2ZVByb21pc2UoXG4gICAgICAgICAgICAgIHN1YmplY3QsXG4gICAgICAgICAgICAgIHJlc3BvbnNlLFxuICAgICAgICAgICAgICByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24oXG4gICAgICAgICAgICAgICAgX190aGlzLFxuICAgICAgICAgICAgICAgIHByb2Nlc3NlZERhdGEsXG4gICAgICAgICAgICAgICAgd2hhdCxcbiAgICAgICAgICAgICAgICB0cnVlLFxuICAgICAgICAgICAgICAgIGZ1bGxQYXJhbXNcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgZmlsbGVkQXJyYXlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKFxuICAgICAgICAgICAgICBzdWJqZWN0LFxuICAgICAgICAgICAgICByZXNwb25zZSxcbiAgICAgICAgICAgICAgcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uKFxuICAgICAgICAgICAgICAgIF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdLFxuICAgICAgICAgICAgICAgIHByb2Nlc3NlZERhdGEsXG4gICAgICAgICAgICAgICAgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yb3V0ZV0sXG4gICAgICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgICAgICBmdWxsUGFyYW1zXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIGZpbGxlZEFycmF5XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICB1cmxIYW5kbGVyLnJlc291cmNlKHRoaXMsICRodHRwLCByZXF1ZXN0Lmh0dHBDb25maWcsIHJlcXVlc3QuaGVhZGVycywgcmVxdWVzdC5wYXJhbXMsIHdoYXQsXG4gICAgICAgICAgdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZXRhZ10sIG9wZXJhdGlvbilbbWV0aG9kXSgpXG4gICAgICAgIC5zdWJzY3JpYmUob2tDYWxsYmFjaywgZnVuY3Rpb24gZXJyb3IocmVzcG9uc2UpIHtcbiAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAzMDQgJiYgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dKSB7XG4gICAgICAgICAgICByZXNvbHZlUHJvbWlzZShzdWJqZWN0LCByZXNwb25zZSwgX190aGlzLCBmaWxsZWRBcnJheSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChldmVyeShjb25maWcuZXJyb3JJbnRlcmNlcHRvcnMsIGZ1bmN0aW9uIChjYjogYW55KSB7XG5cbiAgICAgICAgICAgIHJldHVybiBjYihyZXNwb25zZSwgc3ViamVjdCwgb2tDYWxsYmFjaykgIT09IGZhbHNlO1xuICAgICAgICAgIH0pKSB7XG4gICAgICAgICAgICAvLyB0cmlnZ2VyZWQgaWYgbm8gY2FsbGJhY2sgcmV0dXJucyBmYWxzZVxuICAgICAgICAgICAgc3ViamVjdC5lcnJvcihyZXNwb25zZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVSZXNwb25zZShzdWJqZWN0LCB0cnVlLCBmaWxsZWRBcnJheSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHdpdGhIdHRwQ29uZmlnKGh0dHBDb25maWcpIHtcbiAgICAgICAgdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaHR0cENvbmZpZ10gPSBodHRwQ29uZmlnO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gc2F2ZShwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgaWYgKHRoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmZyb21TZXJ2ZXJdKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnB1dF0ocGFyYW1zLCBoZWFkZXJzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKCdwb3N0JywgdW5kZWZpbmVkLCBwYXJhbXMsIHVuZGVmaW5lZCwgaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gZWxlbUZ1bmN0aW9uKG9wZXJhdGlvbiwgd2hhdCwgcGFyYW1zLCBvYmosIGhlYWRlcnMpIHtcbiAgICAgICAgY29uc3QgX190aGlzID0gdGhpcztcbiAgICAgICAgY29uc3Qgc3ViamVjdCA9IG5ldyBCZWhhdmlvclN1YmplY3QobnVsbCk7XG4gICAgICAgIGNvbnN0IHJlc1BhcmFtcyA9IHBhcmFtcyB8fCB7fTtcbiAgICAgICAgY29uc3Qgcm91dGUgPSB3aGF0IHx8IHRoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXTtcbiAgICAgICAgY29uc3QgZmV0Y2hVcmwgPSB1cmxIYW5kbGVyLmZldGNoVXJsKHRoaXMsIHdoYXQpO1xuXG4gICAgICAgIGxldCBjYWxsT2JqID0gb2JqIHx8IHRoaXM7XG4gICAgICAgIC8vIGZhbGxiYWNrIHRvIGV0YWcgb24gcmVzdGFuZ3VsYXIgb2JqZWN0IChzaW5jZSBmb3IgY3VzdG9tIG1ldGhvZHMgd2UgcHJvYmFibHkgZG9uJ3QgZXhwbGljaXRseSBzcGVjaWZ5IHRoZSBldGFnIGZpZWxkKVxuICAgICAgICBjb25zdCBldGFnID0gY2FsbE9ialtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZXRhZ10gfHwgKG9wZXJhdGlvbiAhPT0gJ3Bvc3QnID8gdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZXRhZ10gOiBudWxsKTtcblxuICAgICAgICBpZiAoaXNPYmplY3QoY2FsbE9iaikgJiYgY29uZmlnLmlzUmVzdGFuZ3VsYXJpemVkKGNhbGxPYmopKSB7XG4gICAgICAgICAgY2FsbE9iaiA9IHN0cmlwUmVzdGFuZ3VsYXIoY2FsbE9iaik7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IGNvbmZpZy5mdWxsUmVxdWVzdEludGVyY2VwdG9yKFxuICAgICAgICAgIGNhbGxPYmosXG4gICAgICAgICAgb3BlcmF0aW9uLFxuICAgICAgICAgIHJvdXRlLFxuICAgICAgICAgIGZldGNoVXJsLFxuICAgICAgICAgIGhlYWRlcnMgfHwge30sXG4gICAgICAgICAgcmVzUGFyYW1zIHx8IHt9LFxuICAgICAgICAgIHRoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmh0dHBDb25maWddIHx8IHt9XG4gICAgICAgICk7XG5cbiAgICAgICAgbGV0IGZpbGxlZE9iamVjdCA9IHt9O1xuICAgICAgICBmaWxsZWRPYmplY3QgPSBjb25maWcudHJhbnNmb3JtRWxlbShmaWxsZWRPYmplY3QsIGZhbHNlLCByb3V0ZSwgc2VydmljZSk7XG5cbiAgICAgICAgY29uc3Qgb2tDYWxsYmFjayA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIGNvbnN0IHJlc0RhdGEgPSBnZXQocmVzcG9uc2UsICdib2R5Jyk7XG4gICAgICAgICAgY29uc3QgZnVsbFBhcmFtcyA9IGdldChyZXNwb25zZSwgJ2NvbmZpZy5wYXJhbXMnKTtcblxuICAgICAgICAgIGNvbnN0IGVsZW0gPSBwYXJzZVJlc3BvbnNlKHJlc0RhdGEsIG9wZXJhdGlvbiwgcm91dGUsIGZldGNoVXJsLCByZXNwb25zZSwgc3ViamVjdCk7XG5cbiAgICAgICAgICBpZiAoZWxlbSkge1xuICAgICAgICAgICAgbGV0IGRhdGE7XG4gICAgICAgICAgICBpZiAodHJ1ZSA9PT0gY29uZmlnLnBsYWluQnlEZWZhdWx0KSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZShzdWJqZWN0LCByZXNwb25zZSwgZWxlbSwgZmlsbGVkT2JqZWN0KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ3Bvc3QnICYmICFfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlc3Rhbmd1bGFyQ29sbGVjdGlvbl0pIHtcbiAgICAgICAgICAgICAgZGF0YSA9IHJlc3Rhbmd1bGFyaXplRWxlbShcbiAgICAgICAgICAgICAgICBfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhcmVudFJlc291cmNlXSxcbiAgICAgICAgICAgICAgICBlbGVtLFxuICAgICAgICAgICAgICAgIHJvdXRlLFxuICAgICAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgICAgICBmdWxsUGFyYW1zXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBkYXRhLCBmaWxsZWRPYmplY3QpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgZGF0YSA9IHJlc3Rhbmd1bGFyaXplRWxlbShcbiAgICAgICAgICAgICAgICBfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhcmVudFJlc291cmNlXSxcbiAgICAgICAgICAgICAgICBlbGVtLFxuICAgICAgICAgICAgICAgIF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdLFxuICAgICAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgICAgICBmdWxsUGFyYW1zXG4gICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgZGF0YVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuc2luZ2xlT25lXSA9IF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuc2luZ2xlT25lXTtcbiAgICAgICAgICAgICAgcmVzb2x2ZVByb21pc2Uoc3ViamVjdCwgcmVzcG9uc2UsIGRhdGEsIGZpbGxlZE9iamVjdCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZVByb21pc2Uoc3ViamVjdCwgcmVzcG9uc2UsIHVuZGVmaW5lZCwgZmlsbGVkT2JqZWN0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgZXJyb3JDYWxsYmFjayA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDMwNCAmJiBjb25maWcuaXNTYWZlKG9wZXJhdGlvbikpIHtcbiAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBfX3RoaXMsIGZpbGxlZE9iamVjdCk7XG4gICAgICAgICAgfSBlbHNlIGlmIChldmVyeShjb25maWcuZXJyb3JJbnRlcmNlcHRvcnMsIGZ1bmN0aW9uIChjYjogYW55KSB7XG4gICAgICAgICAgICByZXR1cm4gY2IocmVzcG9uc2UsIHN1YmplY3QsIG9rQ2FsbGJhY2spICE9PSBmYWxzZTtcbiAgICAgICAgICB9KSkge1xuICAgICAgICAgICAgLy8gdHJpZ2dlcmVkIGlmIG5vIGNhbGxiYWNrIHJldHVybnMgZmFsc2VcbiAgICAgICAgICAgIHN1YmplY3QuZXJyb3IocmVzcG9uc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgLy8gT3ZlcnJpZGluZyBIVFRQIE1ldGhvZFxuICAgICAgICBsZXQgY2FsbE9wZXJhdGlvbiA9IG9wZXJhdGlvbjtcbiAgICAgICAgbGV0IGNhbGxIZWFkZXJzID0gZXh0ZW5kKHt9LCByZXF1ZXN0LmhlYWRlcnMpO1xuICAgICAgICBjb25zdCBpc092ZXJyaWRlT3BlcmF0aW9uID0gY29uZmlnLmlzT3ZlcnJpZGVuTWV0aG9kKG9wZXJhdGlvbik7XG4gICAgICAgIGlmIChpc092ZXJyaWRlT3BlcmF0aW9uKSB7XG4gICAgICAgICAgY2FsbE9wZXJhdGlvbiA9ICdwb3N0JztcbiAgICAgICAgICBjYWxsSGVhZGVycyA9IGV4dGVuZChjYWxsSGVhZGVycywgeydYLUhUVFAtTWV0aG9kLU92ZXJyaWRlJzogb3BlcmF0aW9uID09PSAncmVtb3ZlJyA/ICdERUxFVEUnIDogb3BlcmF0aW9uLnRvVXBwZXJDYXNlKCl9KTtcbiAgICAgICAgfSBlbHNlIGlmIChjb25maWcuanNvbnAgJiYgY2FsbE9wZXJhdGlvbiA9PT0gJ2dldCcpIHtcbiAgICAgICAgICBjYWxsT3BlcmF0aW9uID0gJ2pzb25wJztcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb25maWcuaXNTYWZlKG9wZXJhdGlvbikpIHtcbiAgICAgICAgICBpZiAoaXNPdmVycmlkZU9wZXJhdGlvbikge1xuICAgICAgICAgICAgdXJsSGFuZGxlci5yZXNvdXJjZSh0aGlzLCAkaHR0cCwgcmVxdWVzdC5odHRwQ29uZmlnLCBjYWxsSGVhZGVycywgcmVxdWVzdC5wYXJhbXMsXG4gICAgICAgICAgICAgIHdoYXQsIGV0YWcsIGNhbGxPcGVyYXRpb24pW2NhbGxPcGVyYXRpb25dKHt9KS5zdWJzY3JpYmUob2tDYWxsYmFjaywgZXJyb3JDYWxsYmFjayk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHVybEhhbmRsZXIucmVzb3VyY2UodGhpcywgJGh0dHAsIHJlcXVlc3QuaHR0cENvbmZpZywgY2FsbEhlYWRlcnMsIHJlcXVlc3QucGFyYW1zLFxuICAgICAgICAgICAgICB3aGF0LCBldGFnLCBjYWxsT3BlcmF0aW9uKVtjYWxsT3BlcmF0aW9uXSgpLnN1YnNjcmliZShva0NhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdXJsSGFuZGxlci5yZXNvdXJjZSh0aGlzLCAkaHR0cCwgcmVxdWVzdC5odHRwQ29uZmlnLCBjYWxsSGVhZGVycywgcmVxdWVzdC5wYXJhbXMsXG4gICAgICAgICAgICB3aGF0LCBldGFnLCBjYWxsT3BlcmF0aW9uKVtjYWxsT3BlcmF0aW9uXShyZXF1ZXN0LmVsZW1lbnQpLnN1YnNjcmliZShva0NhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZVJlc3BvbnNlKHN1YmplY3QsIGZhbHNlLCBmaWxsZWRPYmplY3QpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBnZXRGdW5jdGlvbihwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgnZ2V0JywgdW5kZWZpbmVkLCBwYXJhbXMsIHVuZGVmaW5lZCwgaGVhZGVycyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGRlbGV0ZUZ1bmN0aW9uKHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKCdyZW1vdmUnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcHV0RnVuY3Rpb24ocGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ3B1dCcsIHVuZGVmaW5lZCwgcGFyYW1zLCB1bmRlZmluZWQsIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBwb3N0RnVuY3Rpb24od2hhdCwgZWxlbSwgcGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ3Bvc3QnLCB3aGF0LCBwYXJhbXMsIGVsZW0sIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBoZWFkRnVuY3Rpb24ocGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ2hlYWQnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gdHJhY2VGdW5jdGlvbihwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgndHJhY2UnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gb3B0aW9uc0Z1bmN0aW9uKHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKCdvcHRpb25zJywgdW5kZWZpbmVkLCBwYXJhbXMsIHVuZGVmaW5lZCwgaGVhZGVycyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHBhdGNoRnVuY3Rpb24oZWxlbSwgcGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ3BhdGNoJywgdW5kZWZpbmVkLCBwYXJhbXMsIGVsZW0sIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBjdXN0b21GdW5jdGlvbihvcGVyYXRpb24sIHBhdGgsIHBhcmFtcywgaGVhZGVycywgZWxlbSkge1xuICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKG9wZXJhdGlvbiwgcGF0aCwgcGFyYW1zLCBlbGVtLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gYWRkUmVzdGFuZ3VsYXJNZXRob2RGdW5jdGlvbihuYW1lLCBvcGVyYXRpb24sIHBhdGgsIGRlZmF1bHRQYXJhbXMsIGRlZmF1bHRIZWFkZXJzLCBkZWZhdWx0RWxlbSkge1xuICAgICAgICBsZXQgYmluZGVkRnVuY3Rpb247XG4gICAgICAgIGlmIChvcGVyYXRpb24gPT09ICdnZXRMaXN0Jykge1xuICAgICAgICAgIGJpbmRlZEZ1bmN0aW9uID0gYmluZChmZXRjaEZ1bmN0aW9uLCB0aGlzLCBwYXRoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBiaW5kZWRGdW5jdGlvbiA9IGJpbmQoY3VzdG9tRnVuY3Rpb24sIHRoaXMsIG9wZXJhdGlvbiwgcGF0aCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjcmVhdGVkRnVuY3Rpb24gPSBmdW5jdGlvbiAocGFyYW1zLCBoZWFkZXJzLCBlbGVtKSB7XG4gICAgICAgICAgY29uc3QgY2FsbFBhcmFtcyA9IGRlZmF1bHRzKHtcbiAgICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgICAgaGVhZGVyczogaGVhZGVycyxcbiAgICAgICAgICAgIGVsZW06IGVsZW1cbiAgICAgICAgICB9LCB7XG4gICAgICAgICAgICBwYXJhbXM6IGRlZmF1bHRQYXJhbXMsXG4gICAgICAgICAgICBoZWFkZXJzOiBkZWZhdWx0SGVhZGVycyxcbiAgICAgICAgICAgIGVsZW06IGRlZmF1bHRFbGVtXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIGJpbmRlZEZ1bmN0aW9uKGNhbGxQYXJhbXMucGFyYW1zLCBjYWxsUGFyYW1zLmhlYWRlcnMsIGNhbGxQYXJhbXMuZWxlbSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKGNvbmZpZy5pc1NhZmUob3BlcmF0aW9uKSkge1xuICAgICAgICAgIHRoaXNbbmFtZV0gPSBjcmVhdGVkRnVuY3Rpb247XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpc1tuYW1lXSA9IGZ1bmN0aW9uIChlbGVtLCBwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgICAgIHJldHVybiBjcmVhdGVkRnVuY3Rpb24ocGFyYW1zLCBoZWFkZXJzLCBlbGVtKTtcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHdpdGhDb25maWd1cmF0aW9uRnVuY3Rpb24oY29uZmlndXJlcikge1xuICAgICAgICBjb25zdCBuZXdDb25maWcgPSBjbG9uZShvbWl0KGNvbmZpZywgJ2NvbmZpZ3VyYXRpb24nKSk7XG4gICAgICAgIFJlc3Rhbmd1bGFyQ29uZmlndXJlcihuZXdDb25maWcsIG5ld0NvbmZpZyk7XG4gICAgICAgIGNvbmZpZ3VyZXIobmV3Q29uZmlnKTtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVNlcnZpY2VGb3JDb25maWd1cmF0aW9uKG5ld0NvbmZpZyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHRvU2VydmljZShyb3V0ZSwgcGFyZW50KSB7XG4gICAgICAgIGNvbnN0IGtub3duQ29sbGVjdGlvbk1ldGhvZHMgPSB2YWx1ZXMoY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzKTtcbiAgICAgICAgY29uc3Qgc2VydjogYW55ID0ge307XG4gICAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSAocGFyZW50IHx8IHNlcnZpY2UpLmFsbChyb3V0ZSk7XG4gICAgICAgIHNlcnYub25lID0gYmluZChvbmUsIChwYXJlbnQgfHwgc2VydmljZSksIHBhcmVudCwgcm91dGUpO1xuICAgICAgICBzZXJ2LmFsbCA9IGJpbmQoY29sbGVjdGlvbi5hbGwsIGNvbGxlY3Rpb24pO1xuICAgICAgICBzZXJ2LnBvc3QgPSBiaW5kKGNvbGxlY3Rpb24ucG9zdCwgY29sbGVjdGlvbik7XG4gICAgICAgIHNlcnYuZ2V0TGlzdCA9IGJpbmQoY29sbGVjdGlvbi5nZXRMaXN0LCBjb2xsZWN0aW9uKTtcbiAgICAgICAgc2Vydi53aXRoSHR0cENvbmZpZyA9IGJpbmQoY29sbGVjdGlvbi53aXRoSHR0cENvbmZpZywgY29sbGVjdGlvbik7XG4gICAgICAgIHNlcnYuZ2V0ID0gYmluZChjb2xsZWN0aW9uLmdldCwgY29sbGVjdGlvbik7XG5cbiAgICAgICAgZm9yIChjb25zdCBwcm9wIGluIGNvbGxlY3Rpb24pIHtcbiAgICAgICAgICBpZiAoY29sbGVjdGlvbi5oYXNPd25Qcm9wZXJ0eShwcm9wKSAmJiBpc0Z1bmN0aW9uKGNvbGxlY3Rpb25bcHJvcF0pICYmICFpbmNsdWRlcyhrbm93bkNvbGxlY3Rpb25NZXRob2RzLCBwcm9wKSkge1xuICAgICAgICAgICAgc2Vydltwcm9wXSA9IGJpbmQoY29sbGVjdGlvbltwcm9wXSwgY29sbGVjdGlvbik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHNlcnY7XG4gICAgICB9XG5cbiAgICAgIFJlc3Rhbmd1bGFyQ29uZmlndXJlcihzZXJ2aWNlLCBjb25maWcpO1xuXG4gICAgICBzZXJ2aWNlLmNvcHkgPSBiaW5kKGNvcHlSZXN0YW5ndWxhcml6ZWRFbGVtZW50LCBzZXJ2aWNlKTtcblxuICAgICAgc2VydmljZS5zZXJ2aWNlID0gYmluZCh0b1NlcnZpY2UsIHNlcnZpY2UpO1xuXG4gICAgICBzZXJ2aWNlLndpdGhDb25maWcgPSBiaW5kKHdpdGhDb25maWd1cmF0aW9uRnVuY3Rpb24sIHNlcnZpY2UpO1xuXG4gICAgICBzZXJ2aWNlLm9uZSA9IGJpbmQob25lLCBzZXJ2aWNlLCBudWxsKTtcblxuICAgICAgc2VydmljZS5hbGwgPSBiaW5kKGFsbCwgc2VydmljZSwgbnVsbCk7XG5cbiAgICAgIHNlcnZpY2Uuc2V2ZXJhbCA9IGJpbmQoc2V2ZXJhbCwgc2VydmljZSwgbnVsbCk7XG5cbiAgICAgIHNlcnZpY2Uub25lVXJsID0gYmluZChvbmVVcmwsIHNlcnZpY2UsIG51bGwpO1xuXG4gICAgICBzZXJ2aWNlLmFsbFVybCA9IGJpbmQoYWxsVXJsLCBzZXJ2aWNlLCBudWxsKTtcblxuICAgICAgc2VydmljZS5zdHJpcFJlc3Rhbmd1bGFyID0gYmluZChzdHJpcFJlc3Rhbmd1bGFyLCBzZXJ2aWNlKTtcblxuICAgICAgc2VydmljZS5yZXN0YW5ndWxhcml6ZUVsZW1lbnQgPSBiaW5kKHJlc3Rhbmd1bGFyaXplRWxlbSwgc2VydmljZSk7XG5cbiAgICAgIHNlcnZpY2UucmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uID0gYmluZChyZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb25BbmRFbGVtZW50cywgc2VydmljZSk7XG5cbiAgICAgIHJldHVybiBzZXJ2aWNlO1xuICAgIH1cblxuICAgIHJldHVybiBjcmVhdGVTZXJ2aWNlRm9yQ29uZmlndXJhdGlvbihnbG9iYWxDb25maWd1cmF0aW9uKTtcbiAgfVxuXG59XG4iLCJpbXBvcnQgeyBNb2R1bGVXaXRoUHJvdmlkZXJzLCBOZ01vZHVsZSwgT3B0aW9uYWwsIFNraXBTZWxmLCBJbmplY3Rpb25Ub2tlbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IFJFU1RBTkdVTEFSLCBSZXN0YW5ndWxhckZhY3RvcnkgfSBmcm9tICcuL25neC1yZXN0YW5ndWxhci5jb25maWcnO1xuaW1wb3J0IHsgUmVzdGFuZ3VsYXIgfSBmcm9tICcuL25neC1yZXN0YW5ndWxhcic7XG5pbXBvcnQgeyBSZXN0YW5ndWxhckh0dHAgfSBmcm9tICcuL25neC1yZXN0YW5ndWxhci1odHRwJztcblxuZXhwb3J0IGNvbnN0IENPTkZJR19PQkogPSBuZXcgSW5qZWN0aW9uVG9rZW48c3RyaW5nPignY29uZmlnT2JqJyk7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtIdHRwQ2xpZW50TW9kdWxlXSxcbiAgcHJvdmlkZXJzOiBbUmVzdGFuZ3VsYXJIdHRwLCBSZXN0YW5ndWxhcl1cbn0pXG5leHBvcnQgY2xhc3MgUmVzdGFuZ3VsYXJNb2R1bGUge1xuXG4gIGNvbnN0cnVjdG9yKEBPcHRpb25hbCgpIEBTa2lwU2VsZigpIHBhcmVudE1vZHVsZTogUmVzdGFuZ3VsYXJNb2R1bGUpIHtcbiAgICBpZiAocGFyZW50TW9kdWxlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdSZXN0YW5ndWxhck1vZHVsZSBpcyBhbHJlYWR5IGxvYWRlZC4gSW1wb3J0IGl0IGluIHRoZSBBcHBNb2R1bGUgb25seScpO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBmb3JSb290KGNvbmZpZ0Z1bmN0aW9uPzogKHByb3ZpZGVyOiBhbnksIC4uLmFyZzogYW55W10pID0+IHZvaWQpOiBNb2R1bGVXaXRoUHJvdmlkZXJzO1xuICBzdGF0aWMgZm9yUm9vdChwcm92aWRlcnM/OiBhbnlbXSwgY29uZmlnRnVuY3Rpb24/OiAocHJvdmlkZXI6IGFueSwgLi4uYXJnOiBhbnlbXSkgPT4gdm9pZCk6IE1vZHVsZVdpdGhQcm92aWRlcnM7XG4gIHN0YXRpYyBmb3JSb290KGNvbmZpZzE/LCBjb25maWcyPyk6IE1vZHVsZVdpdGhQcm92aWRlcnMge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogUmVzdGFuZ3VsYXJNb2R1bGUsXG4gICAgICBwcm92aWRlcnM6IFtcbiAgICAgICAge3Byb3ZpZGU6IENPTkZJR19PQkosIHVzZVZhbHVlOiBbY29uZmlnMSwgY29uZmlnMl19LFxuICAgICAgICB7cHJvdmlkZTogUkVTVEFOR1VMQVIsIHVzZUZhY3Rvcnk6IFJlc3Rhbmd1bGFyRmFjdG9yeSwgZGVwczogW0NPTkZJR19PQkpdfSxcbiAgICAgIF1cbiAgICB9O1xuICB9XG5cbn1cbiJdLCJuYW1lcyI6WyJ2YWx1ZXMiLCJtYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFLQSxJQUFhLFdBQVcsR0FBRyxJQUFJLGNBQWMsQ0FBUyx1QkFBdUIsQ0FBQzs7Ozs7QUFFOUUsU0FBZ0Isa0JBQWtCLENBQUMsRUFBOEI7UUFBOUIsa0JBQThCLEVBQTdCLDBCQUFrQixFQUFFLGdCQUFROztRQUMxRCxXQUFXLEdBQUcsRUFBRTs7UUFDaEIsRUFBRSxHQUFHLGtCQUFrQjtJQUUzQixJQUFJLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1FBQy9CLFdBQVcsR0FBRyxrQkFBa0IsQ0FBQztRQUNqQyxFQUFFLEdBQUcsUUFBUSxDQUFDO0tBQ2Y7SUFFRCxPQUFPLEVBQUMsRUFBRSxJQUFBLEVBQUUsV0FBVyxhQUFBLEVBQUMsQ0FBQztDQUMxQjs7Ozs7O0FDakJELEFBSUE7SUFBQTtLQW1FQzs7Ozs7SUFqRVEsK0JBQWE7Ozs7SUFBcEIsVUFBcUIsT0FBTzs7WUFDcEIsa0JBQWtCLEdBQUcsaUJBQWlCLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQzs7WUFDL0UsY0FBYyxHQUFHLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7O1lBQ3hFLFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTs7WUFDekMsZUFBZSxHQUFHLE9BQU8sQ0FBQyxlQUFlLElBQUksS0FBSzs7WUFFcEQsT0FBTyxHQUFHLElBQUksV0FBVyxDQUMzQixVQUFVLEVBQ1YsT0FBTyxDQUFDLEdBQUcsRUFDWCxPQUFPLENBQUMsSUFBSSxFQUNaO1lBQ0UsT0FBTyxFQUFFLGNBQWM7WUFDdkIsTUFBTSxFQUFFLGtCQUFrQjtZQUMxQixZQUFZLEVBQUUsT0FBTyxDQUFDLFlBQVk7WUFDbEMsZUFBZSxpQkFBQTtTQUNoQixDQUNGO1FBRUQsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzFFLE9BQU8sR0FBRyxJQUFJLFdBQVcsQ0FDdkIsVUFBVSxFQUNWLE9BQU8sQ0FBQyxHQUFHLEVBQ1g7Z0JBQ0UsT0FBTyxFQUFFLGNBQWM7Z0JBQ3ZCLE1BQU0sRUFBRSxrQkFBa0I7Z0JBQzFCLFlBQVksRUFBRSxPQUFPLENBQUMsWUFBWTtnQkFDbEMsZUFBZSxpQkFBQTthQUNoQixDQUNGLENBQUM7U0FDSDtRQUNELE9BQU8sT0FBTyxDQUFDO0tBQ2hCOzs7OztJQUVNLDBDQUF3Qjs7OztJQUEvQixVQUFnQyxXQUFXOztZQUNuQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQzs7WUFDOUMsTUFBTSxHQUFlLElBQUksVUFBVSxFQUFFO2dDQUU5QixHQUFHOztnQkFDUixLQUFLLEdBQVEsa0JBQWtCLENBQUMsR0FBRyxDQUFDO1lBRXhDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDeEIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEdBQUc7b0JBQ3pCLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztpQkFDbEMsQ0FBQyxDQUFDO2FBQ0o7aUJBQU07Z0JBQ0wsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7b0JBQzdCLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMvQjtnQkFDRCxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDcEM7U0FDRjtRQWJELEtBQUssSUFBTSxHQUFHLElBQUksa0JBQWtCO29CQUF6QixHQUFHO1NBYWI7UUFFRCxPQUFPLE1BQU0sQ0FBQztLQUNmOzs7OztJQUVNLHNDQUFvQjs7OztJQUEzQixVQUE0QixPQUFPO1FBQ2pDLEtBQUssSUFBTSxHQUFHLElBQUksT0FBTyxFQUFFOztnQkFDbkIsS0FBSyxHQUFRLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDL0IsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQ2hDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ3JCO1NBQ0Y7UUFFRCxPQUFPLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztLQUM3QztJQUNILHdCQUFDO0NBQUEsSUFBQTs7Ozs7O0FDdkVEO0lBWUUseUJBQW1CLElBQWlCO1FBQWpCLFNBQUksR0FBSixJQUFJLENBQWE7S0FDbkM7Ozs7O0lBRUQsdUNBQWE7Ozs7SUFBYixVQUFjLE9BQU87O1lBQ2IsT0FBTyxHQUFHLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFFeEQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQzlCOzs7OztJQUVELGlDQUFPOzs7O0lBQVAsVUFBUSxPQUF5QjtRQUFqQyxpQkF3QkM7UUF2QkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7YUFDL0IsSUFBSSxDQUNILE1BQU0sQ0FBQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUssWUFBWSxZQUFZLEdBQUEsQ0FBQyxFQUM5QyxHQUFHLENBQUMsVUFBQyxRQUFhO1lBQ2hCLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFO2dCQUNoQixPQUFPLFVBQVUsQ0FBQyxJQUFJLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7YUFDcEQ7WUFDRCxPQUFPLFFBQVEsQ0FBQztTQUNqQixDQUFDLEVBQ0YsR0FBRyxDQUFDLFVBQUEsUUFBUTtZQUNWLFFBQVEsQ0FBQyxNQUFNLEdBQUcsRUFBQyxNQUFNLEVBQUUsT0FBTyxFQUFDLENBQUM7WUFDcEMsT0FBTyxRQUFRLENBQUM7U0FDakIsQ0FBQyxFQUNGLFVBQVUsQ0FBQyxVQUFBLEdBQUc7WUFDWixHQUFHLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztZQUN0QixHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7WUFDckIsR0FBRyxDQUFDLGFBQWEsR0FBRyxVQUFDLFVBQVc7Z0JBQzlCLE9BQU8sS0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksT0FBTyxDQUFDLENBQUM7YUFDNUMsQ0FBQztZQUVGLE9BQU8sVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3hCLENBQUMsQ0FDSCxDQUFDO0tBQ0g7O2dCQXBDRixVQUFVOzs7O2dCQVJGLFdBQVc7O0lBNkNwQixzQkFBQztDQUFBOzs7Ozs7Ozs7OztBQ3pCRCxTQUFnQixxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsYUFBYTtJQUN6RCxNQUFNLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQzs7Ozs7UUFLL0IsV0FBVyxHQUFHLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQztJQUNsRSxhQUFhLENBQUMsTUFBTSxHQUFHLFVBQVUsU0FBUztRQUN4QyxPQUFPLFFBQVEsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7S0FDdkQsQ0FBQzs7UUFFSSxlQUFlLEdBQUcsZUFBZTtJQUN2QyxhQUFhLENBQUMsYUFBYSxHQUFHLFVBQVUsTUFBTTtRQUM1QyxPQUFPLFdBQVcsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLElBQUksTUFBTSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUM7WUFDaEYsTUFBTSxJQUFJLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3RDLGFBQWEsQ0FBQyxXQUFXLENBQUM7S0FDN0IsQ0FBQztJQUVGLGFBQWEsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQztJQUN0RyxNQUFNLENBQUMsc0JBQXNCLEdBQUcsVUFBVSxLQUFLO1FBQzdDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0tBQ25DLENBQUM7Ozs7SUFJRixhQUFhLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7SUFDeEYsTUFBTSxDQUFDLFVBQVUsR0FBRyxVQUFVLFVBQVU7UUFDdEMsYUFBYSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUM1QyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUM5QyxVQUFVLENBQUM7UUFDYixPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7Ozs7SUFLRixhQUFhLENBQUMsV0FBVyxHQUFHLGFBQWEsQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDO0lBQzVELE1BQU0sQ0FBQyxjQUFjLEdBQUcsVUFBVSxjQUFjO1FBQzlDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsY0FBYyxDQUFDO1FBQzNDLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQzs7OztJQUtGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxhQUFhLENBQUMsaUJBQWlCLElBQUksRUFBRSxDQUFDO0lBQ3hFLE1BQU0sQ0FBQyxvQkFBb0IsR0FBRyxVQUFVQSxTQUFNO1FBQzVDLGFBQWEsQ0FBQyxpQkFBaUIsR0FBR0EsU0FBTSxDQUFDO1FBQ3pDLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQzs7OztJQUtGLGFBQWEsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDLGNBQWMsSUFBSSxLQUFLLENBQUM7SUFDckUsTUFBTSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsS0FBSztRQUN4QyxhQUFhLENBQUMsY0FBYyxHQUFHLEtBQUssS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUM3RCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixhQUFhLENBQUMsY0FBYyxHQUFHLFVBQVUsZUFBZSxFQUFFLEdBQUc7UUFDM0QsT0FBTyxRQUFRLENBQUMsR0FBRyxFQUFFLGVBQWUsRUFBRSxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztLQUN4RSxDQUFDO0lBRUYsYUFBYSxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDO0lBQ2hHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsVUFBVSxNQUFNO1FBQ3BDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO0tBQ2xDLENBQUM7SUFFRixhQUFhLENBQUMsb0JBQW9CLEdBQUcsYUFBYSxDQUFDLG9CQUFvQixJQUFJO1FBQ3pFLEdBQUcsRUFBRSxFQUFFO1FBQ1AsSUFBSSxFQUFFLEVBQUU7UUFDUixHQUFHLEVBQUUsRUFBRTtRQUNQLE1BQU0sRUFBRSxFQUFFO1FBQ1YsTUFBTSxFQUFFLEVBQUU7S0FDWCxDQUFDO0lBRUYsTUFBTSxDQUFDLHVCQUF1QixHQUFHLFVBQVUsTUFBTSxFQUFFLE1BQU07O1lBQ25ELE9BQU8sR0FBRyxFQUFFOztZQUNWLE1BQU0sR0FBRyxNQUFNLElBQUksTUFBTTtRQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3hCLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQixPQUFPLEdBQUcsTUFBTSxDQUFDO2FBQ2xCO2lCQUFNO2dCQUNMLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDdEI7U0FDRjthQUFNO1lBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUN4QjtRQUVELElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxNQUFNO1lBQzVCLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUM7U0FDckQsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBRUYsTUFBTSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUM7SUFFMUQsYUFBYSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQztJQUNsRSxNQUFNLENBQUMsaUJBQWlCLEdBQUcsVUFBVSxPQUFPO1FBQzFDLGFBQWEsQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDO1FBQ3ZDLE1BQU0sQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDLGNBQWMsQ0FBQztRQUNyRCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixNQUFNLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQyxjQUFjLENBQUM7Ozs7SUFNckQsYUFBYSxDQUFDLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsSUFBSSxTQUFTLENBQUM7SUFDdkYsTUFBTSxDQUFDLHdCQUF3QixHQUFHLFVBQVUsTUFBTTtRQUNoRCxhQUFhLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDO1FBQzdDLE1BQU0sQ0FBQyxxQkFBcUIsR0FBRyxhQUFhLENBQUMscUJBQXFCLENBQUM7UUFDbkUsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBQ0YsTUFBTSxDQUFDLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQzs7OztJQUtuRSxhQUFhLENBQUMsZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQztJQUN0RSxNQUFNLENBQUMsbUJBQW1CLEdBQUcsVUFBVUEsU0FBTTs7WUFDckMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxFQUFFLEVBQUVBLFNBQU0sQ0FBQztRQUNyQyxJQUFJLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLEVBQUU7WUFDekQsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQjtRQUNELGFBQWEsQ0FBQyxnQkFBZ0IsR0FBRyxVQUFVLENBQUM7UUFDNUMsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBRUYsYUFBYSxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ3JGLE1BQU0sQ0FBQyxRQUFRLEdBQUcsVUFBVSxNQUFNO1FBQ2hDLGFBQWEsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO0tBQzlCLENBQUM7SUFFRixhQUFhLENBQUMsaUJBQWlCLEdBQUcsVUFBVSxNQUFNLEVBQUVBLFNBQU07O1lBQ2xELE1BQU0sR0FBR0EsU0FBTSxJQUFJLGFBQWEsQ0FBQyxnQkFBZ0I7UUFDdkQsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsR0FBVztZQUNwRCxPQUFPLEdBQUcsQ0FBQyxXQUFXLEVBQUUsS0FBSyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDbkQsQ0FBQyxDQUFDLENBQUM7S0FDTCxDQUFDOzs7O0lBS0YsYUFBYSxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxJQUFJLE1BQU0sQ0FBQztJQUM5RCxNQUFNLENBQUMsYUFBYSxHQUFHLFVBQVUsSUFBSTtRQUNuQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsRUFBRTtZQUMvQyxNQUFNLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7U0FDbkQ7UUFFRCxhQUFhLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUNoQyxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7Ozs7Ozs7Ozs7O0lBWUYsYUFBYSxDQUFDLGlCQUFpQixHQUFHLGFBQWEsQ0FBQyxpQkFBaUIsSUFBSTtRQUNuRSxFQUFFLEVBQUUsSUFBSTtRQUNSLEtBQUssRUFBRSxPQUFPO1FBQ2QsY0FBYyxFQUFFLGdCQUFnQjtRQUNoQyxxQkFBcUIsRUFBRSx1QkFBdUI7UUFDOUMsWUFBWSxFQUFFLGdCQUFnQjtRQUM5QixJQUFJLEVBQUUsaUJBQWlCO1FBQ3ZCLFFBQVEsRUFBRSxNQUFNO1FBQ2hCLEdBQUcsRUFBRSxLQUFLO1FBQ1YsT0FBTyxFQUFFLFNBQVM7UUFDbEIsR0FBRyxFQUFFLEtBQUs7UUFDVixJQUFJLEVBQUUsTUFBTTtRQUNaLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLElBQUksRUFBRSxNQUFNO1FBQ1osS0FBSyxFQUFFLE9BQU87UUFDZCxPQUFPLEVBQUUsU0FBUztRQUNsQixLQUFLLEVBQUUsT0FBTztRQUNkLGlCQUFpQixFQUFFLG1CQUFtQjtRQUN0QyxlQUFlLEVBQUUsaUJBQWlCO1FBQ2xDLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLG9CQUFvQixFQUFFLHNCQUFzQjtRQUM1QyxhQUFhLEVBQUUsZUFBZTtRQUM5QixLQUFLLEVBQUUsT0FBTztRQUNkLEdBQUcsRUFBRSxLQUFLO1FBQ1YsVUFBVSxFQUFFLGNBQWM7UUFDMUIsU0FBUyxFQUFFLFdBQVc7UUFDdEIsR0FBRyxFQUFFLEtBQUs7UUFDVixHQUFHLEVBQUUsS0FBSztRQUNWLE9BQU8sRUFBRSxTQUFTO1FBQ2xCLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLE1BQU0sRUFBRSxRQUFRO1FBQ2hCLFNBQVMsRUFBRSxXQUFXO1FBQ3RCLFdBQVcsRUFBRSxhQUFhO1FBQzFCLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLFlBQVksRUFBRSxjQUFjO1FBQzVCLFNBQVMsRUFBRSxXQUFXO1FBQ3RCLGFBQWEsRUFBRSxlQUFlO1FBQzlCLGVBQWUsRUFBRSxpQkFBaUI7UUFDbEMsS0FBSyxFQUFFLE9BQU87UUFDZCxPQUFPLEVBQUUsU0FBUztRQUNsQixNQUFNLEVBQUUsUUFBUTtRQUNoQixRQUFRLEVBQUUsVUFBVTtRQUNwQixLQUFLLEVBQUUsT0FBTztRQUNkLFNBQVMsRUFBRSxXQUFXO1FBQ3RCLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLFVBQVUsRUFBRSxZQUFZO1FBQ3hCLGNBQWMsRUFBRSxnQkFBZ0I7UUFDaEMsU0FBUyxFQUFFLFdBQVc7UUFDdEIsS0FBSyxFQUFFLE9BQU87UUFDZCxJQUFJLEVBQUUsTUFBTTtRQUNaLGVBQWUsRUFBRSxpQkFBaUI7S0FDbkMsQ0FBQztJQUNGLE1BQU0sQ0FBQyxvQkFBb0IsR0FBRyxVQUFVLFNBQVM7UUFDL0MsYUFBYSxDQUFDLGlCQUFpQjtZQUM3QixNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN6RCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixhQUFhLENBQUMsaUJBQWlCLEdBQUcsVUFBVSxHQUFHO1FBQzdDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUM7S0FDL0QsQ0FBQztJQUVGLGFBQWEsQ0FBQyxjQUFjLEdBQUcsVUFBVSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUs7O1lBQ25ELFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7WUFDL0IsT0FBTyxHQUFHLElBQUk7UUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFBRSxVQUFVLElBQVM7WUFDM0MsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNuQixPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3pCLENBQUMsQ0FBQzs7WUFDRyxLQUFLLEdBQVEsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNuQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQztJQUVGLGFBQWEsQ0FBQyxnQkFBZ0IsR0FBRyxVQUFVLEtBQUssRUFBRSxJQUFJOztZQUM5QyxVQUFVLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7O1lBQy9CLE9BQU8sR0FBUSxJQUFJO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxJQUFJO1lBQzdCLElBQUksT0FBTyxFQUFFO2dCQUNYLE9BQU8sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekI7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN2QixDQUFDO0lBRUYsYUFBYSxDQUFDLFdBQVcsR0FBRyxVQUFVLElBQUksRUFBRSxFQUFFO1FBQzVDLGFBQWEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDM0UsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBRUYsYUFBYSxDQUFDLGFBQWEsR0FBRyxVQUFVLElBQUk7UUFDMUMsT0FBTyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztLQUNqRixDQUFDO0lBRUYsYUFBYSxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQU07UUFDeEMsT0FBTyxFQUFFLEtBQUssTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQ2pFLENBQUM7SUFFRixhQUFhLENBQUMsWUFBWSxHQUFHLFVBQVUsSUFBSSxFQUFFLEdBQUc7UUFDOUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNsRixPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixhQUFhLENBQUMsY0FBYyxHQUFHLFVBQVUsSUFBSTtRQUMzQyxPQUFPLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ3ZGLENBQUM7SUFFRixhQUFhLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLEdBQUcsS0FBSyxHQUFHLGFBQWEsQ0FBQyxlQUFlLENBQUM7SUFDbkgsTUFBTSxDQUFDLGtCQUFrQixHQUFHLFVBQVUsS0FBSztRQUN6QyxhQUFhLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztRQUN0QyxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixhQUFhLENBQUMsdUJBQXVCLEdBQUcsVUFBVSxJQUFJOztZQUM5QyxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUM7O1lBQ2pFLFFBQVEsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLFlBQVksR0FBRyxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztRQUN6RyxPQUFPLFFBQVEsQ0FBQztLQUNqQixDQUFDOzs7Ozs7OztJQVVGLGFBQWEsQ0FBQyxvQkFBb0IsR0FBRyxhQUFhLENBQUMsb0JBQW9CLFlBQU8sYUFBYSxDQUFDLG9CQUFvQixJQUFJLEVBQUUsQ0FBQztJQUV2SCxhQUFhLENBQUMsMEJBQTBCLEdBQUcsVUFBVSxJQUFJO1FBQ3ZELE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQztLQUNuQixDQUFDO0lBRUYsYUFBYSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPOztZQUNqRixZQUFZLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQztRQUM5RCxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDOztZQUN4RCxPQUFPLEdBQUcsSUFBSTtRQUNsQixJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsV0FBZ0I7WUFDM0MsT0FBTyxHQUFHLFdBQVcsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUN0QyxJQUFJLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNqQyxDQUFDLENBQUM7UUFDSCxPQUFPLE9BQU8sQ0FBQztLQUNoQixDQUFDO0lBRUYsTUFBTSxDQUFDLHNCQUFzQixHQUFHLFVBQVUsU0FBUztRQUNqRCxhQUFhLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25ELE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQztJQUVGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxhQUFhLENBQUMsaUJBQWlCLFlBQU8sYUFBYSxDQUFDLGlCQUFpQixJQUFJLEVBQUUsQ0FBQztJQUM5RyxNQUFNLENBQUMsbUJBQW1CLEdBQUcsVUFBVSxXQUFXO1FBQ2hELGFBQWEsQ0FBQyxpQkFBaUIsYUFBSSxXQUFXLEdBQUssYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDcEYsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBRUYsTUFBTSxDQUFDLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztJQUM5RCxNQUFNLENBQUMsb0JBQW9CLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDO0lBQzVELE1BQU0sQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUMsbUJBQW1CLENBQUM7Ozs7Ozs7SUFVeEQsYUFBYSxDQUFDLG1CQUFtQixHQUFHLGFBQWEsQ0FBQyxtQkFBbUIsWUFBTyxhQUFhLENBQUMsbUJBQW1CLElBQUksRUFBRSxDQUFDO0lBRXBILGFBQWEsQ0FBQyxrQkFBa0IsR0FBRyxVQUFVLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVU7UUFDckcsT0FBTztZQUNMLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLE1BQU0sRUFBRSxNQUFNO1lBQ2QsVUFBVSxFQUFFLFVBQVU7U0FDdkIsQ0FBQztLQUNILENBQUM7SUFFRixhQUFhLENBQUMsc0JBQXNCLEdBQUcsVUFBVSxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVOztZQUNuRyxZQUFZLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQzs7WUFDdkQsY0FBYyxHQUFHLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVLENBQUM7UUFDbkgsT0FBTyxNQUFNLENBQUMsWUFBWSxFQUFFLFVBQVUsT0FBWSxFQUFFLFdBQWdCOztnQkFFNUQsaUJBQWlCLEdBQVEsV0FBVyxDQUN4QyxPQUFPLENBQUMsT0FBTyxFQUNmLFNBQVMsRUFDVCxJQUFJLEVBQ0osR0FBRyxFQUNILE9BQU8sQ0FBQyxPQUFPLEVBQ2YsT0FBTyxDQUFDLE1BQU0sRUFDZCxPQUFPLENBQUMsVUFBVSxDQUNuQjtZQUNELE9BQU8sTUFBTSxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1NBQzNDLEVBQUUsY0FBYyxDQUFDLENBQUM7S0FDcEIsQ0FBQztJQUVGLE1BQU0sQ0FBQyxxQkFBcUIsR0FBRyxVQUFVLFdBQVc7UUFDbEQsYUFBYSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVU7WUFDdEcsT0FBTztnQkFDTCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUM7Z0JBQ2hELFVBQVUsRUFBRSxVQUFVO2FBQ3ZCLENBQUM7U0FDSCxDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixNQUFNLENBQUMscUJBQXFCLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDO0lBRTVELE1BQU0sQ0FBQyx5QkFBeUIsR0FBRyxVQUFVLFdBQVc7UUFDdEQsYUFBYSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNwRCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixNQUFNLENBQUMseUJBQXlCLEdBQUcsTUFBTSxDQUFDLHlCQUF5QixDQUFDO0lBRXBFLGFBQWEsQ0FBQywyQkFBMkIsR0FBRyxhQUFhLENBQUMsMkJBQTJCLElBQUksVUFBVSxJQUFJO1FBQ3JHLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQztJQUNGLE1BQU0sQ0FBQyw4QkFBOEIsR0FBRyxVQUFVLElBQUk7UUFDcEQsYUFBYSxDQUFDLDJCQUEyQixHQUFHLElBQUksQ0FBQztRQUNqRCxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixNQUFNLENBQUMsbUNBQW1DLEdBQUcsVUFBVSxXQUFXO1FBQ2hFLGFBQWEsQ0FBQyxnQ0FBZ0MsR0FBRyxXQUFXLENBQUM7UUFDN0QsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDOzs7Ozs7OztJQVNGLGFBQWEsQ0FBQyxxQkFBcUIsR0FBRyxhQUFhLENBQUMscUJBQXFCLElBQUksVUFBVSxJQUFJO1FBQ3pGLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQztJQUNGLE1BQU0sQ0FBQyx3QkFBd0IsR0FBRyxVQUFVLElBQUk7UUFDOUMsYUFBYSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQztRQUMzQyxPQUFPLElBQUksQ0FBQztLQUNiLENBQUM7SUFFRixhQUFhLENBQUMsZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLGdCQUFnQixJQUFJO1FBQ2pFLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQztJQUNGLE1BQU0sQ0FBQyxhQUFhLEdBQUcsVUFBVUEsU0FBTTtRQUNyQyxJQUFJLE9BQU8sQ0FBQ0EsU0FBTSxDQUFDLEVBQUU7WUFDbkIsYUFBYSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsS0FBSztnQkFDOUMsT0FBTyxDQUFDLFFBQVEsQ0FBQ0EsU0FBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ2pDLENBQUM7U0FDSDthQUFNLElBQUksU0FBUyxDQUFDQSxTQUFNLENBQUMsRUFBRTtZQUM1QixhQUFhLENBQUMsZ0JBQWdCLEdBQUc7Z0JBQy9CLE9BQU8sQ0FBQ0EsU0FBTSxDQUFDO2FBQ2hCLENBQUM7U0FDSDtRQUNELE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQzs7Ozs7Ozs7OztJQVdGLGFBQWEsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztJQUN2RixNQUFNLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxTQUFTO1FBQzNDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1FBQ2pDLE9BQU8sSUFBSSxDQUFDO0tBQ2IsQ0FBQzs7OztJQUtGLGFBQWEsQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDLFlBQVksSUFBSSxFQUFFLENBQUM7SUFDOUQsTUFBTSxDQUFDLHFCQUFxQixHQUFHLFVBQVUsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFROztZQUM1RCxZQUFZLEdBQUcsSUFBSTs7WUFDbkIsV0FBVyxHQUFHLElBQUk7UUFDdEIsSUFBSSxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMxQixXQUFXLEdBQUcsU0FBUyxDQUFDO1NBQ3pCO2FBQU07WUFDTCxXQUFXLEdBQUcsUUFBUSxDQUFDO1lBQ3ZCLFlBQVksR0FBRyxTQUFTLENBQUM7U0FDMUI7O1lBRUcsZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7UUFDdkQsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3JCLGdCQUFnQixHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQzFEO1FBRUQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUk7WUFDeEMsSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFFO2dCQUNuRCxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMxQjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQyxDQUFDO1FBRUgsT0FBTyxNQUFNLENBQUM7S0FDZixDQUFDO0lBRUYsTUFBTSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsS0FBSyxFQUFFLEVBQUU7UUFDM0MsT0FBTyxNQUFNLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztLQUN0RCxDQUFDO0lBRUYsTUFBTSxDQUFDLFdBQVcsR0FBRyxVQUFVLEtBQUssRUFBRSxFQUFFO1FBQ3RDLE9BQU8sTUFBTSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FDdkQsQ0FBQztJQUVGLGFBQWEsQ0FBQyxhQUFhLEdBQUcsVUFBVSxJQUFJLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSztRQUNuRixJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN4RyxPQUFPLElBQUksQ0FBQztTQUNiOztZQUNLLGdCQUFnQixHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDOztZQUN0RCxXQUFXLEdBQUcsSUFBSTtRQUN0QixJQUFJLGdCQUFnQixFQUFFO1lBQ3BCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxVQUFVLFdBQTZEO2dCQUM1RixXQUFXLEdBQUcsV0FBVyxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQzthQUN0RCxDQUFDLENBQUM7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0tBQzNGLENBQUM7SUFFRixhQUFhLENBQUMsc0JBQXNCLEdBQUcsV0FBVyxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQztRQUN0RixLQUFLO1FBQ0wsYUFBYSxDQUFDLHNCQUFzQixDQUFDO0lBRXZDLE1BQU0sQ0FBQyw4QkFBOEIsR0FBRyxVQUFVLE1BQU07UUFDdEQsYUFBYSxDQUFDLHNCQUFzQixHQUFHLENBQUMsTUFBTSxDQUFDO0tBQ2hELENBQUM7SUFFRixhQUFhLENBQUMsWUFBWSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLEdBQUcsS0FBSyxHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUM7SUFDMUcsTUFBTSxDQUFDLGVBQWUsR0FBRyxVQUFVLElBQUk7UUFDckMsYUFBYSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDbEMsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDOztJQUlGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7Ozs7OztRQU0vQixXQUFXLEdBQUc7S0FDbkI7SUFFRCxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQU07UUFDaEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsT0FBTyxJQUFJLENBQUM7S0FDYixDQUFDO0lBRUYsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLEdBQUcsVUFBVSxPQUFPOztZQUM5QyxPQUFPLEdBQUcsRUFBRTtRQUNsQixPQUFPLE9BQU8sRUFBRTtZQUNkLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDdEIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxDQUFDO1NBQ2pFO1FBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7S0FDMUIsQ0FBQzs7Ozs7Ozs7SUFFRixTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFVBQVU7O1lBQ25ELFFBQVEsR0FBRyxFQUFFO1FBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsVUFBVSxHQUFHOztnQkFDNUIsS0FBSyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUM7O1lBRzdCLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQzs7WUFFakcsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN6QixPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUM7YUFDckI7WUFFRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUUvQixRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUc7O3dCQUNSLFlBQVksR0FBRyxNQUFNLENBQUMsS0FBSyxFQUFFO3dCQUNqQyxHQUFHLEVBQUUsR0FBRztxQkFDVCxDQUFDO29CQUNGLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDMUMsQ0FBQzthQUVIO2lCQUFNO2dCQUVMLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLElBQUk7O3dCQUN0QixZQUFZLEdBQUcsTUFBTSxDQUFDLEtBQUssRUFBRTt3QkFDakMsR0FBRyxFQUFFLEdBQUc7d0JBQ1IsSUFBSSxFQUFFLElBQUk7cUJBQ1gsQ0FBQztvQkFDRixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7aUJBQzFDLENBQUM7YUFFSDtTQUNGLENBQUMsQ0FBQztRQUVILE9BQU8sUUFBUSxDQUFDO0tBQ2pCO0lBRUQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsVUFBVSxPQUFPLEVBQUUsS0FBSyxFQUFFLGVBQWUsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUzs7WUFDbEgsTUFBTSxHQUFHLFFBQVEsQ0FBQyxVQUFVLElBQUksRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDOztZQUM1RSxPQUFPLEdBQUcsUUFBUSxDQUFDLFdBQVcsSUFBSSxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUM7UUFFdkUsSUFBSSxJQUFJLEVBQUU7WUFDUixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDcEMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQzthQUM1QjtpQkFBTTtnQkFDTCxPQUFPLENBQUMsZUFBZSxDQUFDLEdBQUcsSUFBSSxDQUFDO2FBQ2pDO1NBQ0Y7O1lBRUcsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBRTVCLElBQUksSUFBSSxFQUFFOztnQkFDSixHQUFHLEdBQUcsRUFBRTtZQUNaLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNwQixHQUFHLElBQUksR0FBRyxDQUFDO2FBQ1o7WUFDRCxHQUFHLElBQUksSUFBSSxDQUFDO1lBQ1osR0FBRyxJQUFJLEdBQUcsQ0FBQztTQUNaO1FBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07WUFDcEIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDeEgsR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1NBQzNCO1FBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBRTlELE9BQU8sbUJBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO1lBQ2xELE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQ2pEO2dCQUNFLE1BQU0sRUFBRSxLQUFLO2dCQUNiLE1BQU0sRUFBRSxNQUFNO2dCQUNkLE9BQU8sRUFBRSxPQUFPO2FBQ2pCLENBQUM7WUFFSixHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM3QztnQkFDRSxNQUFNLEVBQUUsS0FBSztnQkFDYixNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUUsT0FBTzthQUNqQixDQUFDO1lBRUosS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDL0M7Z0JBQ0UsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFLE9BQU87YUFDakIsQ0FBQztZQUVKLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQzdDO2dCQUNFLE1BQU0sRUFBRSxLQUFLO2dCQUNiLE1BQU0sRUFBRSxNQUFNO2dCQUNkLE9BQU8sRUFBRSxPQUFPO2FBQ2pCLENBQUM7WUFFSixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM5QztnQkFDRSxNQUFNLEVBQUUsTUFBTTtnQkFDZCxNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUUsT0FBTzthQUNqQixDQUFDO1lBRUosTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDaEQ7Z0JBQ0UsTUFBTSxFQUFFLFFBQVE7Z0JBQ2hCLE1BQU0sRUFBRSxNQUFNO2dCQUNkLE9BQU8sRUFBRSxPQUFPO2FBQ2pCLENBQUM7WUFFSixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM5QztnQkFDRSxNQUFNLEVBQUUsTUFBTTtnQkFDZCxNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUUsT0FBTzthQUNqQixDQUFDO1lBRUosS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDL0M7Z0JBQ0UsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFLE9BQU87YUFDakIsQ0FBQztZQUVKLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQ2pEO2dCQUNFLE1BQU0sRUFBRSxTQUFTO2dCQUNqQixNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUUsT0FBTzthQUNqQixDQUFDO1lBRUosS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDL0M7Z0JBQ0UsTUFBTSxFQUFFLE9BQU87Z0JBQ2YsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsT0FBTyxFQUFFLE9BQU87YUFDakIsQ0FBQztTQUNMLENBQUMsQ0FBQztLQUNKLENBQUM7Ozs7Ozs7O1FBT0ksSUFBSSxHQUFHO0tBQ1o7SUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUM7SUFFbkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEdBQUcsVUFBVSxHQUFHOztZQUNuQyxLQUFLLEdBQUcsNEJBQTRCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNwRCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDN0MsT0FBTyxDQUFDLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUMzRSxDQUFDO0lBRUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsVUFBVSxPQUFPOztZQUMvQixNQUFNLEdBQUcsSUFBSTtRQUNuQixPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFFLFVBQVUsSUFBUyxFQUFFLElBQVM7O2dCQUNsRSxPQUFPOztnQkFDTCxZQUFZLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO1lBQ3ZELElBQUksWUFBWSxFQUFFO2dCQUNoQixJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFO29CQUM3QyxPQUFPLFlBQVksQ0FBQztpQkFDckI7cUJBQU07b0JBQ0wsT0FBTyxHQUFHLFlBQVksQ0FBQztpQkFDeEI7YUFDRjtpQkFBTTtnQkFDTCxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRXRELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsRUFBRTs7d0JBQ3pELEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7b0JBQ3JELElBQUksR0FBRyxFQUFFO3dCQUNQLE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztxQkFDaEM7aUJBQ0Y7cUJBQU07O3dCQUNELE1BQU0sU0FBSztvQkFDZixJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFO3dCQUNqQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDdEQ7eUJBQU07d0JBQ0wsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUM1QztvQkFFRCxJQUFJLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO3dCQUN0RCxPQUFPLElBQUksR0FBRyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxHQUFHLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO3FCQUNsRjtpQkFDRjthQUNGO1lBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUM7WUFDL0MsT0FBTyxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBRWxDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN6QixDQUFDO0lBR0YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsVUFBVSxPQUFPLEVBQUUsSUFBSTs7WUFDM0MsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQ2hDLElBQUksSUFBSSxFQUFFO1lBQ1IsT0FBTyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUM7U0FDdkI7UUFDRCxPQUFPLE9BQU8sQ0FBQztLQUNoQixDQUFDO0lBRUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLE9BQU8sRUFBRSxJQUFJOztZQUNsRCxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDOztZQUNsQyxNQUFNLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7Ozs7Ozs7Ozs7O1FBUWpFLFNBQVMsVUFBVSxDQUFDLEdBQUc7O2dCQUNmLFVBQVUsR0FBRyxFQUFFO1lBQ3JCLEtBQUssSUFBTSxHQUFHLElBQUksR0FBRyxFQUFFO2dCQUNyQixJQUFJLEdBQUcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQzNCLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3RCO2FBQ0Y7WUFDRCxPQUFPLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUMxQjs7Ozs7OztRQUVELFNBQVMsYUFBYSxDQUFDLEdBQUcsRUFBRSxRQUFTLEVBQUUsT0FBUTs7Z0JBQ3ZDLGVBQWUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDO1lBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMvQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDckU7WUFDRCxPQUFPLGVBQWUsQ0FBQztTQUN4Qjs7Ozs7O1FBRUQsU0FBUyxjQUFjLENBQUMsR0FBRyxFQUFFLGVBQWdCO1lBQzNDLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxDQUFDO2lCQUM3QixPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQztpQkFDckIsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7aUJBQ3JCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDO2lCQUNwQixPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQztpQkFDckIsT0FBTyxDQUFDLE1BQU0sR0FBRyxlQUFlLEdBQUcsS0FBSyxHQUFHLEdBQUcsRUFBRSxDQUFDO1NBQ25EO1FBRUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1NBQ3pDOztZQUVLLEtBQUssR0FBRyxFQUFFO1FBQ2hCLGFBQWEsQ0FBQyxNQUFNLEVBQUUsVUFBVSxLQUFLLEVBQUUsR0FBRztZQUN4QyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRTtnQkFDekMsT0FBTzthQUNSO1lBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkIsS0FBSyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDakI7WUFFRCxPQUFPLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQztnQkFDeEIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ2YsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3ZCO2dCQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRCxDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7UUFFSCxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDckcsQ0FBQztJQUVGLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0NBQzdDOzs7Ozs7O0lDL3FCQyxxQkFDMEMsU0FBUyxFQUN6QyxRQUFrQixFQUNsQixJQUFxQjtRQUZXLGNBQVMsR0FBVCxTQUFTLENBQUE7UUFDekMsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixTQUFJLEdBQUosSUFBSSxDQUFpQjtRQUU3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDOztZQUNuQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7UUFDcEMsTUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUV0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztLQUN6Qjs7OztJQUVELHNDQUFnQjs7O0lBQWhCO1FBQUEsaUJBVUM7O1FBVEMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNyRCxPQUFPO1NBQ1I7O1lBRUssS0FBSyxHQUFHQyxLQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBQyxRQUFtQjtZQUNoRSxPQUFPLEtBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3BDLENBQUM7UUFFRixDQUFBLEtBQUEsSUFBSSxDQUFDLFNBQVMsRUFBQyxFQUFFLHFCQUFLLElBQUksQ0FBQyxRQUFRLEdBQUssS0FBSyxHQUFHO0tBQ2pEOztnQkEzSEYsVUFBVTs7OztnREFzR04sUUFBUSxZQUFJLE1BQU0sU0FBQyxXQUFXO2dCQXJJTixRQUFRO2dCQTRCNUIsZUFBZTs7SUErSHhCLGtCQUFDO0NBQUEsSUFBQTs7Ozs7QUFFRCxTQUFTLGNBQWMsQ0FBQyxLQUFLOztRQUNyQixtQkFBbUIsR0FBRyxFQUFFO0lBRTlCLHFCQUFxQixDQUFDLElBQUksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO0lBRWpELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDOzs7O0lBRWpCLFNBQVMsSUFBSTs7Ozs7UUFFWCxTQUFTLDZCQUE2QixDQUFDLE1BQU07O2dCQUNyQyxPQUFPLEdBQVEsRUFBRTs7Z0JBRWpCLFVBQVUsR0FBRyxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDcEUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQzs7Ozs7Ozs7O1lBRTdCLFNBQVMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFVBQVU7Z0JBQ3BFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO2dCQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRixJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRixJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDOUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQztnQkFDakYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzRSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7O2dCQUcxRSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUksQ0FBQzs7Z0JBR3RELElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25FLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRWpFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQztnQkFFekQsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxFQUFFOzt3QkFDdEMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDOzt3QkFDdkMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDOzt3QkFFekMsMEJBQTBCLEdBQUcsS0FBSyxDQUN0QyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQ2hGLE1BQU0sQ0FBQyxXQUFXLENBQ25COzt3QkFDSyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSwwQkFBMEIsQ0FBQztvQkFFL0QsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFFO3dCQUM5QixNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ3JEO29CQUNELElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDL0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUN2RDtvQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQztpQkFDaEU7cUJBQU07b0JBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQ3REO2dCQUNELE9BQU8sSUFBSSxDQUFDO2FBQ2I7Ozs7Ozs7O1lBRUQsU0FBUyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUzs7b0JBQ25DLEtBQUs7Z0JBQ1QsSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUN2QyxLQUFLLEdBQUcsd0RBQXdELENBQUM7b0JBQ2pFLEtBQUssSUFBSSw0RUFBNEUsQ0FBQztvQkFDdEYsTUFBTSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDeEI7Z0JBQ0QsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ3RCLEtBQUssR0FBRyxpRUFBaUUsQ0FBQztvQkFDMUUsS0FBSyxJQUFJLCtFQUErRSxDQUFDO29CQUN6RixNQUFNLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUN4Qjs7b0JBQ0ssSUFBSSxHQUFHLEVBQUU7Z0JBQ2YsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUMzRSxPQUFPLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ3ZEOzs7Ozs7WUFFRCxTQUFTLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSztnQkFDeEIsT0FBTyx3QkFBd0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQzthQUMzRDs7Ozs7O1lBRUQsU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUs7O29CQUN0QixVQUFVLEdBQUcsRUFBRTtnQkFDckIsVUFBVSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNyRixPQUFPLHdCQUF3QixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ25FOzs7Ozs7O1lBRUQsU0FBUyxNQUFNLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHO2dCQUNoQyxJQUFJLENBQUMsS0FBSyxFQUFFO29CQUNWLE1BQU0sSUFBSSxLQUFLLENBQUMsMkRBQTJELENBQUMsQ0FBQztpQkFDOUU7O29CQUNLLElBQUksR0FBRyxFQUFFO2dCQUNmLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDdEMsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQzthQUN2RDs7Ozs7OztZQUVELFNBQVMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRztnQkFDaEMsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDVixNQUFNLElBQUksS0FBSyxDQUFDLDJEQUEyRCxDQUFDLENBQUM7aUJBQzlFOztvQkFDSyxJQUFJLEdBQUcsRUFBRTtnQkFDZixNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3RDLE9BQU8sd0JBQXdCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDN0Q7Ozs7Ozs7O1lBR0QsU0FBUyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLFdBQVc7Z0JBQ2hFLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxDQUFDLENBQUMsR0FBRyxHQUFBLENBQUMsQ0FBQyxDQUFDO2FBQzNDOzs7Ozs7OztZQUVELFNBQVMsY0FBYyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFdBQVc7Z0JBQzFELE1BQU0sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7O2dCQUcxQixJQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUU7b0JBQ3ZCLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTt3QkFDNUIsSUFBSSxFQUFFLElBQUk7cUJBQ1gsQ0FBQyxDQUFDLENBQUM7aUJBQ0w7cUJBQU07b0JBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDcEI7Z0JBRUQsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ3BCOzs7Ozs7WUFHRCxTQUFTLGdCQUFnQixDQUFDLElBQUk7Z0JBQzVCLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFOzt3QkFDWCxPQUFLLEdBQUcsRUFBRTtvQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLEtBQUs7d0JBQ3hCLE9BQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO3FCQUMvRSxDQUFDLENBQUM7b0JBQ0gsT0FBTyxPQUFLLENBQUM7aUJBQ2Q7cUJBQU07b0JBQ0wsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDakU7YUFDRjs7Ozs7WUFFRCxTQUFTLGtCQUFrQixDQUFDLElBQUk7Z0JBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQzs7b0JBQ3RFLGNBQWMsR0FBRyxFQUFDLEdBQUcsRUFBRSxjQUFjLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBQztnQkFDcEUsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxVQUFVLElBQUk7b0JBQzNDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxVQUFVLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPO3dCQUN4RSxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO3FCQUM5RSxDQUFDO2lCQUNILENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsY0FBYyxFQUFFLFVBQVUsV0FBVyxFQUFFLElBQUk7O3dCQUN4QyxhQUFhLEdBQUcsSUFBSSxLQUFLLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSTtvQkFDekQsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFLFVBQVUsS0FBSzt3QkFDcEMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztxQkFDM0UsQ0FBQyxDQUFDO2lCQUNKLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3pFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUN6Rjs7Ozs7O1lBRUQsU0FBUywwQkFBMEIsQ0FBQyxXQUFXLEVBQUUsU0FBYztnQkFBZCwwQkFBQSxFQUFBLGNBQWM7O29CQUN2RCxhQUFhLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUM7Z0JBQ3BELE9BQU8sa0JBQWtCLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsRUFDOUUsYUFBYSxFQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkU7Ozs7Ozs7Ozs7WUFFRCxTQUFTLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVcsRUFBRSxVQUFXLEVBQUUsU0FBVTs7b0JBQ2hGLElBQUksR0FBRyxNQUFNLENBQUMsMkJBQTJCLENBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7O29CQUVoRSxTQUFTLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQztnQkFFaEYsSUFBSSxNQUFNLENBQUMsZUFBZSxFQUFFO29CQUMxQixTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ3BGO2dCQUVELElBQUksVUFBVSxFQUFFO29CQUNkLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLEdBQUc7d0JBQ2xELE9BQU8sVUFBVSxDQUFDO3FCQUNuQixDQUFDO2lCQUNIO2dCQUVELFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsR0FBRyxLQUFLLENBQUM7Z0JBQ2xFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDdkUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUM3RSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDekUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUM3RSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3pFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDM0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUMvRSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQzNFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFakUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQzlCLE9BQU8sTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDckU7Ozs7Ozs7OztZQUVELFNBQVMsd0JBQXdCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsVUFBVyxFQUFFLFNBQVU7O29CQUN6RSxJQUFJLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDOztvQkFFL0QsU0FBUyxHQUFHLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxVQUFVLENBQUM7Z0JBQ2hGLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQ2pFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQy9FLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDN0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN6RSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQzNFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNyRixTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQy9FLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDM0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNuRSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUVuRixrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDOUIsT0FBTyxNQUFNLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNwRTs7Ozs7OztZQUVELFNBQVMsbUNBQW1DLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLOztvQkFDM0QsVUFBVSxHQUFHLHdCQUF3QixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztnQkFDMUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLElBQUk7b0JBQzdCLElBQUksSUFBSSxFQUFFO3dCQUNSLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNoRDtpQkFDRixDQUFDLENBQUM7Z0JBQ0gsT0FBTyxVQUFVLENBQUM7YUFDbkI7Ozs7Ozs7WUFFRCxTQUFTLE9BQU8sQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU87Z0JBQ3JDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQzFEOzs7Ozs7O1lBRUQsU0FBUyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU87O29CQUN4QyxNQUFNLEdBQUcsSUFBSTs7b0JBQ2IsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7O29CQUNyQixPQUFPLEdBQUcsSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDOztvQkFDckMsV0FBVyxHQUFHLEVBQUU7Z0JBQ3BCLFdBQVcsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFFMUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO3FCQUM3QixTQUFTLENBQUMsVUFBVSxVQUFVOzt3QkFDdkIsUUFBUSxHQUFHLDBCQUEwQixDQUFDLE1BQU0sQ0FBQztvQkFDbkQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQztvQkFDM0IsV0FBVyxHQUFHLFFBQVEsQ0FBQztvQkFDdkIsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDeEIsRUFBRSxVQUFVLFFBQVE7b0JBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3pCLEVBQUU7b0JBQ0QsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO2lCQUNwQixDQUFDLENBQUM7Z0JBRUgsT0FBTyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2FBQzNEOzs7Ozs7Ozs7O1lBRUQsU0FBUyxhQUFhLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPOztvQkFDckUsSUFBSSxHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7b0JBQ3ZGLElBQUksR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7Z0JBQ3pDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtvQkFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQzVDO2dCQUNELE9BQU8sSUFBSSxDQUFDO2FBQ2I7Ozs7Ozs7WUFFRCxTQUFTLGFBQWEsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU87O29CQUN2QyxNQUFNLEdBQUcsSUFBSTs7b0JBQ2IsT0FBTyxHQUFHLElBQUksZUFBZSxDQUFDLElBQUksQ0FBQzs7b0JBQ25DLFNBQVMsR0FBRyxTQUFTOztvQkFDckIsR0FBRyxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzs7b0JBQ3JDLFdBQVcsR0FBRyxJQUFJLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUM7O29CQUU1RCxPQUFPLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDLElBQUksRUFBRSxTQUFTLEVBQzNELFdBQVcsRUFBRSxHQUFHLEVBQUUsT0FBTyxJQUFJLEVBQUUsRUFBRSxTQUFTLElBQUksRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDOztvQkFFaEcsV0FBVyxHQUFHLEVBQUU7Z0JBQ3BCLFdBQVcsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDOztvQkFFeEUsTUFBTSxHQUFHLFNBQVM7Z0JBRXRCLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRTtvQkFDaEIsTUFBTSxHQUFHLE9BQU8sQ0FBQztpQkFDbEI7O29CQUVLLFVBQVUsR0FBRyxVQUFVLFFBQVE7O3dCQUM3QixPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUk7O3dCQUN2QixVQUFVLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNOzt3QkFDckMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7b0JBR2pGLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7d0JBQ3BDLElBQUksR0FBRyxFQUFFLENBQUM7cUJBQ1g7b0JBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO3FCQUNoRztvQkFFRCxJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsY0FBYyxFQUFFO3dCQUNsQyxPQUFPLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztxQkFDN0Q7O3dCQUVHLGFBQWEsR0FBR0EsS0FBRyxDQUFDLElBQUksRUFBRSxVQUFVLElBQUk7d0JBQzFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLEVBQUU7NEJBQzNELE9BQU8sa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO3lCQUMzRDs2QkFBTTs0QkFDTCxPQUFPLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEVBQ3ZFLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzt5QkFDN0Q7cUJBQ0YsQ0FBQztvQkFFRixhQUFhLEdBQUcsTUFBTSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztvQkFFNUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsRUFBRTt3QkFDM0QsY0FBYyxDQUNaLE9BQU8sRUFDUCxRQUFRLEVBQ1Isd0JBQXdCLENBQ3RCLE1BQU0sRUFDTixhQUFhLEVBQ2IsSUFBSSxFQUNKLElBQUksRUFDSixVQUFVLENBQ1gsRUFDRCxXQUFXLENBQ1osQ0FBQztxQkFDSDt5QkFBTTt3QkFDTCxjQUFjLENBQ1osT0FBTyxFQUNQLFFBQVEsRUFDUix3QkFBd0IsQ0FDdEIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsRUFDL0MsYUFBYSxFQUNiLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQ3RDLElBQUksRUFDSixVQUFVLENBQ1gsRUFDRCxXQUFXLENBQ1osQ0FBQztxQkFDSDtpQkFDRjtnQkFFRCxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUN4RixJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFO3FCQUMxRCxTQUFTLENBQUMsVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVE7b0JBQzVDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO3dCQUNyRixjQUFjLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7cUJBQ3hEO3lCQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxVQUFVLEVBQU87d0JBRTFELE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEtBQUssS0FBSyxDQUFDO3FCQUNwRCxDQUFDLEVBQUU7O3dCQUVGLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ3pCO2lCQUNGLENBQUMsQ0FBQztnQkFFSCxPQUFPLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7YUFDM0Q7Ozs7O1lBRUQsU0FBUyxjQUFjLENBQUMsVUFBVTtnQkFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsR0FBRyxVQUFVLENBQUM7Z0JBQ3ZELE9BQU8sSUFBSSxDQUFDO2FBQ2I7Ozs7OztZQUVELFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPO2dCQUMzQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQzdDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQzVEO3FCQUFNO29CQUNMLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ2hGO2FBQ0Y7Ozs7Ozs7OztZQUVELFNBQVMsWUFBWSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxPQUFPOztvQkFDbkQsTUFBTSxHQUFHLElBQUk7O29CQUNiLE9BQU8sR0FBRyxJQUFJLGVBQWUsQ0FBQyxJQUFJLENBQUM7O29CQUNuQyxTQUFTLEdBQUcsTUFBTSxJQUFJLEVBQUU7O29CQUN4QixLQUFLLEdBQUcsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDOztvQkFDcEQsUUFBUSxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzs7b0JBRTVDLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSTs7O29CQUVuQixJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO2dCQUUxSCxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLEVBQUU7b0JBQzFELE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDckM7O29CQUNLLE9BQU8sR0FBRyxNQUFNLENBQUMsc0JBQXNCLENBQzNDLE9BQU8sRUFDUCxTQUFTLEVBQ1QsS0FBSyxFQUNMLFFBQVEsRUFDUixPQUFPLElBQUksRUFBRSxFQUNiLFNBQVMsSUFBSSxFQUFFLEVBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQ2hEOztvQkFFRyxZQUFZLEdBQUcsRUFBRTtnQkFDckIsWUFBWSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7O29CQUVuRSxVQUFVLEdBQUcsVUFBVSxRQUFROzt3QkFDN0IsT0FBTyxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDOzt3QkFDL0IsVUFBVSxHQUFHLEdBQUcsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDOzt3QkFFM0MsSUFBSSxHQUFHLGFBQWEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQztvQkFFbEYsSUFBSSxJQUFJLEVBQUU7OzRCQUNKLElBQUksU0FBQTt3QkFDUixJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsY0FBYyxFQUFFOzRCQUNsQyxPQUFPLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQzt5QkFDOUQ7d0JBRUQsSUFBSSxTQUFTLEtBQUssTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFOzRCQUNuRixJQUFJLEdBQUcsa0JBQWtCLENBQ3ZCLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEVBQy9DLElBQUksRUFDSixLQUFLLEVBQ0wsSUFBSSxFQUNKLElBQUksRUFDSixVQUFVLENBQ1gsQ0FBQzs0QkFDRixjQUFjLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQ3ZEOzZCQUFNOzRCQUNMLElBQUksR0FBRyxrQkFBa0IsQ0FDdkIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsRUFDL0MsSUFBSSxFQUNKLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQ3RDLElBQUksRUFDSixJQUFJLEVBQ0osVUFBVSxDQUNYLENBQUM7NEJBRUYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUN0RixjQUFjLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7eUJBQ3ZEO3FCQUVGO3lCQUFNO3dCQUNMLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztxQkFDNUQ7aUJBQ0Y7O29CQUVLLGFBQWEsR0FBRyxVQUFVLFFBQVE7b0JBQ3RDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDdkQsY0FBYyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO3FCQUN6RDt5QkFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsVUFBVSxFQUFPO3dCQUMxRCxPQUFPLEVBQUUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEtBQUssQ0FBQztxQkFDcEQsQ0FBQyxFQUFFOzt3QkFFRixPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUN6QjtpQkFDRjs7O29CQUVHLGFBQWEsR0FBRyxTQUFTOztvQkFDekIsV0FBVyxHQUFHLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQzs7b0JBQ3ZDLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7Z0JBQy9ELElBQUksbUJBQW1CLEVBQUU7b0JBQ3ZCLGFBQWEsR0FBRyxNQUFNLENBQUM7b0JBQ3ZCLFdBQVcsR0FBRyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUMsd0JBQXdCLEVBQUUsU0FBUyxLQUFLLFFBQVEsR0FBRyxRQUFRLEdBQUcsU0FBUyxDQUFDLFdBQVcsRUFBRSxFQUFDLENBQUMsQ0FBQztpQkFDNUg7cUJBQU0sSUFBSSxNQUFNLENBQUMsS0FBSyxJQUFJLGFBQWEsS0FBSyxLQUFLLEVBQUU7b0JBQ2xELGFBQWEsR0FBRyxPQUFPLENBQUM7aUJBQ3pCO2dCQUVELElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDNUIsSUFBSSxtQkFBbUIsRUFBRTt3QkFDdkIsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQzlFLElBQUksRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztxQkFDdEY7eUJBQU07d0JBQ0wsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQzlFLElBQUksRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO3FCQUNwRjtpQkFDRjtxQkFBTTtvQkFDTCxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFDOUUsSUFBSSxFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztpQkFDbkc7Z0JBRUQsT0FBTyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDO2FBQzdEOzs7Ozs7WUFFRCxTQUFTLFdBQVcsQ0FBQyxNQUFNLEVBQUUsT0FBTztnQkFDbEMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUMvRTs7Ozs7O1lBRUQsU0FBUyxjQUFjLENBQUMsTUFBTSxFQUFFLE9BQU87Z0JBQ3JDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDbEY7Ozs7OztZQUVELFNBQVMsV0FBVyxDQUFDLE1BQU0sRUFBRSxPQUFPO2dCQUNsQyxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQy9FOzs7Ozs7OztZQUVELFNBQVMsWUFBWSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU87Z0JBQy9DLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDdEU7Ozs7OztZQUVELFNBQVMsWUFBWSxDQUFDLE1BQU0sRUFBRSxPQUFPO2dCQUNuQyxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQ2hGOzs7Ozs7WUFFRCxTQUFTLGFBQWEsQ0FBQyxNQUFNLEVBQUUsT0FBTztnQkFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNqRjs7Ozs7O1lBRUQsU0FBUyxlQUFlLENBQUMsTUFBTSxFQUFFLE9BQU87Z0JBQ3RDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDbkY7Ozs7Ozs7WUFFRCxTQUFTLGFBQWEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU87Z0JBQzFDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDNUU7Ozs7Ozs7OztZQUVELFNBQVMsY0FBYyxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJO2dCQUM1RCxPQUFPLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQ3pFOzs7Ozs7Ozs7O1lBRUQsU0FBUyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsY0FBYyxFQUFFLFdBQVc7O29CQUNqRyxjQUFjO2dCQUNsQixJQUFJLFNBQVMsS0FBSyxTQUFTLEVBQUU7b0JBQzNCLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDbEQ7cUJBQU07b0JBQ0wsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDOUQ7O29CQUVLLGVBQWUsR0FBRyxVQUFVLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTs7d0JBQy9DLFVBQVUsR0FBRyxRQUFRLENBQUM7d0JBQzFCLE1BQU0sRUFBRSxNQUFNO3dCQUNkLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixJQUFJLEVBQUUsSUFBSTtxQkFDWCxFQUFFO3dCQUNELE1BQU0sRUFBRSxhQUFhO3dCQUNyQixPQUFPLEVBQUUsY0FBYzt3QkFDdkIsSUFBSSxFQUFFLFdBQVc7cUJBQ2xCLENBQUM7b0JBQ0YsT0FBTyxjQUFjLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDL0U7Z0JBRUQsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFO29CQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsZUFBZSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU87d0JBQzFDLE9BQU8sZUFBZSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQy9DLENBQUM7aUJBQ0g7YUFDRjs7Ozs7WUFFRCxTQUFTLHlCQUF5QixDQUFDLFVBQVU7O29CQUNyQyxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ3RELHFCQUFxQixDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDNUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN0QixPQUFPLDZCQUE2QixDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ2pEOzs7Ozs7WUFFRCxTQUFTLFNBQVMsQ0FBQyxLQUFLLEVBQUUsTUFBTTs7b0JBQ3hCLHNCQUFzQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUM7O29CQUN6RCxJQUFJLEdBQVEsRUFBRTs7b0JBQ2QsVUFBVSxHQUFHLENBQUMsTUFBTSxJQUFJLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsTUFBTSxJQUFJLE9BQU8sR0FBRyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3pELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQzlDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ2xFLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBRTVDLEtBQUssSUFBTSxJQUFJLElBQUksVUFBVSxFQUFFO29CQUM3QixJQUFJLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxFQUFFO3dCQUM5RyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztxQkFDakQ7aUJBQ0Y7Z0JBRUQsT0FBTyxJQUFJLENBQUM7YUFDYjtZQUVELHFCQUFxQixDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUV2QyxPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQywwQkFBMEIsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUV6RCxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFM0MsT0FBTyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFOUQsT0FBTyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUV2QyxPQUFPLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRXZDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFFL0MsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU3QyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRTdDLE9BQU8sQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFM0QsT0FBTyxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUVsRSxPQUFPLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRXRGLE9BQU8sT0FBTyxDQUFDO1NBQ2hCO1FBRUQsT0FBTyw2QkFBNkIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0tBQzNEO0NBRUY7Ozs7OztBQzl1QkQ7QUFNQSxJQUFhLFVBQVUsR0FBRyxJQUFJLGNBQWMsQ0FBUyxXQUFXLENBQUM7QUFFakU7SUFNRSwyQkFBb0MsWUFBK0I7UUFDakUsSUFBSSxZQUFZLEVBQUU7WUFDaEIsTUFBTSxJQUFJLEtBQUssQ0FDYixzRUFBc0UsQ0FBQyxDQUFDO1NBQzNFO0tBQ0Y7Ozs7OztJQUlNLHlCQUFPOzs7OztJQUFkLFVBQWUsT0FBUSxFQUFFLE9BQVE7UUFDL0IsT0FBTztZQUNMLFFBQVEsRUFBRSxpQkFBaUI7WUFDM0IsU0FBUyxFQUFFO2dCQUNULEVBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEVBQUM7Z0JBQ25ELEVBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQUMsVUFBVSxDQUFDLEVBQUM7YUFDM0U7U0FDRixDQUFDO0tBQ0g7O2dCQXZCRixRQUFRLFNBQUM7b0JBQ1IsT0FBTyxFQUFFLENBQUMsZ0JBQWdCLENBQUM7b0JBQzNCLFNBQVMsRUFBRSxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUM7aUJBQzFDOzs7O2dCQUdtRCxpQkFBaUIsdUJBQXRELFFBQVEsWUFBSSxRQUFROztJQW1CbkMsd0JBQUM7Q0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsifQ==