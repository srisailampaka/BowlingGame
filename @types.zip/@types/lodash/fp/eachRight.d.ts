import { eachRight } from "../fp";
export = eachRight;
