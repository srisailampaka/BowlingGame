module.exports = require('../../es/instance/trim-end');
