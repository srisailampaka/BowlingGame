module.exports = require('../../es/string/small');
