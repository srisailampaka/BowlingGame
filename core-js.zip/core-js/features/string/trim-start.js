module.exports = require('../../es/string/trim-start');
