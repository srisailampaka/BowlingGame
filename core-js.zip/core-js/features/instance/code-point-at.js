module.exports = require('../../es/instance/code-point-at');
