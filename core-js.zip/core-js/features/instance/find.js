module.exports = require('../../es/instance/find');
