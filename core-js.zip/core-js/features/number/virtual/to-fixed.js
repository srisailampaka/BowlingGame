module.exports = require('../../../es/number/virtual/to-fixed');
