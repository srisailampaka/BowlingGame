module.exports = require('../../es/math/log2');
