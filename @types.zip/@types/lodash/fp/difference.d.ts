import { difference } from "../fp";
export = difference;
