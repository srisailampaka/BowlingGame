import { some } from "../fp";
export = some;
