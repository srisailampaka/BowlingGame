import { head } from "./index";
export = head;
