import { rest } from "../fp";
export = rest;
