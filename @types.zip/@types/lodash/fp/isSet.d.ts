import { isSet } from "../fp";
export = isSet;
