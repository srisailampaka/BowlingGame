module.exports = require('../../es/string/search');
