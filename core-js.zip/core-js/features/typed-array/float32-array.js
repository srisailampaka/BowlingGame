module.exports = require('../../es/typed-array/float32-array');
