module.exports = require('../../es/math/log1p');
