module.exports = require('../../es/object/prevent-extensions');
