require('../modules/esnext.global-this');

module.exports = require('../internals/global');
