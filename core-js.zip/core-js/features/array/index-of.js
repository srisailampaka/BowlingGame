module.exports = require('../../es/array/index-of');
