import { endsWith } from "../fp";
export = endsWith;
