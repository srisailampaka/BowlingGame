module.exports = require('../../es/typed-array/uint32-array');
