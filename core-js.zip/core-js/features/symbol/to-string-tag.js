module.exports = require('../../es/symbol/to-string-tag');
