module.exports = require('../../es/math/acosh');
