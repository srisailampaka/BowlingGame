module.exports = require('../../es/string/trim');
