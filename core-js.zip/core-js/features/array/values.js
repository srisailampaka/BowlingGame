module.exports = require('../../es/array/values');
