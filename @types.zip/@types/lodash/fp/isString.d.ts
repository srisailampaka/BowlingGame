import { isString } from "../fp";
export = isString;
