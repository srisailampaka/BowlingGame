require('../../modules/esnext.symbol.replace-all');
var WrappedWellKnownSymbolModule = require('../../internals/wrapped-well-known-symbol');

module.exports = WrappedWellKnownSymbolModule.f('replaceAll');
