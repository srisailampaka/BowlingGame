module.exports = require('../../es/instance/bind');
