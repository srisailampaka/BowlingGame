import { thru } from "../fp";
export = thru;
