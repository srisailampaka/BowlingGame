module.exports = require('../../es/object/lookup-setter');
