module.exports = require('../../es/symbol/split');
