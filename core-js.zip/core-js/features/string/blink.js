module.exports = require('../../es/string/blink');
