import { assignInAll } from "../fp";
export = assignInAll;
