module.exports = require('../../../es/string/virtual/trim-right');
