module.exports = require('../../es/array-buffer/is-view');
