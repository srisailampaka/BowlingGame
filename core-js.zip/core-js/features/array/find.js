module.exports = require('../../es/array/find');
