module.exports = require('../../es/math/trunc');
