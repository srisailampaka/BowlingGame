var shared = require('../internals/shared');

module.exports = shared('native-function-to-string', Function.toString);
