module.exports = require('../../es/typed-array/int32-array');
