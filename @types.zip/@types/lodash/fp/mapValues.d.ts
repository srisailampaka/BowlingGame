import { mapValues } from "../fp";
export = mapValues;
