module.exports = require('../../es/regexp/constructor');
