module.exports = require('../../es/number/max-safe-integer');
