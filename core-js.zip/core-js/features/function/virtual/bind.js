module.exports = require('../../../es/function/virtual/bind');
