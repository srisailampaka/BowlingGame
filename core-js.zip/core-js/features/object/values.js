module.exports = require('../../es/object/values');
