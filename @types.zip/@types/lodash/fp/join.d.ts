import { join } from "../fp";
export = join;
