import { findLastFrom } from "../fp";
export = findLastFrom;
