import { values } from "../fp";
export = values;
