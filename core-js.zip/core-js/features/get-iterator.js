require('../modules/web.dom-collections.iterator');
require('../modules/es.string.iterator');

module.exports = require('../internals/get-iterator');
