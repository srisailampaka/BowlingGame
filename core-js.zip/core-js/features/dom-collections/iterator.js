module.exports = require('../../stable/dom-collections/iterator');
