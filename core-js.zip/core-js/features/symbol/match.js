module.exports = require('../../es/symbol/match');
