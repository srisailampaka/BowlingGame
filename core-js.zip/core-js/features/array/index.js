module.exports = require('../../es/array');

require('../../modules/esnext.array.last-item');
require('../../modules/esnext.array.last-index');
