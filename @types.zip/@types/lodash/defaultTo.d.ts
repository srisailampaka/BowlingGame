import { defaultTo } from "./index";
export = defaultTo;
