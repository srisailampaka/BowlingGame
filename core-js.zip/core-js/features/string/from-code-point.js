module.exports = require('../../es/string/from-code-point');
