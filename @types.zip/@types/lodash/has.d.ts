import { has } from "./index";
export = has;
