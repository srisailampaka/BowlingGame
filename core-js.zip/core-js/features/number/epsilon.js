module.exports = require('../../es/number/epsilon');
