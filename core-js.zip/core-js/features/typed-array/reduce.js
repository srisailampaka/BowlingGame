require('../../modules/es.typed-array.reduce');
