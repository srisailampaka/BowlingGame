import { isSymbol } from "../fp";
export = isSymbol;
