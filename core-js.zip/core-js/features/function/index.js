module.exports = require('../../es/function');
