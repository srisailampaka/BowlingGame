module.exports = require('../../es/instance/reduce-right');
