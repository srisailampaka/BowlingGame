import { any } from "../fp";
export = any;
