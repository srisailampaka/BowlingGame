module.exports = require('../../../es/array/virtual/for-each');
