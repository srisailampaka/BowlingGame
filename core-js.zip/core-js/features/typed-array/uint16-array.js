module.exports = require('../../es/typed-array/uint16-array');
