module.exports = require('../../es/symbol/species');
