module.exports = require('../stable/set-timeout');
