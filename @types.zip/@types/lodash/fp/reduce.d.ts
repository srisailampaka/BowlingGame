import { reduce } from "../fp";
export = reduce;
