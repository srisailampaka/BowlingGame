module.exports = require('../../es/object/is-sealed');
