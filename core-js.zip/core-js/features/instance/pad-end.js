module.exports = require('../../es/instance/pad-end');
