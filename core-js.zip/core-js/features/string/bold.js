module.exports = require('../../es/string/bold');
