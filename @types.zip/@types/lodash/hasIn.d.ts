import { hasIn } from "./index";
export = hasIn;
