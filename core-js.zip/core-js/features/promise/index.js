module.exports = require('../../es/promise');

require('../../modules/esnext.aggregate-error');
require('../../modules/esnext.promise.all-settled');
require('../../modules/esnext.promise.try');
require('../../modules/esnext.promise.any');
