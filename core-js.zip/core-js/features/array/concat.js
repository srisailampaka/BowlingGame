module.exports = require('../../es/array/concat');
