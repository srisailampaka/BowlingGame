module.exports = require('../../es/instance/index-of');
