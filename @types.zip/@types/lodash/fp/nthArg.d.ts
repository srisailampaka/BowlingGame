import { nthArg } from "../fp";
export = nthArg;
