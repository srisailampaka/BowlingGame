module.exports = require('../../es/math/atanh');
