import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class CompareJson {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		BufferedReader br1 = new BufferedReader(new FileReader("src/file1.txt"));
		BufferedReader br2 = new BufferedReader(new FileReader("src/file2.txt"));
		String leftJson=readTheFile(br1);
		String rightJson=readTheFile(br2);
		Gson gson = new Gson();
		Type type = new TypeToken<Map<String, Object>>(){}.getType();

		Map<String, Object> leftMap = gson.fromJson(leftJson, type);
		Map<String, Object> rightMap = gson.fromJson(rightJson, type);
		
		Map<String, Object> leftFlatMap = FlatMapUtil.flatten(leftMap);
		Map<String, Object> rightFlatMap = FlatMapUtil.flatten(rightMap);
		
		MapDifference<String, Object> difference = Maps.difference(leftFlatMap, rightFlatMap);
		System.out.println("\n\nEntries differing\n--------------------------");
		difference.entriesDiffering().forEach((key, value) -> System.out.println(key + ": " + value));

	}
	
	
	private static String readTheFile(BufferedReader br) throws IOException {
		String everything ="";
		try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	        sb.append(line);
	        sb.append(System.lineSeparator());
	        line = br.readLine();
	        }
	         everything = sb.toString();
	        } finally {
	        br.close();
	    }
		return everything;
	}

}
