module.exports = require('../../stable/instance/values');
