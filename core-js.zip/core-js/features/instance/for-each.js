module.exports = require('../../stable/instance/for-each');
