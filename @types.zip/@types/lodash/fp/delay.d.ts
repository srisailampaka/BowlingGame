import { delay } from "../fp";
export = delay;
