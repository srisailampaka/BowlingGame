module.exports = require('../../es/array/iterator');
