module.exports = require('../stable/clear-immediate');
