import { repeat } from "../fp";
export = repeat;
