/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { RESTANGULAR as ɵb, RestangularFactory as ɵc } from './lib/ngx-restangular.config';
export { CONFIG_OBJ as ɵa } from './lib/ngx-restangular.module';
