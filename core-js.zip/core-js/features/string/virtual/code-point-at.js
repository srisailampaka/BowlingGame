module.exports = require('../../../es/string/virtual/code-point-at');
