module.exports = require('../../es/json/to-string-tag');
