(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('lodash'), require('@angular/common/http'), require('core-js/fn/object'), require('rxjs'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('ngx-restangular', ['exports', '@angular/core', 'lodash', '@angular/common/http', 'core-js/fn/object', 'rxjs', 'rxjs/operators'], factory) :
    (factory((global['ngx-restangular'] = {}),global.ng.core,null,global.ng.common.http,null,global.rxjs,global.rxjs.operators));
}(this, (function (exports,core,lodash,http,object,rxjs,operators) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    /** @type {?} */
    var RESTANGULAR = new core.InjectionToken('restangularWithConfig');
    /**
     * @param {?} __0
     * @return {?}
     */
    function RestangularFactory(_a) {
        var _b = __read(_a, 2), callbackOrServices = _b[0], callback = _b[1];
        /** @type {?} */
        var arrServices = [];
        /** @type {?} */
        var fn = callbackOrServices;
        if (lodash.isArray(callbackOrServices)) {
            arrServices = callbackOrServices;
            fn = callback;
        }
        return { fn: fn, arrServices: arrServices };
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    var RestangularHelper = /** @class */ (function () {
        function RestangularHelper() {
        }
        /**
         * @param {?} options
         * @return {?}
         */
        RestangularHelper.createRequest = /**
         * @param {?} options
         * @return {?}
         */
            function (options) {
                /** @type {?} */
                var requestQueryParams = RestangularHelper.createRequestQueryParams(options.params);
                /** @type {?} */
                var requestHeaders = RestangularHelper.createRequestHeaders(options.headers);
                /** @type {?} */
                var methodName = options.method.toUpperCase();
                /** @type {?} */
                var withCredentials = options.withCredentials || false;
                /** @type {?} */
                var request = new http.HttpRequest(methodName, options.url, options.data, {
                    headers: requestHeaders,
                    params: requestQueryParams,
                    responseType: options.responseType,
                    withCredentials: withCredentials
                });
                if (['GET', 'DELETE', 'HEAD', 'JSONP', 'OPTIONS'].indexOf(methodName) >= 0) {
                    request = new http.HttpRequest(methodName, options.url, {
                        headers: requestHeaders,
                        params: requestQueryParams,
                        responseType: options.responseType,
                        withCredentials: withCredentials
                    });
                }
                return request;
            };
        /**
         * @param {?} queryParams
         * @return {?}
         */
        RestangularHelper.createRequestQueryParams = /**
         * @param {?} queryParams
         * @return {?}
         */
            function (queryParams) {
                /** @type {?} */
                var requestQueryParams = object.assign({}, queryParams);
                /** @type {?} */
                var search = new http.HttpParams();
                var _loop_1 = function (key) {
                    /** @type {?} */
                    var value = requestQueryParams[key];
                    if (Array.isArray(value)) {
                        value.forEach(function (val) {
                            search = search.append(key, val);
                        });
                    }
                    else {
                        if (typeof value === 'object') {
                            value = JSON.stringify(value);
                        }
                        search = search.append(key, value);
                    }
                };
                for (var key in requestQueryParams) {
                    _loop_1(key);
                }
                return search;
            };
        /**
         * @param {?} headers
         * @return {?}
         */
        RestangularHelper.createRequestHeaders = /**
         * @param {?} headers
         * @return {?}
         */
            function (headers) {
                for (var key in headers) {
                    /** @type {?} */
                    var value = headers[key];
                    if (typeof value === 'undefined') {
                        delete headers[key];
                    }
                }
                return new http.HttpHeaders(object.assign({}, headers));
            };
        return RestangularHelper;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    var RestangularHttp = /** @class */ (function () {
        function RestangularHttp(http$$1) {
            this.http = http$$1;
        }
        /**
         * @param {?} options
         * @return {?}
         */
        RestangularHttp.prototype.createRequest = /**
         * @param {?} options
         * @return {?}
         */
            function (options) {
                /** @type {?} */
                var request = RestangularHelper.createRequest(options);
                return this.request(request);
            };
        /**
         * @param {?} request
         * @return {?}
         */
        RestangularHttp.prototype.request = /**
         * @param {?} request
         * @return {?}
         */
            function (request) {
                var _this = this;
                return this.http.handle(request)
                    .pipe(operators.filter(function (event) { return event instanceof http.HttpResponse; }), operators.map(function (response) {
                    if (!response.ok) {
                        return rxjs.throwError(new http.HttpErrorResponse(response));
                    }
                    return response;
                }), operators.map(function (response) {
                    response.config = { params: request };
                    return response;
                }), operators.catchError(function (err) {
                    err.request = request;
                    err.data = err.error;
                    err.repeatRequest = function (newRequest) {
                        return _this.request(newRequest || request);
                    };
                    return rxjs.throwError(err);
                }));
            };
        RestangularHttp.decorators = [
            { type: core.Injectable },
        ];
        /** @nocollapse */
        RestangularHttp.ctorParameters = function () {
            return [
                { type: http.HttpBackend }
            ];
        };
        return RestangularHttp;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    /**
     * @param {?} object
     * @param {?} configuration
     * @return {?}
     */
    function RestangularConfigurer(object$$1, configuration) {
        object$$1.configuration = configuration;
        /**
         * Those are HTTP safe methods for which there is no need to pass any data with the request.
         * @type {?}
         */
        var safeMethods = ['get', 'head', 'options', 'trace', 'getlist'];
        configuration.isSafe = function (operation) {
            return lodash.includes(safeMethods, operation.toLowerCase());
        };
        /** @type {?} */
        var absolutePattern = /^https?:\/\//i;
        configuration.isAbsoluteUrl = function (string) {
            return lodash.isUndefined(configuration.absoluteUrl) || lodash.isNull(configuration.absoluteUrl) ?
                string && absolutePattern.test(string) :
                configuration.absoluteUrl;
        };
        configuration.absoluteUrl = lodash.isUndefined(configuration.absoluteUrl) ? true : configuration.absoluteUrl;
        object$$1.setSelfLinkAbsoluteUrl = function (value) {
            configuration.absoluteUrl = value;
        };
        /**
         * This is the BaseURL to be used with Restangular
         */
        configuration.baseUrl = lodash.isUndefined(configuration.baseUrl) ? '' : configuration.baseUrl;
        object$$1.setBaseUrl = function (newBaseUrl) {
            configuration.baseUrl = /\/$/.test(newBaseUrl) ?
                newBaseUrl.substring(0, newBaseUrl.length - 1) :
                newBaseUrl;
            return this;
        };
        /**
         * Sets the extra fields to keep from the parents
         */
        configuration.extraFields = configuration.extraFields || [];
        object$$1.setExtraFields = function (newExtraFields) {
            configuration.extraFields = newExtraFields;
            return this;
        };
        /**
         * Some default $http parameter to be used in EVERY call
         **/
        configuration.defaultHttpFields = configuration.defaultHttpFields || {};
        object$$1.setDefaultHttpFields = function (values) {
            configuration.defaultHttpFields = values;
            return this;
        };
        /**
         * Always return plain data, no restangularized object
         **/
        configuration.plainByDefault = configuration.plainByDefault || false;
        object$$1.setPlainByDefault = function (value) {
            configuration.plainByDefault = value === true ? true : false;
            return this;
        };
        configuration.withHttpValues = function (httpLocalConfig, obj) {
            return lodash.defaults(obj, httpLocalConfig, configuration.defaultHttpFields);
        };
        configuration.encodeIds = lodash.isUndefined(configuration.encodeIds) ? true : configuration.encodeIds;
        object$$1.setEncodeIds = function (encode) {
            configuration.encodeIds = encode;
        };
        configuration.defaultRequestParams = configuration.defaultRequestParams || {
            get: {},
            post: {},
            put: {},
            remove: {},
            common: {}
        };
        object$$1.setDefaultRequestParams = function (param1, param2) {
            /** @type {?} */
            var methods = [];
            /** @type {?} */
            var params = param2 || param1;
            if (!lodash.isUndefined(param2)) {
                if (lodash.isArray(param1)) {
                    methods = param1;
                }
                else {
                    methods.push(param1);
                }
            }
            else {
                methods.push('common');
            }
            lodash.each(methods, function (method) {
                configuration.defaultRequestParams[method] = params;
            });
            return this;
        };
        object$$1.requestParams = configuration.defaultRequestParams;
        configuration.defaultHeaders = configuration.defaultHeaders || {};
        object$$1.setDefaultHeaders = function (headers) {
            configuration.defaultHeaders = headers;
            object$$1.defaultHeaders = configuration.defaultHeaders;
            return this;
        };
        object$$1.defaultHeaders = configuration.defaultHeaders;
        /**
         * Method overriders response Method
         **/
        configuration.defaultResponseMethod = configuration.defaultResponseMethod || 'promise';
        object$$1.setDefaultResponseMethod = function (method) {
            configuration.defaultResponseMethod = method;
            object$$1.defaultResponseMethod = configuration.defaultResponseMethod;
            return this;
        };
        object$$1.defaultResponseMethod = configuration.defaultResponseMethod;
        /**
         * Method overriders will set which methods are sent via POST with an X-HTTP-Method-Override
         **/
        configuration.methodOverriders = configuration.methodOverriders || [];
        object$$1.setMethodOverriders = function (values) {
            /** @type {?} */
            var overriders = lodash.extend([], values);
            if (configuration.isOverridenMethod('delete', overriders)) {
                overriders.push('remove');
            }
            configuration.methodOverriders = overriders;
            return this;
        };
        configuration.jsonp = lodash.isUndefined(configuration.jsonp) ? false : configuration.jsonp;
        object$$1.setJsonp = function (active) {
            configuration.jsonp = active;
        };
        configuration.isOverridenMethod = function (method, values) {
            /** @type {?} */
            var search = values || configuration.methodOverriders;
            return !lodash.isUndefined(lodash.find(search, function (one) {
                return one.toLowerCase() === method.toLowerCase();
            }));
        };
        /**
         * Sets the URL creator type. For now, only Path is created. In the future we'll have queryParams
         **/
        configuration.urlCreator = configuration.urlCreator || 'path';
        object$$1.setUrlCreator = function (name) {
            if (!lodash.has(configuration.urlCreatorFactory, name)) {
                throw new Error('URL Path selected isn\'t valid');
            }
            configuration.urlCreator = name;
            return this;
        };
        /**
         * You can set the restangular fields here. The 3 required fields for Restangular are:
         *
         * id: Id of the element
         * route: name of the route of this element
         * parentResource: the reference to the parent resource
         *
         *  All of this fields except for id, are handled (and created) by Restangular. By default,
         *  the field values will be id, route and parentResource respectively
         */
        configuration.restangularFields = configuration.restangularFields || {
            id: 'id',
            route: 'route',
            parentResource: 'parentResource',
            restangularCollection: 'restangularCollection',
            cannonicalId: '__cannonicalId',
            etag: 'restangularEtag',
            selfLink: 'href',
            get: 'get',
            getList: 'getList',
            put: 'put',
            post: 'post',
            remove: 'remove',
            head: 'head',
            trace: 'trace',
            options: 'options',
            patch: 'patch',
            getRestangularUrl: 'getRestangularUrl',
            getRequestedUrl: 'getRequestedUrl',
            putElement: 'putElement',
            addRestangularMethod: 'addRestangularMethod',
            getParentList: 'getParentList',
            clone: 'clone',
            ids: 'ids',
            httpConfig: '_$httpConfig',
            reqParams: 'reqParams',
            one: 'one',
            all: 'all',
            several: 'several',
            oneUrl: 'oneUrl',
            allUrl: 'allUrl',
            customPUT: 'customPUT',
            customPATCH: 'customPATCH',
            customPOST: 'customPOST',
            customDELETE: 'customDELETE',
            customGET: 'customGET',
            customGETLIST: 'customGETLIST',
            customOperation: 'customOperation',
            doPUT: 'doPUT',
            doPATCH: 'doPATCH',
            doPOST: 'doPOST',
            doDELETE: 'doDELETE',
            doGET: 'doGET',
            doGETLIST: 'doGETLIST',
            fromServer: 'fromServer',
            withConfig: 'withConfig',
            withHttpConfig: 'withHttpConfig',
            singleOne: 'singleOne',
            plain: 'plain',
            save: 'save',
            restangularized: 'restangularized'
        };
        object$$1.setRestangularFields = function (resFields) {
            configuration.restangularFields =
                lodash.extend({}, configuration.restangularFields, resFields);
            return this;
        };
        configuration.isRestangularized = function (obj) {
            return !!obj[configuration.restangularFields.restangularized];
        };
        configuration.setFieldToElem = function (field, elem, value) {
            /** @type {?} */
            var properties = field.split('.');
            /** @type {?} */
            var idValue = elem;
            lodash.each(lodash.initial(properties), function (prop) {
                idValue[prop] = {};
                idValue = idValue[prop];
            });
            /** @type {?} */
            var index = lodash.last(properties);
            idValue[index] = value;
            return this;
        };
        configuration.getFieldFromElem = function (field, elem) {
            /** @type {?} */
            var properties = field.split('.');
            /** @type {?} */
            var idValue = elem;
            lodash.each(properties, function (prop) {
                if (idValue) {
                    idValue = idValue[prop];
                }
            });
            return lodash.clone(idValue);
        };
        configuration.setIdToElem = function (elem, id /*, route */) {
            configuration.setFieldToElem(configuration.restangularFields.id, elem, id);
            return this;
        };
        configuration.getIdFromElem = function (elem) {
            return configuration.getFieldFromElem(configuration.restangularFields.id, elem);
        };
        configuration.isValidId = function (elemId) {
            return '' !== elemId && !lodash.isUndefined(elemId) && !lodash.isNull(elemId);
        };
        configuration.setUrlToElem = function (elem, url /*, route */) {
            configuration.setFieldToElem(configuration.restangularFields.selfLink, elem, url);
            return this;
        };
        configuration.getUrlFromElem = function (elem) {
            return configuration.getFieldFromElem(configuration.restangularFields.selfLink, elem);
        };
        configuration.useCannonicalId = lodash.isUndefined(configuration.useCannonicalId) ? false : configuration.useCannonicalId;
        object$$1.setUseCannonicalId = function (value) {
            configuration.useCannonicalId = value;
            return this;
        };
        configuration.getCannonicalIdFromElem = function (elem) {
            /** @type {?} */
            var cannonicalId = elem[configuration.restangularFields.cannonicalId];
            /** @type {?} */
            var actualId = configuration.isValidId(cannonicalId) ? cannonicalId : configuration.getIdFromElem(elem);
            return actualId;
        };
        /**
         * Sets the Response parser. This is used in case your response isn't directly the data.
         * For example if you have a response like {meta: {'meta'}, data: {name: 'Gonto'}}
         * you can extract this data which is the one that needs wrapping
         *
         * The ResponseExtractor is a function that receives the response and the method executed.
         */
        configuration.responseInterceptors = configuration.responseInterceptors ? __spread(configuration.responseInterceptors) : [];
        configuration.defaultResponseInterceptor = function (data /*, operation, what, url, response, subject */) {
            return data || {};
        };
        configuration.responseExtractor = function (data, operation, what, url, response, subject) {
            /** @type {?} */
            var interceptors = lodash.clone(configuration.responseInterceptors);
            interceptors.push(configuration.defaultResponseInterceptor);
            /** @type {?} */
            var theData = data;
            lodash.each(interceptors, function (interceptor) {
                theData = interceptor(theData, operation, what, url, response, subject);
            });
            return theData;
        };
        object$$1.addResponseInterceptor = function (extractor) {
            configuration.responseInterceptors.push(extractor);
            return this;
        };
        configuration.errorInterceptors = configuration.errorInterceptors ? __spread(configuration.errorInterceptors) : [];
        object$$1.addErrorInterceptor = function (interceptor) {
            configuration.errorInterceptors = __spread([interceptor], configuration.errorInterceptors);
            return this;
        };
        object$$1.setResponseInterceptor = object$$1.addResponseInterceptor;
        object$$1.setResponseExtractor = object$$1.addResponseInterceptor;
        object$$1.setErrorInterceptor = object$$1.addErrorInterceptor;
        /**
         * Response interceptor is called just before resolving promises.
         */
        /**
         * Request interceptor is called before sending an object to the server.
         */
        configuration.requestInterceptors = configuration.requestInterceptors ? __spread(configuration.requestInterceptors) : [];
        configuration.defaultInterceptor = function (element, operation, path, url, headers, params, httpConfig) {
            return {
                element: element,
                headers: headers,
                params: params,
                httpConfig: httpConfig
            };
        };
        configuration.fullRequestInterceptor = function (element, operation, path, url, headers, params, httpConfig) {
            /** @type {?} */
            var interceptors = lodash.clone(configuration.requestInterceptors);
            /** @type {?} */
            var defaultRequest = configuration.defaultInterceptor(element, operation, path, url, headers, params, httpConfig);
            return lodash.reduce(interceptors, function (request, interceptor) {
                /** @type {?} */
                var returnInterceptor = interceptor(request.element, operation, path, url, request.headers, request.params, request.httpConfig);
                return lodash.extend(request, returnInterceptor);
            }, defaultRequest);
        };
        object$$1.addRequestInterceptor = function (interceptor) {
            configuration.requestInterceptors.push(function (elem, operation, path, url, headers, params, httpConfig) {
                return {
                    headers: headers,
                    params: params,
                    element: interceptor(elem, operation, path, url),
                    httpConfig: httpConfig
                };
            });
            return this;
        };
        object$$1.setRequestInterceptor = object$$1.addRequestInterceptor;
        object$$1.addFullRequestInterceptor = function (interceptor) {
            configuration.requestInterceptors.push(interceptor);
            return this;
        };
        object$$1.setFullRequestInterceptor = object$$1.addFullRequestInterceptor;
        configuration.onBeforeElemRestangularized = configuration.onBeforeElemRestangularized || function (elem) {
            return elem;
        };
        object$$1.setOnBeforeElemRestangularized = function (post) {
            configuration.onBeforeElemRestangularized = post;
            return this;
        };
        object$$1.setRestangularizePromiseInterceptor = function (interceptor) {
            configuration.restangularizePromiseInterceptor = interceptor;
            return this;
        };
        /**
         * This method is called after an element has been "Restangularized".
         *
         * It receives the element, a boolean indicating if it's an element or a collection
         * and the name of the model
         *
         */
        configuration.onElemRestangularized = configuration.onElemRestangularized || function (elem) {
            return elem;
        };
        object$$1.setOnElemRestangularized = function (post) {
            configuration.onElemRestangularized = post;
            return this;
        };
        configuration.shouldSaveParent = configuration.shouldSaveParent || function () {
            return true;
        };
        object$$1.setParentless = function (values) {
            if (lodash.isArray(values)) {
                configuration.shouldSaveParent = function (route) {
                    return !lodash.includes(values, route);
                };
            }
            else if (lodash.isBoolean(values)) {
                configuration.shouldSaveParent = function () {
                    return !values;
                };
            }
            return this;
        };
        /**
         * This lets you set a suffix to every request.
         *
         * For example, if your api requires that for JSon requests you do /users/123.json, you can set that
         * in here.
         *
         *
         * By default, the suffix is null
         */
        configuration.suffix = lodash.isUndefined(configuration.suffix) ? null : configuration.suffix;
        object$$1.setRequestSuffix = function (newSuffix) {
            configuration.suffix = newSuffix;
            return this;
        };
        /**
         * Add element transformers for certain routes.
         */
        configuration.transformers = configuration.transformers || {};
        object$$1.addElementTransformer = function (type, secondArg, thirdArg) {
            /** @type {?} */
            var isCollection = null;
            /** @type {?} */
            var transformer = null;
            if (arguments.length === 2) {
                transformer = secondArg;
            }
            else {
                transformer = thirdArg;
                isCollection = secondArg;
            }
            /** @type {?} */
            var typeTransformers = configuration.transformers[type];
            if (!typeTransformers) {
                typeTransformers = configuration.transformers[type] = [];
            }
            typeTransformers.push(function (coll, elem) {
                if (lodash.isNull(isCollection) || (coll === isCollection)) {
                    return transformer(elem);
                }
                return elem;
            });
            return object$$1;
        };
        object$$1.extendCollection = function (route, fn) {
            return object$$1.addElementTransformer(route, true, fn);
        };
        object$$1.extendModel = function (route, fn) {
            return object$$1.addElementTransformer(route, false, fn);
        };
        configuration.transformElem = function (elem, isCollection, route, Restangular, force) {
            if (!force && !configuration.transformLocalElements && !elem[configuration.restangularFields.fromServer]) {
                return elem;
            }
            /** @type {?} */
            var typeTransformers = configuration.transformers[route];
            /** @type {?} */
            var changedElem = elem;
            if (typeTransformers) {
                lodash.each(typeTransformers, function (transformer) {
                    changedElem = transformer(isCollection, changedElem);
                });
            }
            return configuration.onElemRestangularized(changedElem, isCollection, route, Restangular);
        };
        configuration.transformLocalElements = lodash.isUndefined(configuration.transformLocalElements) ?
            false :
            configuration.transformLocalElements;
        object$$1.setTransformOnlyServerElements = function (active) {
            configuration.transformLocalElements = !active;
        };
        configuration.fullResponse = lodash.isUndefined(configuration.fullResponse) ? false : configuration.fullResponse;
        object$$1.setFullResponse = function (full) {
            configuration.fullResponse = full;
            return this;
        };
        // Internal values and functions
        configuration.urlCreatorFactory = {};
        /**
         * Base URL Creator. Base prototype for everything related to it
         *
         * @type {?}
         */
        var BaseCreator = function () {
        };
        BaseCreator.prototype.setConfig = function (config) {
            this.config = config;
            return this;
        };
        BaseCreator.prototype.parentsArray = function (current) {
            /** @type {?} */
            var parents = [];
            while (current) {
                parents.push(current);
                current = current[this.config.restangularFields.parentResource];
            }
            return parents.reverse();
        };
        /**
         * @param {?} config
         * @param {?} $http
         * @param {?} url
         * @param {?} configurer
         * @return {?}
         */
        function RestangularResource(config, $http, url, configurer) {
            /** @type {?} */
            var resource = {};
            lodash.each(lodash.keys(configurer), function (key) {
                /** @type {?} */
                var value = configurer[key];
                // Add default parameters
                value.params = lodash.extend({}, value.params, config.defaultRequestParams[value.method.toLowerCase()]);
                // We don't want the ? if no params are there
                if (lodash.isEmpty(value.params)) {
                    delete value.params;
                }
                if (config.isSafe(value.method)) {
                    resource[key] = function () {
                        /** @type {?} */
                        var resultConfig = lodash.extend(value, {
                            url: url
                        });
                        return $http.createRequest(resultConfig);
                    };
                }
                else {
                    resource[key] = function (data) {
                        /** @type {?} */
                        var resultConfig = lodash.extend(value, {
                            url: url,
                            data: data
                        });
                        return $http.createRequest(resultConfig);
                    };
                }
            });
            return resource;
        }
        BaseCreator.prototype.resource = function (current, $http, localHttpConfig, callHeaders, callParams, what, etag, operation) {
            /** @type {?} */
            var params = lodash.defaults(callParams || {}, this.config.defaultRequestParams.common);
            /** @type {?} */
            var headers = lodash.defaults(callHeaders || {}, this.config.defaultHeaders);
            if (etag) {
                if (!configuration.isSafe(operation)) {
                    headers['If-Match'] = etag;
                }
                else {
                    headers['If-None-Match'] = etag;
                }
            }
            /** @type {?} */
            var url = this.base(current);
            if (what) {
                /** @type {?} */
                var add = '';
                if (!/\/$/.test(url)) {
                    add += '/';
                }
                add += what;
                url += add;
            }
            if (this.config.suffix &&
                url.indexOf(this.config.suffix, url.length - this.config.suffix.length) === -1 && !this.config.getUrlFromElem(current)) {
                url += this.config.suffix;
            }
            current[this.config.restangularFields.httpConfig] = undefined;
            return RestangularResource(this.config, $http, url, {
                getList: this.config.withHttpValues(localHttpConfig, {
                    method: 'GET',
                    params: params,
                    headers: headers
                }),
                get: this.config.withHttpValues(localHttpConfig, {
                    method: 'GET',
                    params: params,
                    headers: headers
                }),
                jsonp: this.config.withHttpValues(localHttpConfig, {
                    method: 'jsonp',
                    params: params,
                    headers: headers
                }),
                put: this.config.withHttpValues(localHttpConfig, {
                    method: 'PUT',
                    params: params,
                    headers: headers
                }),
                post: this.config.withHttpValues(localHttpConfig, {
                    method: 'POST',
                    params: params,
                    headers: headers
                }),
                remove: this.config.withHttpValues(localHttpConfig, {
                    method: 'DELETE',
                    params: params,
                    headers: headers
                }),
                head: this.config.withHttpValues(localHttpConfig, {
                    method: 'HEAD',
                    params: params,
                    headers: headers
                }),
                trace: this.config.withHttpValues(localHttpConfig, {
                    method: 'TRACE',
                    params: params,
                    headers: headers
                }),
                options: this.config.withHttpValues(localHttpConfig, {
                    method: 'OPTIONS',
                    params: params,
                    headers: headers
                }),
                patch: this.config.withHttpValues(localHttpConfig, {
                    method: 'PATCH',
                    params: params,
                    headers: headers
                })
            });
        };
        /**
         * This is the Path URL creator. It uses Path to show Hierarchy in the Rest API.
         * This means that if you have an Account that then has a set of Buildings, a URL to a building
         * would be /accounts/123/buildings/456
         *
         * @type {?}
         */
        var Path = function () {
        };
        Path.prototype = new BaseCreator();
        Path.prototype.normalizeUrl = function (url) {
            /** @type {?} */
            var parts = /((?:http[s]?:)?\/\/)?(.*)?/.exec(url);
            parts[2] = parts[2].replace(/[\\\/]+/g, '/');
            return (typeof parts[1] !== 'undefined') ? parts[1] + parts[2] : parts[2];
        };
        Path.prototype.base = function (current) {
            /** @type {?} */
            var __this = this;
            return lodash.reduce(this.parentsArray(current), function (acum, elem) {
                /** @type {?} */
                var elemUrl;
                /** @type {?} */
                var elemSelfLink = __this.config.getUrlFromElem(elem);
                if (elemSelfLink) {
                    if (__this.config.isAbsoluteUrl(elemSelfLink)) {
                        return elemSelfLink;
                    }
                    else {
                        elemUrl = elemSelfLink;
                    }
                }
                else {
                    elemUrl = elem[__this.config.restangularFields.route];
                    if (elem[__this.config.restangularFields.restangularCollection]) {
                        /** @type {?} */
                        var ids = elem[__this.config.restangularFields.ids];
                        if (ids) {
                            elemUrl += '/' + ids.join(',');
                        }
                    }
                    else {
                        /** @type {?} */
                        var elemId = void 0;
                        if (__this.config.useCannonicalId) {
                            elemId = __this.config.getCannonicalIdFromElem(elem);
                        }
                        else {
                            elemId = __this.config.getIdFromElem(elem);
                        }
                        if (configuration.isValidId(elemId) && !elem.singleOne) {
                            elemUrl += '/' + (__this.config.encodeIds ? encodeURIComponent(elemId) : elemId);
                        }
                    }
                }
                acum = acum.replace(/\/$/, '') + '/' + elemUrl;
                return __this.normalizeUrl(acum);
            }, this.config.baseUrl);
        };
        Path.prototype.fetchUrl = function (current, what) {
            /** @type {?} */
            var baseUrl = this.base(current);
            if (what) {
                baseUrl += '/' + what;
            }
            return baseUrl;
        };
        Path.prototype.fetchRequestedUrl = function (current, what) {
            /** @type {?} */
            var url = this.fetchUrl(current, what);
            /** @type {?} */
            var params = current[configuration.restangularFields.reqParams];
            // From here on and until the end of fetchRequestedUrl,
            // the code has been kindly borrowed from angular.js
            // The reason for such code bloating is coherence:
            //   If the user were to use this for cache management, the
            //   serialization of parameters would need to be identical
            //   to the one done by angular for cache keys to match.
            /**
             * @param {?} obj
             * @return {?}
             */
            function sortedKeys(obj) {
                /** @type {?} */
                var resultKeys = [];
                for (var key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        resultKeys.push(key);
                    }
                }
                return resultKeys.sort();
            }
            /**
             * @param {?} obj
             * @param {?=} iterator
             * @param {?=} context
             * @return {?}
             */
            function forEachSorted(obj, iterator, context) {
                /** @type {?} */
                var sortedKeysArray = sortedKeys(obj);
                for (var i = 0; i < sortedKeysArray.length; i++) {
                    iterator.call(context, obj[sortedKeysArray[i]], sortedKeysArray[i]);
                }
                return sortedKeysArray;
            }
            /**
             * @param {?} val
             * @param {?=} pctEncodeSpaces
             * @return {?}
             */
            function encodeUriQuery(val, pctEncodeSpaces) {
                return encodeURIComponent(val)
                    .replace(/%40/gi, '@')
                    .replace(/%3A/gi, ':')
                    .replace(/%24/g, '$')
                    .replace(/%2C/gi, ',')
                    .replace(/%20/g, (pctEncodeSpaces ? '%20' : '+'));
            }
            if (!params) {
                return url + (this.config.suffix || '');
            }
            /** @type {?} */
            var parts = [];
            forEachSorted(params, function (value, key) {
                if (value === null || value === undefined) {
                    return;
                }
                if (!lodash.isArray(value)) {
                    value = [value];
                }
                lodash.forEach(value, function (v) {
                    if (lodash.isObject(v)) {
                        v = JSON.stringify(v);
                    }
                    parts.push(encodeUriQuery(key) + '=' + encodeUriQuery(v));
                });
            });
            return url + (this.config.suffix || '') + ((url.indexOf('?') === -1) ? '?' : '&') + parts.join('&');
        };
        configuration.urlCreatorFactory.path = Path;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    var Restangular = /** @class */ (function () {
        function Restangular(configObj, injector, http$$1) {
            this.configObj = configObj;
            this.injector = injector;
            this.http = http$$1;
            this.provider = new providerConfig(http$$1);
            /** @type {?} */
            var element = this.provider.$get();
            object.assign(this, element);
            this.setDefaultConfig();
        }
        /**
         * @return {?}
         */
        Restangular.prototype.setDefaultConfig = /**
         * @return {?}
         */
            function () {
                var _this = this;
                var _a;
                if (!this.configObj || !lodash.isFunction(this.configObj.fn)) {
                    return;
                }
                /** @type {?} */
                var arrDI = lodash.map(this.configObj.arrServices, function (services) {
                    return _this.injector.get(services);
                });
                (_a = this.configObj).fn.apply(_a, __spread([this.provider], arrDI));
            };
        Restangular.decorators = [
            { type: core.Injectable },
        ];
        /** @nocollapse */
        Restangular.ctorParameters = function () {
            return [
                { type: undefined, decorators: [{ type: core.Optional }, { type: core.Inject, args: [RESTANGULAR,] }] },
                { type: core.Injector },
                { type: RestangularHttp }
            ];
        };
        return Restangular;
    }());
    /**
     * @param {?} $http
     * @return {?}
     */
    function providerConfig($http) {
        /** @type {?} */
        var globalConfiguration = {};
        RestangularConfigurer(this, globalConfiguration);
        this.$get = $get;
        /**
         * @return {?}
         */
        function $get() {
            /**
             * @param {?} config
             * @return {?}
             */
            function createServiceForConfiguration(config) {
                /** @type {?} */
                var service = {};
                /** @type {?} */
                var urlHandler = new config.urlCreatorFactory[config.urlCreator]();
                urlHandler.setConfig(config);
                /**
                 * @param {?} parent
                 * @param {?} elem
                 * @param {?} route
                 * @param {?} reqParams
                 * @param {?} fromServer
                 * @return {?}
                 */
                function restangularizeBase(parent, elem, route, reqParams, fromServer) {
                    elem[config.restangularFields.route] = route;
                    elem[config.restangularFields.getRestangularUrl] = lodash.bind(urlHandler.fetchUrl, urlHandler, elem);
                    elem[config.restangularFields.getRequestedUrl] = lodash.bind(urlHandler.fetchRequestedUrl, urlHandler, elem);
                    elem[config.restangularFields.addRestangularMethod] = lodash.bind(addRestangularMethodFunction, elem);
                    elem[config.restangularFields.clone] = lodash.bind(copyRestangularizedElement, elem);
                    elem[config.restangularFields.reqParams] = lodash.isEmpty(reqParams) ? null : reqParams;
                    elem[config.restangularFields.withHttpConfig] = lodash.bind(withHttpConfig, elem);
                    elem[config.restangularFields.plain] = lodash.bind(stripRestangular, elem, elem);
                    // Tag element as restangularized
                    elem[config.restangularFields.restangularized] = true;
                    // RequestLess connection
                    elem[config.restangularFields.one] = lodash.bind(one, elem, elem);
                    elem[config.restangularFields.all] = lodash.bind(all, elem, elem);
                    elem[config.restangularFields.several] = lodash.bind(several, elem, elem);
                    elem[config.restangularFields.oneUrl] = lodash.bind(oneUrl, elem, elem);
                    elem[config.restangularFields.allUrl] = lodash.bind(allUrl, elem, elem);
                    elem[config.restangularFields.fromServer] = !!fromServer;
                    if (parent && config.shouldSaveParent(route)) {
                        /** @type {?} */
                        var parentId = config.getIdFromElem(parent);
                        /** @type {?} */
                        var parentUrl = config.getUrlFromElem(parent);
                        /** @type {?} */
                        var restangularFieldsForParent = lodash.union(lodash.values(lodash.pick(config.restangularFields, ['route', 'singleOne', 'parentResource'])), config.extraFields);
                        /** @type {?} */
                        var parentResource = lodash.pick(parent, restangularFieldsForParent);
                        if (config.isValidId(parentId)) {
                            config.setIdToElem(parentResource, parentId, route);
                        }
                        if (config.isValidId(parentUrl)) {
                            config.setUrlToElem(parentResource, parentUrl, route);
                        }
                        elem[config.restangularFields.parentResource] = parentResource;
                    }
                    else {
                        elem[config.restangularFields.parentResource] = null;
                    }
                    return elem;
                }
                /**
                 * @param {?} parent
                 * @param {?} route
                 * @param {?} id
                 * @param {?} singleOne
                 * @return {?}
                 */
                function one(parent, route, id, singleOne) {
                    /** @type {?} */
                    var error;
                    if (lodash.isNumber(route) || lodash.isNumber(parent)) {
                        error = 'You\'re creating a Restangular entity with the number ';
                        error += 'instead of the route or the parent. For example, you can\'t call .one(12).';
                        throw new Error(error);
                    }
                    if (lodash.isUndefined(route)) {
                        error = 'You\'re creating a Restangular entity either without the path. ';
                        error += 'For example you can\'t call .one(). Please check if your arguments are valid.';
                        throw new Error(error);
                    }
                    /** @type {?} */
                    var elem = {};
                    config.setIdToElem(elem, id, route);
                    config.setFieldToElem(config.restangularFields.singleOne, elem, singleOne);
                    return restangularizeElem(parent, elem, route, false);
                }
                /**
                 * @param {?} parent
                 * @param {?} route
                 * @return {?}
                 */
                function all(parent, route) {
                    return restangularizeCollection(parent, [], route, false);
                }
                /**
                 * @param {?} parent
                 * @param {?} route
                 * @return {?}
                 */
                function several(parent, route /*, ids */) {
                    /** @type {?} */
                    var collection = [];
                    collection[config.restangularFields.ids] = Array.prototype.splice.call(arguments, 2);
                    return restangularizeCollection(parent, collection, route, false);
                }
                /**
                 * @param {?} parent
                 * @param {?} route
                 * @param {?} url
                 * @return {?}
                 */
                function oneUrl(parent, route, url) {
                    if (!route) {
                        throw new Error('Route is mandatory when creating new Restangular objects.');
                    }
                    /** @type {?} */
                    var elem = {};
                    config.setUrlToElem(elem, url, route);
                    return restangularizeElem(parent, elem, route, false);
                }
                /**
                 * @param {?} parent
                 * @param {?} route
                 * @param {?} url
                 * @return {?}
                 */
                function allUrl(parent, route, url) {
                    if (!route) {
                        throw new Error('Route is mandatory when creating new Restangular objects.');
                    }
                    /** @type {?} */
                    var elem = {};
                    config.setUrlToElem(elem, url, route);
                    return restangularizeCollection(parent, elem, route, false);
                }
                // Promises
                /**
                 * @param {?} subject
                 * @param {?} isCollection
                 * @param {?} valueToFill
                 * @return {?}
                 */
                function restangularizeResponse(subject, isCollection, valueToFill) {
                    return subject.pipe(operators.filter(function (res) { return !!res; }));
                }
                /**
                 * @param {?} subject
                 * @param {?} response
                 * @param {?} data
                 * @param {?} filledValue
                 * @return {?}
                 */
                function resolvePromise(subject, response, data, filledValue) {
                    lodash.extend(filledValue, data);
                    // Trigger the full response interceptor.
                    if (config.fullResponse) {
                        subject.next(lodash.extend(response, {
                            data: data
                        }));
                    }
                    else {
                        subject.next(data);
                    }
                    subject.complete();
                }
                // Elements
                /**
                 * @param {?} elem
                 * @return {?}
                 */
                function stripRestangular(elem) {
                    if (lodash.isArray(elem)) {
                        /** @type {?} */
                        var array_1 = [];
                        lodash.each(elem, function (value) {
                            array_1.push(config.isRestangularized(value) ? stripRestangular(value) : value);
                        });
                        return array_1;
                    }
                    else {
                        return lodash.omit(elem, lodash.values(lodash.omit(config.restangularFields, 'id')));
                    }
                }
                /**
                 * @param {?} elem
                 * @return {?}
                 */
                function addCustomOperation(elem) {
                    elem[config.restangularFields.customOperation] = lodash.bind(customFunction, elem);
                    /** @type {?} */
                    var requestMethods = { get: customFunction, delete: customFunction };
                    lodash.each(['put', 'patch', 'post'], function (name) {
                        requestMethods[name] = function (operation, element, path, params, headers) {
                            return lodash.bind(customFunction, this)(operation, path, params, headers, element);
                        };
                    });
                    lodash.each(requestMethods, function (requestFunc, name) {
                        /** @type {?} */
                        var callOperation = name === 'delete' ? 'remove' : name;
                        lodash.each(['do', 'custom'], function (alias) {
                            elem[alias + name.toUpperCase()] = lodash.bind(requestFunc, elem, callOperation);
                        });
                    });
                    elem[config.restangularFields.customGETLIST] = lodash.bind(fetchFunction, elem);
                    elem[config.restangularFields.doGETLIST] = elem[config.restangularFields.customGETLIST];
                }
                /**
                 * @param {?} fromElement
                 * @param {?=} toElement
                 * @return {?}
                 */
                function copyRestangularizedElement(fromElement, toElement) {
                    if (toElement === void 0) {
                        toElement = {};
                    }
                    /** @type {?} */
                    var copiedElement = object.assign(toElement, fromElement);
                    return restangularizeElem(copiedElement[config.restangularFields.parentResource], copiedElement, copiedElement[config.restangularFields.route], true);
                }
                /**
                 * @param {?} parent
                 * @param {?} element
                 * @param {?} route
                 * @param {?=} fromServer
                 * @param {?=} collection
                 * @param {?=} reqParams
                 * @return {?}
                 */
                function restangularizeElem(parent, element, route, fromServer, collection, reqParams) {
                    /** @type {?} */
                    var elem = config.onBeforeElemRestangularized(element, false, route);
                    /** @type {?} */
                    var localElem = restangularizeBase(parent, elem, route, reqParams, fromServer);
                    if (config.useCannonicalId) {
                        localElem[config.restangularFields.cannonicalId] = config.getIdFromElem(localElem);
                    }
                    if (collection) {
                        localElem[config.restangularFields.getParentList] = function () {
                            return collection;
                        };
                    }
                    localElem[config.restangularFields.restangularCollection] = false;
                    localElem[config.restangularFields.get] = lodash.bind(getFunction, localElem);
                    localElem[config.restangularFields.getList] = lodash.bind(fetchFunction, localElem);
                    localElem[config.restangularFields.put] = lodash.bind(putFunction, localElem);
                    localElem[config.restangularFields.post] = lodash.bind(postFunction, localElem);
                    localElem[config.restangularFields.remove] = lodash.bind(deleteFunction, localElem);
                    localElem[config.restangularFields.head] = lodash.bind(headFunction, localElem);
                    localElem[config.restangularFields.trace] = lodash.bind(traceFunction, localElem);
                    localElem[config.restangularFields.options] = lodash.bind(optionsFunction, localElem);
                    localElem[config.restangularFields.patch] = lodash.bind(patchFunction, localElem);
                    localElem[config.restangularFields.save] = lodash.bind(save, localElem);
                    addCustomOperation(localElem);
                    return config.transformElem(localElem, false, route, service, true);
                }
                /**
                 * @param {?} parent
                 * @param {?} element
                 * @param {?} route
                 * @param {?=} fromServer
                 * @param {?=} reqParams
                 * @return {?}
                 */
                function restangularizeCollection(parent, element, route, fromServer, reqParams) {
                    /** @type {?} */
                    var elem = config.onBeforeElemRestangularized(element, true, route);
                    /** @type {?} */
                    var localElem = restangularizeBase(parent, elem, route, reqParams, fromServer);
                    localElem[config.restangularFields.restangularCollection] = true;
                    localElem[config.restangularFields.post] = lodash.bind(postFunction, localElem, null);
                    localElem[config.restangularFields.remove] = lodash.bind(deleteFunction, localElem);
                    localElem[config.restangularFields.head] = lodash.bind(headFunction, localElem);
                    localElem[config.restangularFields.trace] = lodash.bind(traceFunction, localElem);
                    localElem[config.restangularFields.putElement] = lodash.bind(putElementFunction, localElem);
                    localElem[config.restangularFields.options] = lodash.bind(optionsFunction, localElem);
                    localElem[config.restangularFields.patch] = lodash.bind(patchFunction, localElem);
                    localElem[config.restangularFields.get] = lodash.bind(getById, localElem);
                    localElem[config.restangularFields.getList] = lodash.bind(fetchFunction, localElem, null);
                    addCustomOperation(localElem);
                    return config.transformElem(localElem, true, route, service, true);
                }
                /**
                 * @param {?} parent
                 * @param {?} element
                 * @param {?} route
                 * @return {?}
                 */
                function restangularizeCollectionAndElements(parent, element, route) {
                    /** @type {?} */
                    var collection = restangularizeCollection(parent, element, route, false);
                    lodash.each(collection, function (elem) {
                        if (elem) {
                            restangularizeElem(parent, elem, route, false);
                        }
                    });
                    return collection;
                }
                /**
                 * @param {?} id
                 * @param {?} reqParams
                 * @param {?} headers
                 * @return {?}
                 */
                function getById(id, reqParams, headers) {
                    return this.customGET(id.toString(), reqParams, headers);
                }
                /**
                 * @param {?} idx
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function putElementFunction(idx, params, headers) {
                    /** @type {?} */
                    var __this = this;
                    /** @type {?} */
                    var elemToPut = this[idx];
                    /** @type {?} */
                    var subject = new rxjs.BehaviorSubject(null);
                    /** @type {?} */
                    var filledArray = [];
                    filledArray = config.transformElem(filledArray, true, elemToPut[config.restangularFields.route], service);
                    elemToPut.put(params, headers)
                        .subscribe(function (serverElem) {
                        /** @type {?} */
                        var newArray = copyRestangularizedElement(__this);
                        newArray[idx] = serverElem;
                        filledArray = newArray;
                        subject.next(newArray);
                    }, function (response) {
                        subject.error(response);
                    }, function () {
                        subject.complete();
                    });
                    return restangularizeResponse(subject, true, filledArray);
                }
                /**
                 * @param {?} resData
                 * @param {?} operation
                 * @param {?} route
                 * @param {?} fetchUrl
                 * @param {?} response
                 * @param {?} subject
                 * @return {?}
                 */
                function parseResponse(resData, operation, route, fetchUrl, response, subject) {
                    /** @type {?} */
                    var data = config.responseExtractor(resData, operation, route, fetchUrl, response, subject);
                    /** @type {?} */
                    var etag = response.headers.get('ETag');
                    if (data && etag) {
                        data[config.restangularFields.etag] = etag;
                    }
                    return data;
                }
                /**
                 * @param {?} what
                 * @param {?} reqParams
                 * @param {?} headers
                 * @return {?}
                 */
                function fetchFunction(what, reqParams, headers) {
                    /** @type {?} */
                    var __this = this;
                    /** @type {?} */
                    var subject = new rxjs.BehaviorSubject(null);
                    /** @type {?} */
                    var operation = 'getList';
                    /** @type {?} */
                    var url = urlHandler.fetchUrl(this, what);
                    /** @type {?} */
                    var whatFetched = what || __this[config.restangularFields.route];
                    /** @type {?} */
                    var request = config.fullRequestInterceptor(null, operation, whatFetched, url, headers || {}, reqParams || {}, this[config.restangularFields.httpConfig] || {});
                    /** @type {?} */
                    var filledArray = [];
                    filledArray = config.transformElem(filledArray, true, whatFetched, service);
                    /** @type {?} */
                    var method = 'getList';
                    if (config.jsonp) {
                        method = 'jsonp';
                    }
                    /** @type {?} */
                    var okCallback = function (response) {
                        /** @type {?} */
                        var resData = response.body;
                        /** @type {?} */
                        var fullParams = response.config.params;
                        /** @type {?} */
                        var data = parseResponse(resData, operation, whatFetched, url, response, subject);
                        // support empty response for getList() calls (some APIs respond with 204 and empty body)
                        if (lodash.isUndefined(data) || '' === data) {
                            data = [];
                        }
                        if (!lodash.isArray(data)) {
                            throw new Error('Response for getList SHOULD be an array and not an object or something else');
                        }
                        if (true === config.plainByDefault) {
                            return resolvePromise(subject, response, data, filledArray);
                        }
                        /** @type {?} */
                        var processedData = lodash.map(data, function (elem) {
                            if (!__this[config.restangularFields.restangularCollection]) {
                                return restangularizeElem(__this, elem, what, true, data);
                            }
                            else {
                                return restangularizeElem(__this[config.restangularFields.parentResource], elem, __this[config.restangularFields.route], true, data);
                            }
                        });
                        processedData = lodash.extend(data, processedData);
                        if (!__this[config.restangularFields.restangularCollection]) {
                            resolvePromise(subject, response, restangularizeCollection(__this, processedData, what, true, fullParams), filledArray);
                        }
                        else {
                            resolvePromise(subject, response, restangularizeCollection(__this[config.restangularFields.parentResource], processedData, __this[config.restangularFields.route], true, fullParams), filledArray);
                        }
                    };
                    urlHandler.resource(this, $http, request.httpConfig, request.headers, request.params, what, this[config.restangularFields.etag], operation)[method]()
                        .subscribe(okCallback, function error(response) {
                        if (response.status === 304 && __this[config.restangularFields.restangularCollection]) {
                            resolvePromise(subject, response, __this, filledArray);
                        }
                        else if (lodash.every(config.errorInterceptors, function (cb) {
                            return cb(response, subject, okCallback) !== false;
                        })) {
                            // triggered if no callback returns false
                            subject.error(response);
                        }
                    });
                    return restangularizeResponse(subject, true, filledArray);
                }
                /**
                 * @param {?} httpConfig
                 * @return {?}
                 */
                function withHttpConfig(httpConfig) {
                    this[config.restangularFields.httpConfig] = httpConfig;
                    return this;
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function save(params, headers) {
                    if (this[config.restangularFields.fromServer]) {
                        return this[config.restangularFields.put](params, headers);
                    }
                    else {
                        return lodash.bind(elemFunction, this)('post', undefined, params, undefined, headers);
                    }
                }
                /**
                 * @param {?} operation
                 * @param {?} what
                 * @param {?} params
                 * @param {?} obj
                 * @param {?} headers
                 * @return {?}
                 */
                function elemFunction(operation, what, params, obj, headers) {
                    /** @type {?} */
                    var __this = this;
                    /** @type {?} */
                    var subject = new rxjs.BehaviorSubject(null);
                    /** @type {?} */
                    var resParams = params || {};
                    /** @type {?} */
                    var route = what || this[config.restangularFields.route];
                    /** @type {?} */
                    var fetchUrl = urlHandler.fetchUrl(this, what);
                    /** @type {?} */
                    var callObj = obj || this;
                    // fallback to etag on restangular object (since for custom methods we probably don't explicitly specify the etag field)
                    /** @type {?} */
                    var etag = callObj[config.restangularFields.etag] || (operation !== 'post' ? this[config.restangularFields.etag] : null);
                    if (lodash.isObject(callObj) && config.isRestangularized(callObj)) {
                        callObj = stripRestangular(callObj);
                    }
                    /** @type {?} */
                    var request = config.fullRequestInterceptor(callObj, operation, route, fetchUrl, headers || {}, resParams || {}, this[config.restangularFields.httpConfig] || {});
                    /** @type {?} */
                    var filledObject = {};
                    filledObject = config.transformElem(filledObject, false, route, service);
                    /** @type {?} */
                    var okCallback = function (response) {
                        /** @type {?} */
                        var resData = lodash.get(response, 'body');
                        /** @type {?} */
                        var fullParams = lodash.get(response, 'config.params');
                        /** @type {?} */
                        var elem = parseResponse(resData, operation, route, fetchUrl, response, subject);
                        if (elem) {
                            /** @type {?} */
                            var data = void 0;
                            if (true === config.plainByDefault) {
                                return resolvePromise(subject, response, elem, filledObject);
                            }
                            if (operation === 'post' && !__this[config.restangularFields.restangularCollection]) {
                                data = restangularizeElem(__this[config.restangularFields.parentResource], elem, route, true, null, fullParams);
                                resolvePromise(subject, response, data, filledObject);
                            }
                            else {
                                data = restangularizeElem(__this[config.restangularFields.parentResource], elem, __this[config.restangularFields.route], true, null, fullParams);
                                data[config.restangularFields.singleOne] = __this[config.restangularFields.singleOne];
                                resolvePromise(subject, response, data, filledObject);
                            }
                        }
                        else {
                            resolvePromise(subject, response, undefined, filledObject);
                        }
                    };
                    /** @type {?} */
                    var errorCallback = function (response) {
                        if (response.status === 304 && config.isSafe(operation)) {
                            resolvePromise(subject, response, __this, filledObject);
                        }
                        else if (lodash.every(config.errorInterceptors, function (cb) {
                            return cb(response, subject, okCallback) !== false;
                        })) {
                            // triggered if no callback returns false
                            subject.error(response);
                        }
                    };
                    // Overriding HTTP Method
                    /** @type {?} */
                    var callOperation = operation;
                    /** @type {?} */
                    var callHeaders = lodash.extend({}, request.headers);
                    /** @type {?} */
                    var isOverrideOperation = config.isOverridenMethod(operation);
                    if (isOverrideOperation) {
                        callOperation = 'post';
                        callHeaders = lodash.extend(callHeaders, { 'X-HTTP-Method-Override': operation === 'remove' ? 'DELETE' : operation.toUpperCase() });
                    }
                    else if (config.jsonp && callOperation === 'get') {
                        callOperation = 'jsonp';
                    }
                    if (config.isSafe(operation)) {
                        if (isOverrideOperation) {
                            urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation]({}).subscribe(okCallback, errorCallback);
                        }
                        else {
                            urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation]().subscribe(okCallback, errorCallback);
                        }
                    }
                    else {
                        urlHandler.resource(this, $http, request.httpConfig, callHeaders, request.params, what, etag, callOperation)[callOperation](request.element).subscribe(okCallback, errorCallback);
                    }
                    return restangularizeResponse(subject, false, filledObject);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function getFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('get', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function deleteFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('remove', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function putFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('put', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} what
                 * @param {?} elem
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function postFunction(what, elem, params, headers) {
                    return lodash.bind(elemFunction, this)('post', what, params, elem, headers);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function headFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('head', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function traceFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('trace', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function optionsFunction(params, headers) {
                    return lodash.bind(elemFunction, this)('options', undefined, params, undefined, headers);
                }
                /**
                 * @param {?} elem
                 * @param {?} params
                 * @param {?} headers
                 * @return {?}
                 */
                function patchFunction(elem, params, headers) {
                    return lodash.bind(elemFunction, this)('patch', undefined, params, elem, headers);
                }
                /**
                 * @param {?} operation
                 * @param {?} path
                 * @param {?} params
                 * @param {?} headers
                 * @param {?} elem
                 * @return {?}
                 */
                function customFunction(operation, path, params, headers, elem) {
                    return lodash.bind(elemFunction, this)(operation, path, params, elem, headers);
                }
                /**
                 * @param {?} name
                 * @param {?} operation
                 * @param {?} path
                 * @param {?} defaultParams
                 * @param {?} defaultHeaders
                 * @param {?} defaultElem
                 * @return {?}
                 */
                function addRestangularMethodFunction(name, operation, path, defaultParams, defaultHeaders, defaultElem) {
                    /** @type {?} */
                    var bindedFunction;
                    if (operation === 'getList') {
                        bindedFunction = lodash.bind(fetchFunction, this, path);
                    }
                    else {
                        bindedFunction = lodash.bind(customFunction, this, operation, path);
                    }
                    /** @type {?} */
                    var createdFunction = function (params, headers, elem) {
                        /** @type {?} */
                        var callParams = lodash.defaults({
                            params: params,
                            headers: headers,
                            elem: elem
                        }, {
                            params: defaultParams,
                            headers: defaultHeaders,
                            elem: defaultElem
                        });
                        return bindedFunction(callParams.params, callParams.headers, callParams.elem);
                    };
                    if (config.isSafe(operation)) {
                        this[name] = createdFunction;
                    }
                    else {
                        this[name] = function (elem, params, headers) {
                            return createdFunction(params, headers, elem);
                        };
                    }
                }
                /**
                 * @param {?} configurer
                 * @return {?}
                 */
                function withConfigurationFunction(configurer) {
                    /** @type {?} */
                    var newConfig = lodash.clone(lodash.omit(config, 'configuration'));
                    RestangularConfigurer(newConfig, newConfig);
                    configurer(newConfig);
                    return createServiceForConfiguration(newConfig);
                }
                /**
                 * @param {?} route
                 * @param {?} parent
                 * @return {?}
                 */
                function toService(route, parent) {
                    /** @type {?} */
                    var knownCollectionMethods = lodash.values(config.restangularFields);
                    /** @type {?} */
                    var serv = {};
                    /** @type {?} */
                    var collection = (parent || service).all(route);
                    serv.one = lodash.bind(one, (parent || service), parent, route);
                    serv.all = lodash.bind(collection.all, collection);
                    serv.post = lodash.bind(collection.post, collection);
                    serv.getList = lodash.bind(collection.getList, collection);
                    serv.withHttpConfig = lodash.bind(collection.withHttpConfig, collection);
                    serv.get = lodash.bind(collection.get, collection);
                    for (var prop in collection) {
                        if (collection.hasOwnProperty(prop) && lodash.isFunction(collection[prop]) && !lodash.includes(knownCollectionMethods, prop)) {
                            serv[prop] = lodash.bind(collection[prop], collection);
                        }
                    }
                    return serv;
                }
                RestangularConfigurer(service, config);
                service.copy = lodash.bind(copyRestangularizedElement, service);
                service.service = lodash.bind(toService, service);
                service.withConfig = lodash.bind(withConfigurationFunction, service);
                service.one = lodash.bind(one, service, null);
                service.all = lodash.bind(all, service, null);
                service.several = lodash.bind(several, service, null);
                service.oneUrl = lodash.bind(oneUrl, service, null);
                service.allUrl = lodash.bind(allUrl, service, null);
                service.stripRestangular = lodash.bind(stripRestangular, service);
                service.restangularizeElement = lodash.bind(restangularizeElem, service);
                service.restangularizeCollection = lodash.bind(restangularizeCollectionAndElements, service);
                return service;
            }
            return createServiceForConfiguration(globalConfiguration);
        }
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */
    /** @type {?} */
    var CONFIG_OBJ = new core.InjectionToken('configObj');
    var RestangularModule = /** @class */ (function () {
        function RestangularModule(parentModule) {
            if (parentModule) {
                throw new Error('RestangularModule is already loaded. Import it in the AppModule only');
            }
        }
        /**
         * @param {?=} config1
         * @param {?=} config2
         * @return {?}
         */
        RestangularModule.forRoot = /**
         * @param {?=} config1
         * @param {?=} config2
         * @return {?}
         */
            function (config1, config2) {
                return {
                    ngModule: RestangularModule,
                    providers: [
                        { provide: CONFIG_OBJ, useValue: [config1, config2] },
                        { provide: RESTANGULAR, useFactory: RestangularFactory, deps: [CONFIG_OBJ] },
                    ]
                };
            };
        RestangularModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [http.HttpClientModule],
                        providers: [RestangularHttp, Restangular]
                    },] },
        ];
        /** @nocollapse */
        RestangularModule.ctorParameters = function () {
            return [
                { type: RestangularModule, decorators: [{ type: core.Optional }, { type: core.SkipSelf }] }
            ];
        };
        return RestangularModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
     */

    exports.RestangularModule = RestangularModule;
    exports.Restangular = Restangular;
    exports.RestangularHttp = RestangularHttp;
    exports.ɵb = RESTANGULAR;
    exports.ɵc = RestangularFactory;
    exports.ɵa = CONFIG_OBJ;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmd4LXJlc3Rhbmd1bGFyLnVtZC5qcy5tYXAiLCJzb3VyY2VzIjpbbnVsbCwibmc6Ly9uZ3gtcmVzdGFuZ3VsYXIvbGliL25neC1yZXN0YW5ndWxhci5jb25maWcudHMiLCJuZzovL25neC1yZXN0YW5ndWxhci9saWIvbmd4LXJlc3Rhbmd1bGFyLWhlbHBlci50cyIsIm5nOi8vbmd4LXJlc3Rhbmd1bGFyL2xpYi9uZ3gtcmVzdGFuZ3VsYXItaHR0cC50cyIsIm5nOi8vbmd4LXJlc3Rhbmd1bGFyL2xpYi9uZ3gtcmVzdGFuZ3VsYXItY29uZmlnLmZhY3RvcnkudHMiLCJuZzovL25neC1yZXN0YW5ndWxhci9saWIvbmd4LXJlc3Rhbmd1bGFyLnRzIiwibmc6Ly9uZ3gtcmVzdGFuZ3VsYXIvbGliL25neC1yZXN0YW5ndWxhci5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UgKi9cclxuXHJcbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgICAgICh7IF9fcHJvdG9fXzogW10gfSBpbnN0YW5jZW9mIEFycmF5ICYmIGZ1bmN0aW9uIChkLCBiKSB7IGQuX19wcm90b19fID0gYjsgfSkgfHxcclxuICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcclxuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XHJcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJpbXBvcnQgeyBJbmplY3Rpb25Ub2tlbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBpc0FycmF5IH0gZnJvbSAnbG9kYXNoJztcblxuXG5leHBvcnQgY29uc3QgUkVTVEFOR1VMQVIgPSBuZXcgSW5qZWN0aW9uVG9rZW48c3RyaW5nPigncmVzdGFuZ3VsYXJXaXRoQ29uZmlnJyk7XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXN0YW5ndWxhckZhY3RvcnkoW2NhbGxiYWNrT3JTZXJ2aWNlcywgY2FsbGJhY2tdKSB7XG4gIGxldCBhcnJTZXJ2aWNlcyA9IFtdO1xuICBsZXQgZm4gPSBjYWxsYmFja09yU2VydmljZXM7XG5cbiAgaWYgKGlzQXJyYXkoY2FsbGJhY2tPclNlcnZpY2VzKSkge1xuICAgIGFyclNlcnZpY2VzID0gY2FsbGJhY2tPclNlcnZpY2VzO1xuICAgIGZuID0gY2FsbGJhY2s7XG4gIH1cblxuICByZXR1cm4ge2ZuLCBhcnJTZXJ2aWNlc307XG59XG4iLCJpbXBvcnQgeyBIdHRwUmVxdWVzdCwgSHR0cEhlYWRlcnMsIEh0dHBQYXJhbXMgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5cbmltcG9ydCB7IGFzc2lnbiB9IGZyb20gJ2NvcmUtanMvZm4vb2JqZWN0JztcblxuZXhwb3J0IGNsYXNzIFJlc3Rhbmd1bGFySGVscGVyIHtcblxuICBzdGF0aWMgY3JlYXRlUmVxdWVzdChvcHRpb25zKSB7XG4gICAgY29uc3QgcmVxdWVzdFF1ZXJ5UGFyYW1zID0gUmVzdGFuZ3VsYXJIZWxwZXIuY3JlYXRlUmVxdWVzdFF1ZXJ5UGFyYW1zKG9wdGlvbnMucGFyYW1zKTtcbiAgICBjb25zdCByZXF1ZXN0SGVhZGVycyA9IFJlc3Rhbmd1bGFySGVscGVyLmNyZWF0ZVJlcXVlc3RIZWFkZXJzKG9wdGlvbnMuaGVhZGVycyk7XG4gICAgY29uc3QgbWV0aG9kTmFtZSA9IG9wdGlvbnMubWV0aG9kLnRvVXBwZXJDYXNlKCk7XG4gICAgY29uc3Qgd2l0aENyZWRlbnRpYWxzID0gb3B0aW9ucy53aXRoQ3JlZGVudGlhbHMgfHwgZmFsc2U7XG5cbiAgICBsZXQgcmVxdWVzdCA9IG5ldyBIdHRwUmVxdWVzdChcbiAgICAgIG1ldGhvZE5hbWUsXG4gICAgICBvcHRpb25zLnVybCxcbiAgICAgIG9wdGlvbnMuZGF0YSxcbiAgICAgIHtcbiAgICAgICAgaGVhZGVyczogcmVxdWVzdEhlYWRlcnMsXG4gICAgICAgIHBhcmFtczogcmVxdWVzdFF1ZXJ5UGFyYW1zLFxuICAgICAgICByZXNwb25zZVR5cGU6IG9wdGlvbnMucmVzcG9uc2VUeXBlLFxuICAgICAgICB3aXRoQ3JlZGVudGlhbHNcbiAgICAgIH1cbiAgICApO1xuXG4gICAgaWYgKFsnR0VUJywgJ0RFTEVURScsICdIRUFEJywgJ0pTT05QJywgJ09QVElPTlMnXS5pbmRleE9mKG1ldGhvZE5hbWUpID49IDApIHtcbiAgICAgIHJlcXVlc3QgPSBuZXcgSHR0cFJlcXVlc3QoXG4gICAgICAgIG1ldGhvZE5hbWUsXG4gICAgICAgIG9wdGlvbnMudXJsLFxuICAgICAgICB7XG4gICAgICAgICAgaGVhZGVyczogcmVxdWVzdEhlYWRlcnMsXG4gICAgICAgICAgcGFyYW1zOiByZXF1ZXN0UXVlcnlQYXJhbXMsXG4gICAgICAgICAgcmVzcG9uc2VUeXBlOiBvcHRpb25zLnJlc3BvbnNlVHlwZSxcbiAgICAgICAgICB3aXRoQ3JlZGVudGlhbHNcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcXVlc3Q7XG4gIH1cblxuICBzdGF0aWMgY3JlYXRlUmVxdWVzdFF1ZXJ5UGFyYW1zKHF1ZXJ5UGFyYW1zKSB7XG4gICAgY29uc3QgcmVxdWVzdFF1ZXJ5UGFyYW1zID0gYXNzaWduKHt9LCBxdWVyeVBhcmFtcyk7XG4gICAgbGV0IHNlYXJjaDogSHR0cFBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKCk7XG5cbiAgICBmb3IgKGNvbnN0IGtleSBpbiByZXF1ZXN0UXVlcnlQYXJhbXMpIHtcbiAgICAgIGxldCB2YWx1ZTogYW55ID0gcmVxdWVzdFF1ZXJ5UGFyYW1zW2tleV07XG5cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICB2YWx1ZS5mb3JFYWNoKGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgICAgICBzZWFyY2ggPSBzZWFyY2guYXBwZW5kKGtleSwgdmFsKTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIHZhbHVlID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHNlYXJjaCA9IHNlYXJjaC5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHNlYXJjaDtcbiAgfVxuXG4gIHN0YXRpYyBjcmVhdGVSZXF1ZXN0SGVhZGVycyhoZWFkZXJzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gaGVhZGVycykge1xuICAgICAgY29uc3QgdmFsdWU6IGFueSA9IGhlYWRlcnNba2V5XTtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGRlbGV0ZSBoZWFkZXJzW2tleV07XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBIdHRwSGVhZGVycyhhc3NpZ24oe30sIGhlYWRlcnMpKTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cEJhY2tlbmQsIEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwUmVxdWVzdCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuXG5pbXBvcnQgeyB0aHJvd0Vycm9yLCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbmltcG9ydCB7IFJlc3Rhbmd1bGFySGVscGVyIH0gZnJvbSAnLi9uZ3gtcmVzdGFuZ3VsYXItaGVscGVyJztcbmltcG9ydCB7IGNhdGNoRXJyb3IsIGZpbHRlciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgSHR0cEV2ZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAvc3JjL3Jlc3BvbnNlJztcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFJlc3Rhbmd1bGFySHR0cCB7XG5cbiAgY29uc3RydWN0b3IocHVibGljIGh0dHA6IEh0dHBCYWNrZW5kKSB7XG4gIH1cblxuICBjcmVhdGVSZXF1ZXN0KG9wdGlvbnMpOiBPYnNlcnZhYmxlPEh0dHBFdmVudDxhbnk+PiB7XG4gICAgY29uc3QgcmVxdWVzdCA9IFJlc3Rhbmd1bGFySGVscGVyLmNyZWF0ZVJlcXVlc3Qob3B0aW9ucyk7XG5cbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KHJlcXVlc3QpO1xuICB9XG5cbiAgcmVxdWVzdChyZXF1ZXN0OiBIdHRwUmVxdWVzdDxhbnk+KTogT2JzZXJ2YWJsZTxIdHRwRXZlbnQ8YW55Pj4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAuaGFuZGxlKHJlcXVlc3QpXG4gICAgLnBpcGUoXG4gICAgICBmaWx0ZXIoZXZlbnQgPT4gZXZlbnQgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2UpLFxuICAgICAgbWFwKChyZXNwb25zZTogYW55KSA9PiB7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgICByZXR1cm4gdGhyb3dFcnJvcihuZXcgSHR0cEVycm9yUmVzcG9uc2UocmVzcG9uc2UpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9KSxcbiAgICAgIG1hcChyZXNwb25zZSA9PiB7XG4gICAgICAgIHJlc3BvbnNlLmNvbmZpZyA9IHtwYXJhbXM6IHJlcXVlc3R9O1xuICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICB9KSxcbiAgICAgIGNhdGNoRXJyb3IoZXJyID0+IHtcbiAgICAgICAgZXJyLnJlcXVlc3QgPSByZXF1ZXN0O1xuICAgICAgICBlcnIuZGF0YSA9IGVyci5lcnJvcjtcbiAgICAgICAgZXJyLnJlcGVhdFJlcXVlc3QgPSAobmV3UmVxdWVzdD8pID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KG5ld1JlcXVlc3QgfHwgcmVxdWVzdCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIHRocm93RXJyb3IoZXJyKTtcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxufVxuXG4iLCJpbXBvcnQge1xuICBpbmNsdWRlcyxcbiAgaXNVbmRlZmluZWQsXG4gIGlzTnVsbCxcbiAgaXNBcnJheSxcbiAgaXNPYmplY3QsXG4gIGlzQm9vbGVhbixcbiAgZGVmYXVsdHMsXG4gIGVhY2gsXG4gIGV4dGVuZCxcbiAgZmluZCxcbiAgaGFzLFxuICBpbml0aWFsLFxuICBsYXN0LFxuICBjbG9uZSxcbiAgcmVkdWNlLFxuICBrZXlzLFxuICBpc0VtcHR5LFxuICBmb3JFYWNoLFxufSBmcm9tICdsb2Rhc2gnO1xuXG5leHBvcnQgZnVuY3Rpb24gUmVzdGFuZ3VsYXJDb25maWd1cmVyKG9iamVjdCwgY29uZmlndXJhdGlvbikge1xuICBvYmplY3QuY29uZmlndXJhdGlvbiA9IGNvbmZpZ3VyYXRpb247XG5cbiAgLyoqXG4gICAqIFRob3NlIGFyZSBIVFRQIHNhZmUgbWV0aG9kcyBmb3Igd2hpY2ggdGhlcmUgaXMgbm8gbmVlZCB0byBwYXNzIGFueSBkYXRhIHdpdGggdGhlIHJlcXVlc3QuXG4gICAqL1xuICBjb25zdCBzYWZlTWV0aG9kcyA9IFsnZ2V0JywgJ2hlYWQnLCAnb3B0aW9ucycsICd0cmFjZScsICdnZXRsaXN0J107XG4gIGNvbmZpZ3VyYXRpb24uaXNTYWZlID0gZnVuY3Rpb24gKG9wZXJhdGlvbikge1xuICAgIHJldHVybiBpbmNsdWRlcyhzYWZlTWV0aG9kcywgb3BlcmF0aW9uLnRvTG93ZXJDYXNlKCkpO1xuICB9O1xuXG4gIGNvbnN0IGFic29sdXRlUGF0dGVybiA9IC9eaHR0cHM/OlxcL1xcLy9pO1xuICBjb25maWd1cmF0aW9uLmlzQWJzb2x1dGVVcmwgPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG4gICAgcmV0dXJuIGlzVW5kZWZpbmVkKGNvbmZpZ3VyYXRpb24uYWJzb2x1dGVVcmwpIHx8IGlzTnVsbChjb25maWd1cmF0aW9uLmFic29sdXRlVXJsKSA/XG4gICAgICBzdHJpbmcgJiYgYWJzb2x1dGVQYXR0ZXJuLnRlc3Qoc3RyaW5nKSA6XG4gICAgICBjb25maWd1cmF0aW9uLmFic29sdXRlVXJsO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uYWJzb2x1dGVVcmwgPSBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLmFic29sdXRlVXJsKSA/IHRydWUgOiBjb25maWd1cmF0aW9uLmFic29sdXRlVXJsO1xuICBvYmplY3Quc2V0U2VsZkxpbmtBYnNvbHV0ZVVybCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgIGNvbmZpZ3VyYXRpb24uYWJzb2x1dGVVcmwgPSB2YWx1ZTtcbiAgfTtcbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIEJhc2VVUkwgdG8gYmUgdXNlZCB3aXRoIFJlc3Rhbmd1bGFyXG4gICAqL1xuICBjb25maWd1cmF0aW9uLmJhc2VVcmwgPSBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLmJhc2VVcmwpID8gJycgOiBjb25maWd1cmF0aW9uLmJhc2VVcmw7XG4gIG9iamVjdC5zZXRCYXNlVXJsID0gZnVuY3Rpb24gKG5ld0Jhc2VVcmwpIHtcbiAgICBjb25maWd1cmF0aW9uLmJhc2VVcmwgPSAvXFwvJC8udGVzdChuZXdCYXNlVXJsKSA/XG4gICAgICBuZXdCYXNlVXJsLnN1YnN0cmluZygwLCBuZXdCYXNlVXJsLmxlbmd0aCAtIDEpIDpcbiAgICAgIG5ld0Jhc2VVcmw7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIGV4dHJhIGZpZWxkcyB0byBrZWVwIGZyb20gdGhlIHBhcmVudHNcbiAgICovXG4gIGNvbmZpZ3VyYXRpb24uZXh0cmFGaWVsZHMgPSBjb25maWd1cmF0aW9uLmV4dHJhRmllbGRzIHx8IFtdO1xuICBvYmplY3Quc2V0RXh0cmFGaWVsZHMgPSBmdW5jdGlvbiAobmV3RXh0cmFGaWVsZHMpIHtcbiAgICBjb25maWd1cmF0aW9uLmV4dHJhRmllbGRzID0gbmV3RXh0cmFGaWVsZHM7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFNvbWUgZGVmYXVsdCAkaHR0cCBwYXJhbWV0ZXIgdG8gYmUgdXNlZCBpbiBFVkVSWSBjYWxsXG4gICAqKi9cbiAgY29uZmlndXJhdGlvbi5kZWZhdWx0SHR0cEZpZWxkcyA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdEh0dHBGaWVsZHMgfHwge307XG4gIG9iamVjdC5zZXREZWZhdWx0SHR0cEZpZWxkcyA9IGZ1bmN0aW9uICh2YWx1ZXMpIHtcbiAgICBjb25maWd1cmF0aW9uLmRlZmF1bHRIdHRwRmllbGRzID0gdmFsdWVzO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIC8qKlxuICAgKiBBbHdheXMgcmV0dXJuIHBsYWluIGRhdGEsIG5vIHJlc3Rhbmd1bGFyaXplZCBvYmplY3RcbiAgICoqL1xuICBjb25maWd1cmF0aW9uLnBsYWluQnlEZWZhdWx0ID0gY29uZmlndXJhdGlvbi5wbGFpbkJ5RGVmYXVsdCB8fCBmYWxzZTtcbiAgb2JqZWN0LnNldFBsYWluQnlEZWZhdWx0ID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgY29uZmlndXJhdGlvbi5wbGFpbkJ5RGVmYXVsdCA9IHZhbHVlID09PSB0cnVlID8gdHJ1ZSA6IGZhbHNlO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24ud2l0aEh0dHBWYWx1ZXMgPSBmdW5jdGlvbiAoaHR0cExvY2FsQ29uZmlnLCBvYmopIHtcbiAgICByZXR1cm4gZGVmYXVsdHMob2JqLCBodHRwTG9jYWxDb25maWcsIGNvbmZpZ3VyYXRpb24uZGVmYXVsdEh0dHBGaWVsZHMpO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZW5jb2RlSWRzID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5lbmNvZGVJZHMpID8gdHJ1ZSA6IGNvbmZpZ3VyYXRpb24uZW5jb2RlSWRzO1xuICBvYmplY3Quc2V0RW5jb2RlSWRzID0gZnVuY3Rpb24gKGVuY29kZSkge1xuICAgIGNvbmZpZ3VyYXRpb24uZW5jb2RlSWRzID0gZW5jb2RlO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZGVmYXVsdFJlcXVlc3RQYXJhbXMgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXF1ZXN0UGFyYW1zIHx8IHtcbiAgICBnZXQ6IHt9LFxuICAgIHBvc3Q6IHt9LFxuICAgIHB1dDoge30sXG4gICAgcmVtb3ZlOiB7fSxcbiAgICBjb21tb246IHt9XG4gIH07XG5cbiAgb2JqZWN0LnNldERlZmF1bHRSZXF1ZXN0UGFyYW1zID0gZnVuY3Rpb24gKHBhcmFtMSwgcGFyYW0yKSB7XG4gICAgbGV0IG1ldGhvZHMgPSBbXTtcbiAgICBjb25zdCBwYXJhbXMgPSBwYXJhbTIgfHwgcGFyYW0xO1xuICAgIGlmICghaXNVbmRlZmluZWQocGFyYW0yKSkge1xuICAgICAgaWYgKGlzQXJyYXkocGFyYW0xKSkge1xuICAgICAgICBtZXRob2RzID0gcGFyYW0xO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWV0aG9kcy5wdXNoKHBhcmFtMSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG1ldGhvZHMucHVzaCgnY29tbW9uJyk7XG4gICAgfVxuXG4gICAgZWFjaChtZXRob2RzLCBmdW5jdGlvbiAobWV0aG9kKSB7XG4gICAgICBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXF1ZXN0UGFyYW1zW21ldGhvZF0gPSBwYXJhbXM7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgb2JqZWN0LnJlcXVlc3RQYXJhbXMgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXF1ZXN0UGFyYW1zO1xuXG4gIGNvbmZpZ3VyYXRpb24uZGVmYXVsdEhlYWRlcnMgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRIZWFkZXJzIHx8IHt9O1xuICBvYmplY3Quc2V0RGVmYXVsdEhlYWRlcnMgPSBmdW5jdGlvbiAoaGVhZGVycykge1xuICAgIGNvbmZpZ3VyYXRpb24uZGVmYXVsdEhlYWRlcnMgPSBoZWFkZXJzO1xuICAgIG9iamVjdC5kZWZhdWx0SGVhZGVycyA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdEhlYWRlcnM7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgb2JqZWN0LmRlZmF1bHRIZWFkZXJzID0gY29uZmlndXJhdGlvbi5kZWZhdWx0SGVhZGVycztcblxuXG4gIC8qKlxuICAgKiBNZXRob2Qgb3ZlcnJpZGVycyByZXNwb25zZSBNZXRob2RcbiAgICoqL1xuICBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXNwb25zZU1ldGhvZCA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdFJlc3BvbnNlTWV0aG9kIHx8ICdwcm9taXNlJztcbiAgb2JqZWN0LnNldERlZmF1bHRSZXNwb25zZU1ldGhvZCA9IGZ1bmN0aW9uIChtZXRob2QpIHtcbiAgICBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXNwb25zZU1ldGhvZCA9IG1ldGhvZDtcbiAgICBvYmplY3QuZGVmYXVsdFJlc3BvbnNlTWV0aG9kID0gY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VNZXRob2Q7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG4gIG9iamVjdC5kZWZhdWx0UmVzcG9uc2VNZXRob2QgPSBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXNwb25zZU1ldGhvZDtcblxuICAvKipcbiAgICogTWV0aG9kIG92ZXJyaWRlcnMgd2lsbCBzZXQgd2hpY2ggbWV0aG9kcyBhcmUgc2VudCB2aWEgUE9TVCB3aXRoIGFuIFgtSFRUUC1NZXRob2QtT3ZlcnJpZGVcbiAgICoqL1xuICBjb25maWd1cmF0aW9uLm1ldGhvZE92ZXJyaWRlcnMgPSBjb25maWd1cmF0aW9uLm1ldGhvZE92ZXJyaWRlcnMgfHwgW107XG4gIG9iamVjdC5zZXRNZXRob2RPdmVycmlkZXJzID0gZnVuY3Rpb24gKHZhbHVlcykge1xuICAgIGNvbnN0IG92ZXJyaWRlcnMgPSBleHRlbmQoW10sIHZhbHVlcyk7XG4gICAgaWYgKGNvbmZpZ3VyYXRpb24uaXNPdmVycmlkZW5NZXRob2QoJ2RlbGV0ZScsIG92ZXJyaWRlcnMpKSB7XG4gICAgICBvdmVycmlkZXJzLnB1c2goJ3JlbW92ZScpO1xuICAgIH1cbiAgICBjb25maWd1cmF0aW9uLm1ldGhvZE92ZXJyaWRlcnMgPSBvdmVycmlkZXJzO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uanNvbnAgPSBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLmpzb25wKSA/IGZhbHNlIDogY29uZmlndXJhdGlvbi5qc29ucDtcbiAgb2JqZWN0LnNldEpzb25wID0gZnVuY3Rpb24gKGFjdGl2ZSkge1xuICAgIGNvbmZpZ3VyYXRpb24uanNvbnAgPSBhY3RpdmU7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5pc092ZXJyaWRlbk1ldGhvZCA9IGZ1bmN0aW9uIChtZXRob2QsIHZhbHVlcykge1xuICAgIGNvbnN0IHNlYXJjaCA9IHZhbHVlcyB8fCBjb25maWd1cmF0aW9uLm1ldGhvZE92ZXJyaWRlcnM7XG4gICAgcmV0dXJuICFpc1VuZGVmaW5lZChmaW5kKHNlYXJjaCwgZnVuY3Rpb24gKG9uZTogc3RyaW5nKSB7XG4gICAgICByZXR1cm4gb25lLnRvTG93ZXJDYXNlKCkgPT09IG1ldGhvZC50b0xvd2VyQ2FzZSgpO1xuICAgIH0pKTtcbiAgfTtcblxuICAvKipcbiAgICogU2V0cyB0aGUgVVJMIGNyZWF0b3IgdHlwZS4gRm9yIG5vdywgb25seSBQYXRoIGlzIGNyZWF0ZWQuIEluIHRoZSBmdXR1cmUgd2UnbGwgaGF2ZSBxdWVyeVBhcmFtc1xuICAgKiovXG4gIGNvbmZpZ3VyYXRpb24udXJsQ3JlYXRvciA9IGNvbmZpZ3VyYXRpb24udXJsQ3JlYXRvciB8fCAncGF0aCc7XG4gIG9iamVjdC5zZXRVcmxDcmVhdG9yID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICBpZiAoIWhhcyhjb25maWd1cmF0aW9uLnVybENyZWF0b3JGYWN0b3J5LCBuYW1lKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVUkwgUGF0aCBzZWxlY3RlZCBpc25cXCd0IHZhbGlkJyk7XG4gICAgfVxuXG4gICAgY29uZmlndXJhdGlvbi51cmxDcmVhdG9yID0gbmFtZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICAvKipcbiAgICogWW91IGNhbiBzZXQgdGhlIHJlc3Rhbmd1bGFyIGZpZWxkcyBoZXJlLiBUaGUgMyByZXF1aXJlZCBmaWVsZHMgZm9yIFJlc3Rhbmd1bGFyIGFyZTpcbiAgICpcbiAgICogaWQ6IElkIG9mIHRoZSBlbGVtZW50XG4gICAqIHJvdXRlOiBuYW1lIG9mIHRoZSByb3V0ZSBvZiB0aGlzIGVsZW1lbnRcbiAgICogcGFyZW50UmVzb3VyY2U6IHRoZSByZWZlcmVuY2UgdG8gdGhlIHBhcmVudCByZXNvdXJjZVxuICAgKlxuICAgKiAgQWxsIG9mIHRoaXMgZmllbGRzIGV4Y2VwdCBmb3IgaWQsIGFyZSBoYW5kbGVkIChhbmQgY3JlYXRlZCkgYnkgUmVzdGFuZ3VsYXIuIEJ5IGRlZmF1bHQsXG4gICAqICB0aGUgZmllbGQgdmFsdWVzIHdpbGwgYmUgaWQsIHJvdXRlIGFuZCBwYXJlbnRSZXNvdXJjZSByZXNwZWN0aXZlbHlcbiAgICovXG4gIGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMgPSBjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzIHx8IHtcbiAgICBpZDogJ2lkJyxcbiAgICByb3V0ZTogJ3JvdXRlJyxcbiAgICBwYXJlbnRSZXNvdXJjZTogJ3BhcmVudFJlc291cmNlJyxcbiAgICByZXN0YW5ndWxhckNvbGxlY3Rpb246ICdyZXN0YW5ndWxhckNvbGxlY3Rpb24nLFxuICAgIGNhbm5vbmljYWxJZDogJ19fY2Fubm9uaWNhbElkJyxcbiAgICBldGFnOiAncmVzdGFuZ3VsYXJFdGFnJyxcbiAgICBzZWxmTGluazogJ2hyZWYnLFxuICAgIGdldDogJ2dldCcsXG4gICAgZ2V0TGlzdDogJ2dldExpc3QnLFxuICAgIHB1dDogJ3B1dCcsXG4gICAgcG9zdDogJ3Bvc3QnLFxuICAgIHJlbW92ZTogJ3JlbW92ZScsXG4gICAgaGVhZDogJ2hlYWQnLFxuICAgIHRyYWNlOiAndHJhY2UnLFxuICAgIG9wdGlvbnM6ICdvcHRpb25zJyxcbiAgICBwYXRjaDogJ3BhdGNoJyxcbiAgICBnZXRSZXN0YW5ndWxhclVybDogJ2dldFJlc3Rhbmd1bGFyVXJsJyxcbiAgICBnZXRSZXF1ZXN0ZWRVcmw6ICdnZXRSZXF1ZXN0ZWRVcmwnLFxuICAgIHB1dEVsZW1lbnQ6ICdwdXRFbGVtZW50JyxcbiAgICBhZGRSZXN0YW5ndWxhck1ldGhvZDogJ2FkZFJlc3Rhbmd1bGFyTWV0aG9kJyxcbiAgICBnZXRQYXJlbnRMaXN0OiAnZ2V0UGFyZW50TGlzdCcsXG4gICAgY2xvbmU6ICdjbG9uZScsXG4gICAgaWRzOiAnaWRzJyxcbiAgICBodHRwQ29uZmlnOiAnXyRodHRwQ29uZmlnJyxcbiAgICByZXFQYXJhbXM6ICdyZXFQYXJhbXMnLFxuICAgIG9uZTogJ29uZScsXG4gICAgYWxsOiAnYWxsJyxcbiAgICBzZXZlcmFsOiAnc2V2ZXJhbCcsXG4gICAgb25lVXJsOiAnb25lVXJsJyxcbiAgICBhbGxVcmw6ICdhbGxVcmwnLFxuICAgIGN1c3RvbVBVVDogJ2N1c3RvbVBVVCcsXG4gICAgY3VzdG9tUEFUQ0g6ICdjdXN0b21QQVRDSCcsXG4gICAgY3VzdG9tUE9TVDogJ2N1c3RvbVBPU1QnLFxuICAgIGN1c3RvbURFTEVURTogJ2N1c3RvbURFTEVURScsXG4gICAgY3VzdG9tR0VUOiAnY3VzdG9tR0VUJyxcbiAgICBjdXN0b21HRVRMSVNUOiAnY3VzdG9tR0VUTElTVCcsXG4gICAgY3VzdG9tT3BlcmF0aW9uOiAnY3VzdG9tT3BlcmF0aW9uJyxcbiAgICBkb1BVVDogJ2RvUFVUJyxcbiAgICBkb1BBVENIOiAnZG9QQVRDSCcsXG4gICAgZG9QT1NUOiAnZG9QT1NUJyxcbiAgICBkb0RFTEVURTogJ2RvREVMRVRFJyxcbiAgICBkb0dFVDogJ2RvR0VUJyxcbiAgICBkb0dFVExJU1Q6ICdkb0dFVExJU1QnLFxuICAgIGZyb21TZXJ2ZXI6ICdmcm9tU2VydmVyJyxcbiAgICB3aXRoQ29uZmlnOiAnd2l0aENvbmZpZycsXG4gICAgd2l0aEh0dHBDb25maWc6ICd3aXRoSHR0cENvbmZpZycsXG4gICAgc2luZ2xlT25lOiAnc2luZ2xlT25lJyxcbiAgICBwbGFpbjogJ3BsYWluJyxcbiAgICBzYXZlOiAnc2F2ZScsXG4gICAgcmVzdGFuZ3VsYXJpemVkOiAncmVzdGFuZ3VsYXJpemVkJ1xuICB9O1xuICBvYmplY3Quc2V0UmVzdGFuZ3VsYXJGaWVsZHMgPSBmdW5jdGlvbiAocmVzRmllbGRzKSB7XG4gICAgY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcyA9XG4gICAgICBleHRlbmQoe30sIGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMsIHJlc0ZpZWxkcyk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5pc1Jlc3Rhbmd1bGFyaXplZCA9IGZ1bmN0aW9uIChvYmopIHtcbiAgICByZXR1cm4gISFvYmpbY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhcml6ZWRdO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uc2V0RmllbGRUb0VsZW0gPSBmdW5jdGlvbiAoZmllbGQsIGVsZW0sIHZhbHVlKSB7XG4gICAgY29uc3QgcHJvcGVydGllcyA9IGZpZWxkLnNwbGl0KCcuJyk7XG4gICAgbGV0IGlkVmFsdWUgPSBlbGVtO1xuICAgIGVhY2goaW5pdGlhbChwcm9wZXJ0aWVzKSwgZnVuY3Rpb24gKHByb3A6IGFueSkge1xuICAgICAgaWRWYWx1ZVtwcm9wXSA9IHt9O1xuICAgICAgaWRWYWx1ZSA9IGlkVmFsdWVbcHJvcF07XG4gICAgfSk7XG4gICAgY29uc3QgaW5kZXg6IGFueSA9IGxhc3QocHJvcGVydGllcyk7XG4gICAgaWRWYWx1ZVtpbmRleF0gPSB2YWx1ZTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmdldEZpZWxkRnJvbUVsZW0gPSBmdW5jdGlvbiAoZmllbGQsIGVsZW0pIHtcbiAgICBjb25zdCBwcm9wZXJ0aWVzID0gZmllbGQuc3BsaXQoJy4nKTtcbiAgICBsZXQgaWRWYWx1ZTogYW55ID0gZWxlbTtcbiAgICBlYWNoKHByb3BlcnRpZXMsIGZ1bmN0aW9uIChwcm9wKSB7XG4gICAgICBpZiAoaWRWYWx1ZSkge1xuICAgICAgICBpZFZhbHVlID0gaWRWYWx1ZVtwcm9wXTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gY2xvbmUoaWRWYWx1ZSk7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5zZXRJZFRvRWxlbSA9IGZ1bmN0aW9uIChlbGVtLCBpZCAvKiwgcm91dGUgKi8pIHtcbiAgICBjb25maWd1cmF0aW9uLnNldEZpZWxkVG9FbGVtKGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMuaWQsIGVsZW0sIGlkKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLmdldElkRnJvbUVsZW0gPSBmdW5jdGlvbiAoZWxlbSkge1xuICAgIHJldHVybiBjb25maWd1cmF0aW9uLmdldEZpZWxkRnJvbUVsZW0oY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5pZCwgZWxlbSk7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5pc1ZhbGlkSWQgPSBmdW5jdGlvbiAoZWxlbUlkKSB7XG4gICAgcmV0dXJuICcnICE9PSBlbGVtSWQgJiYgIWlzVW5kZWZpbmVkKGVsZW1JZCkgJiYgIWlzTnVsbChlbGVtSWQpO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uc2V0VXJsVG9FbGVtID0gZnVuY3Rpb24gKGVsZW0sIHVybCAvKiwgcm91dGUgKi8pIHtcbiAgICBjb25maWd1cmF0aW9uLnNldEZpZWxkVG9FbGVtKGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJGaWVsZHMuc2VsZkxpbmssIGVsZW0sIHVybCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5nZXRVcmxGcm9tRWxlbSA9IGZ1bmN0aW9uIChlbGVtKSB7XG4gICAgcmV0dXJuIGNvbmZpZ3VyYXRpb24uZ2V0RmllbGRGcm9tRWxlbShjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzLnNlbGZMaW5rLCBlbGVtKTtcbiAgfTtcblxuICBjb25maWd1cmF0aW9uLnVzZUNhbm5vbmljYWxJZCA9IGlzVW5kZWZpbmVkKGNvbmZpZ3VyYXRpb24udXNlQ2Fubm9uaWNhbElkKSA/IGZhbHNlIDogY29uZmlndXJhdGlvbi51c2VDYW5ub25pY2FsSWQ7XG4gIG9iamVjdC5zZXRVc2VDYW5ub25pY2FsSWQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICBjb25maWd1cmF0aW9uLnVzZUNhbm5vbmljYWxJZCA9IHZhbHVlO1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZ2V0Q2Fubm9uaWNhbElkRnJvbUVsZW0gPSBmdW5jdGlvbiAoZWxlbSkge1xuICAgIGNvbnN0IGNhbm5vbmljYWxJZCA9IGVsZW1bY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5jYW5ub25pY2FsSWRdO1xuICAgIGNvbnN0IGFjdHVhbElkID0gY29uZmlndXJhdGlvbi5pc1ZhbGlkSWQoY2Fubm9uaWNhbElkKSA/IGNhbm5vbmljYWxJZCA6IGNvbmZpZ3VyYXRpb24uZ2V0SWRGcm9tRWxlbShlbGVtKTtcbiAgICByZXR1cm4gYWN0dWFsSWQ7XG4gIH07XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIFJlc3BvbnNlIHBhcnNlci4gVGhpcyBpcyB1c2VkIGluIGNhc2UgeW91ciByZXNwb25zZSBpc24ndCBkaXJlY3RseSB0aGUgZGF0YS5cbiAgICogRm9yIGV4YW1wbGUgaWYgeW91IGhhdmUgYSByZXNwb25zZSBsaWtlIHttZXRhOiB7J21ldGEnfSwgZGF0YToge25hbWU6ICdHb250byd9fVxuICAgKiB5b3UgY2FuIGV4dHJhY3QgdGhpcyBkYXRhIHdoaWNoIGlzIHRoZSBvbmUgdGhhdCBuZWVkcyB3cmFwcGluZ1xuICAgKlxuICAgKiBUaGUgUmVzcG9uc2VFeHRyYWN0b3IgaXMgYSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHRoZSByZXNwb25zZSBhbmQgdGhlIG1ldGhvZCBleGVjdXRlZC5cbiAgICovXG5cbiAgY29uZmlndXJhdGlvbi5yZXNwb25zZUludGVyY2VwdG9ycyA9IGNvbmZpZ3VyYXRpb24ucmVzcG9uc2VJbnRlcmNlcHRvcnMgPyBbLi4uY29uZmlndXJhdGlvbi5yZXNwb25zZUludGVyY2VwdG9yc10gOiBbXTtcblxuICBjb25maWd1cmF0aW9uLmRlZmF1bHRSZXNwb25zZUludGVyY2VwdG9yID0gZnVuY3Rpb24gKGRhdGEgLyosIG9wZXJhdGlvbiwgd2hhdCwgdXJsLCByZXNwb25zZSwgc3ViamVjdCAqLykge1xuICAgIHJldHVybiBkYXRhIHx8IHt9O1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24ucmVzcG9uc2VFeHRyYWN0b3IgPSBmdW5jdGlvbiAoZGF0YSwgb3BlcmF0aW9uLCB3aGF0LCB1cmwsIHJlc3BvbnNlLCBzdWJqZWN0KSB7XG4gICAgY29uc3QgaW50ZXJjZXB0b3JzID0gY2xvbmUoY29uZmlndXJhdGlvbi5yZXNwb25zZUludGVyY2VwdG9ycyk7XG4gICAgaW50ZXJjZXB0b3JzLnB1c2goY29uZmlndXJhdGlvbi5kZWZhdWx0UmVzcG9uc2VJbnRlcmNlcHRvcik7XG4gICAgbGV0IHRoZURhdGEgPSBkYXRhO1xuICAgIGVhY2goaW50ZXJjZXB0b3JzLCBmdW5jdGlvbiAoaW50ZXJjZXB0b3I6IGFueSkge1xuICAgICAgdGhlRGF0YSA9IGludGVyY2VwdG9yKHRoZURhdGEsIG9wZXJhdGlvbixcbiAgICAgICAgd2hhdCwgdXJsLCByZXNwb25zZSwgc3ViamVjdCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoZURhdGE7XG4gIH07XG5cbiAgb2JqZWN0LmFkZFJlc3BvbnNlSW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoZXh0cmFjdG9yKSB7XG4gICAgY29uZmlndXJhdGlvbi5yZXNwb25zZUludGVyY2VwdG9ycy5wdXNoKGV4dHJhY3Rvcik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5lcnJvckludGVyY2VwdG9ycyA9IGNvbmZpZ3VyYXRpb24uZXJyb3JJbnRlcmNlcHRvcnMgPyBbLi4uY29uZmlndXJhdGlvbi5lcnJvckludGVyY2VwdG9yc10gOiBbXTtcbiAgb2JqZWN0LmFkZEVycm9ySW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoaW50ZXJjZXB0b3IpIHtcbiAgICBjb25maWd1cmF0aW9uLmVycm9ySW50ZXJjZXB0b3JzID0gW2ludGVyY2VwdG9yLCAuLi5jb25maWd1cmF0aW9uLmVycm9ySW50ZXJjZXB0b3JzXTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBvYmplY3Quc2V0UmVzcG9uc2VJbnRlcmNlcHRvciA9IG9iamVjdC5hZGRSZXNwb25zZUludGVyY2VwdG9yO1xuICBvYmplY3Quc2V0UmVzcG9uc2VFeHRyYWN0b3IgPSBvYmplY3QuYWRkUmVzcG9uc2VJbnRlcmNlcHRvcjtcbiAgb2JqZWN0LnNldEVycm9ySW50ZXJjZXB0b3IgPSBvYmplY3QuYWRkRXJyb3JJbnRlcmNlcHRvcjtcblxuICAvKipcbiAgICogUmVzcG9uc2UgaW50ZXJjZXB0b3IgaXMgY2FsbGVkIGp1c3QgYmVmb3JlIHJlc29sdmluZyBwcm9taXNlcy5cbiAgICovXG5cblxuICAvKipcbiAgICogUmVxdWVzdCBpbnRlcmNlcHRvciBpcyBjYWxsZWQgYmVmb3JlIHNlbmRpbmcgYW4gb2JqZWN0IHRvIHRoZSBzZXJ2ZXIuXG4gICAqL1xuICBjb25maWd1cmF0aW9uLnJlcXVlc3RJbnRlcmNlcHRvcnMgPSBjb25maWd1cmF0aW9uLnJlcXVlc3RJbnRlcmNlcHRvcnMgPyBbLi4uY29uZmlndXJhdGlvbi5yZXF1ZXN0SW50ZXJjZXB0b3JzXSA6IFtdO1xuXG4gIGNvbmZpZ3VyYXRpb24uZGVmYXVsdEludGVyY2VwdG9yID0gZnVuY3Rpb24gKGVsZW1lbnQsIG9wZXJhdGlvbiwgcGF0aCwgdXJsLCBoZWFkZXJzLCBwYXJhbXMsIGh0dHBDb25maWcpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZWxlbWVudDogZWxlbWVudCxcbiAgICAgIGhlYWRlcnM6IGhlYWRlcnMsXG4gICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgIGh0dHBDb25maWc6IGh0dHBDb25maWdcbiAgICB9O1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24uZnVsbFJlcXVlc3RJbnRlcmNlcHRvciA9IGZ1bmN0aW9uIChlbGVtZW50LCBvcGVyYXRpb24sIHBhdGgsIHVybCwgaGVhZGVycywgcGFyYW1zLCBodHRwQ29uZmlnKSB7XG4gICAgY29uc3QgaW50ZXJjZXB0b3JzID0gY2xvbmUoY29uZmlndXJhdGlvbi5yZXF1ZXN0SW50ZXJjZXB0b3JzKTtcbiAgICBjb25zdCBkZWZhdWx0UmVxdWVzdCA9IGNvbmZpZ3VyYXRpb24uZGVmYXVsdEludGVyY2VwdG9yKGVsZW1lbnQsIG9wZXJhdGlvbiwgcGF0aCwgdXJsLCBoZWFkZXJzLCBwYXJhbXMsIGh0dHBDb25maWcpO1xuICAgIHJldHVybiByZWR1Y2UoaW50ZXJjZXB0b3JzLCBmdW5jdGlvbiAocmVxdWVzdDogYW55LCBpbnRlcmNlcHRvcjogYW55KSB7XG5cbiAgICAgIGNvbnN0IHJldHVybkludGVyY2VwdG9yOiBhbnkgPSBpbnRlcmNlcHRvcihcbiAgICAgICAgcmVxdWVzdC5lbGVtZW50LFxuICAgICAgICBvcGVyYXRpb24sXG4gICAgICAgIHBhdGgsXG4gICAgICAgIHVybCxcbiAgICAgICAgcmVxdWVzdC5oZWFkZXJzLFxuICAgICAgICByZXF1ZXN0LnBhcmFtcyxcbiAgICAgICAgcmVxdWVzdC5odHRwQ29uZmlnXG4gICAgICApO1xuICAgICAgcmV0dXJuIGV4dGVuZChyZXF1ZXN0LCByZXR1cm5JbnRlcmNlcHRvcik7XG4gICAgfSwgZGVmYXVsdFJlcXVlc3QpO1xuICB9O1xuXG4gIG9iamVjdC5hZGRSZXF1ZXN0SW50ZXJjZXB0b3IgPSBmdW5jdGlvbiAoaW50ZXJjZXB0b3IpIHtcbiAgICBjb25maWd1cmF0aW9uLnJlcXVlc3RJbnRlcmNlcHRvcnMucHVzaChmdW5jdGlvbiAoZWxlbSwgb3BlcmF0aW9uLCBwYXRoLCB1cmwsIGhlYWRlcnMsIHBhcmFtcywgaHR0cENvbmZpZykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaGVhZGVyczogaGVhZGVycyxcbiAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgIGVsZW1lbnQ6IGludGVyY2VwdG9yKGVsZW0sIG9wZXJhdGlvbiwgcGF0aCwgdXJsKSxcbiAgICAgICAgaHR0cENvbmZpZzogaHR0cENvbmZpZ1xuICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBvYmplY3Quc2V0UmVxdWVzdEludGVyY2VwdG9yID0gb2JqZWN0LmFkZFJlcXVlc3RJbnRlcmNlcHRvcjtcblxuICBvYmplY3QuYWRkRnVsbFJlcXVlc3RJbnRlcmNlcHRvciA9IGZ1bmN0aW9uIChpbnRlcmNlcHRvcikge1xuICAgIGNvbmZpZ3VyYXRpb24ucmVxdWVzdEludGVyY2VwdG9ycy5wdXNoKGludGVyY2VwdG9yKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICBvYmplY3Quc2V0RnVsbFJlcXVlc3RJbnRlcmNlcHRvciA9IG9iamVjdC5hZGRGdWxsUmVxdWVzdEludGVyY2VwdG9yO1xuXG4gIGNvbmZpZ3VyYXRpb24ub25CZWZvcmVFbGVtUmVzdGFuZ3VsYXJpemVkID0gY29uZmlndXJhdGlvbi5vbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQgfHwgZnVuY3Rpb24gKGVsZW0pIHtcbiAgICByZXR1cm4gZWxlbTtcbiAgfTtcbiAgb2JqZWN0LnNldE9uQmVmb3JlRWxlbVJlc3Rhbmd1bGFyaXplZCA9IGZ1bmN0aW9uIChwb3N0KSB7XG4gICAgY29uZmlndXJhdGlvbi5vbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQgPSBwb3N0O1xuICAgIHJldHVybiB0aGlzO1xuICB9O1xuXG4gIG9iamVjdC5zZXRSZXN0YW5ndWxhcml6ZVByb21pc2VJbnRlcmNlcHRvciA9IGZ1bmN0aW9uIChpbnRlcmNlcHRvcikge1xuICAgIGNvbmZpZ3VyYXRpb24ucmVzdGFuZ3VsYXJpemVQcm9taXNlSW50ZXJjZXB0b3IgPSBpbnRlcmNlcHRvcjtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICAvKipcbiAgICogVGhpcyBtZXRob2QgaXMgY2FsbGVkIGFmdGVyIGFuIGVsZW1lbnQgaGFzIGJlZW4gXCJSZXN0YW5ndWxhcml6ZWRcIi5cbiAgICpcbiAgICogSXQgcmVjZWl2ZXMgdGhlIGVsZW1lbnQsIGEgYm9vbGVhbiBpbmRpY2F0aW5nIGlmIGl0J3MgYW4gZWxlbWVudCBvciBhIGNvbGxlY3Rpb25cbiAgICogYW5kIHRoZSBuYW1lIG9mIHRoZSBtb2RlbFxuICAgKlxuICAgKi9cbiAgY29uZmlndXJhdGlvbi5vbkVsZW1SZXN0YW5ndWxhcml6ZWQgPSBjb25maWd1cmF0aW9uLm9uRWxlbVJlc3Rhbmd1bGFyaXplZCB8fCBmdW5jdGlvbiAoZWxlbSkge1xuICAgIHJldHVybiBlbGVtO1xuICB9O1xuICBvYmplY3Quc2V0T25FbGVtUmVzdGFuZ3VsYXJpemVkID0gZnVuY3Rpb24gKHBvc3QpIHtcbiAgICBjb25maWd1cmF0aW9uLm9uRWxlbVJlc3Rhbmd1bGFyaXplZCA9IHBvc3Q7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5zaG91bGRTYXZlUGFyZW50ID0gY29uZmlndXJhdGlvbi5zaG91bGRTYXZlUGFyZW50IHx8IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfTtcbiAgb2JqZWN0LnNldFBhcmVudGxlc3MgPSBmdW5jdGlvbiAodmFsdWVzKSB7XG4gICAgaWYgKGlzQXJyYXkodmFsdWVzKSkge1xuICAgICAgY29uZmlndXJhdGlvbi5zaG91bGRTYXZlUGFyZW50ID0gZnVuY3Rpb24gKHJvdXRlKSB7XG4gICAgICAgIHJldHVybiAhaW5jbHVkZXModmFsdWVzLCByb3V0ZSk7XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoaXNCb29sZWFuKHZhbHVlcykpIHtcbiAgICAgIGNvbmZpZ3VyYXRpb24uc2hvdWxkU2F2ZVBhcmVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuICF2YWx1ZXM7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICAvKipcbiAgICogVGhpcyBsZXRzIHlvdSBzZXQgYSBzdWZmaXggdG8gZXZlcnkgcmVxdWVzdC5cbiAgICpcbiAgICogRm9yIGV4YW1wbGUsIGlmIHlvdXIgYXBpIHJlcXVpcmVzIHRoYXQgZm9yIEpTb24gcmVxdWVzdHMgeW91IGRvIC91c2Vycy8xMjMuanNvbiwgeW91IGNhbiBzZXQgdGhhdFxuICAgKiBpbiBoZXJlLlxuICAgKlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCB0aGUgc3VmZml4IGlzIG51bGxcbiAgICovXG4gIGNvbmZpZ3VyYXRpb24uc3VmZml4ID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi5zdWZmaXgpID8gbnVsbCA6IGNvbmZpZ3VyYXRpb24uc3VmZml4O1xuICBvYmplY3Quc2V0UmVxdWVzdFN1ZmZpeCA9IGZ1bmN0aW9uIChuZXdTdWZmaXgpIHtcbiAgICBjb25maWd1cmF0aW9uLnN1ZmZpeCA9IG5ld1N1ZmZpeDtcbiAgICByZXR1cm4gdGhpcztcbiAgfTtcblxuICAvKipcbiAgICogQWRkIGVsZW1lbnQgdHJhbnNmb3JtZXJzIGZvciBjZXJ0YWluIHJvdXRlcy5cbiAgICovXG4gIGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtZXJzID0gY29uZmlndXJhdGlvbi50cmFuc2Zvcm1lcnMgfHwge307XG4gIG9iamVjdC5hZGRFbGVtZW50VHJhbnNmb3JtZXIgPSBmdW5jdGlvbiAodHlwZSwgc2Vjb25kQXJnLCB0aGlyZEFyZykge1xuICAgIGxldCBpc0NvbGxlY3Rpb24gPSBudWxsO1xuICAgIGxldCB0cmFuc2Zvcm1lciA9IG51bGw7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDIpIHtcbiAgICAgIHRyYW5zZm9ybWVyID0gc2Vjb25kQXJnO1xuICAgIH0gZWxzZSB7XG4gICAgICB0cmFuc2Zvcm1lciA9IHRoaXJkQXJnO1xuICAgICAgaXNDb2xsZWN0aW9uID0gc2Vjb25kQXJnO1xuICAgIH1cblxuICAgIGxldCB0eXBlVHJhbnNmb3JtZXJzID0gY29uZmlndXJhdGlvbi50cmFuc2Zvcm1lcnNbdHlwZV07XG4gICAgaWYgKCF0eXBlVHJhbnNmb3JtZXJzKSB7XG4gICAgICB0eXBlVHJhbnNmb3JtZXJzID0gY29uZmlndXJhdGlvbi50cmFuc2Zvcm1lcnNbdHlwZV0gPSBbXTtcbiAgICB9XG5cbiAgICB0eXBlVHJhbnNmb3JtZXJzLnB1c2goZnVuY3Rpb24gKGNvbGwsIGVsZW0pIHtcbiAgICAgIGlmIChpc051bGwoaXNDb2xsZWN0aW9uKSB8fCAoY29sbCA9PT0gaXNDb2xsZWN0aW9uKSkge1xuICAgICAgICByZXR1cm4gdHJhbnNmb3JtZXIoZWxlbSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZWxlbTtcbiAgICB9KTtcblxuICAgIHJldHVybiBvYmplY3Q7XG4gIH07XG5cbiAgb2JqZWN0LmV4dGVuZENvbGxlY3Rpb24gPSBmdW5jdGlvbiAocm91dGUsIGZuKSB7XG4gICAgcmV0dXJuIG9iamVjdC5hZGRFbGVtZW50VHJhbnNmb3JtZXIocm91dGUsIHRydWUsIGZuKTtcbiAgfTtcblxuICBvYmplY3QuZXh0ZW5kTW9kZWwgPSBmdW5jdGlvbiAocm91dGUsIGZuKSB7XG4gICAgcmV0dXJuIG9iamVjdC5hZGRFbGVtZW50VHJhbnNmb3JtZXIocm91dGUsIGZhbHNlLCBmbik7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi50cmFuc2Zvcm1FbGVtID0gZnVuY3Rpb24gKGVsZW0sIGlzQ29sbGVjdGlvbiwgcm91dGUsIFJlc3Rhbmd1bGFyLCBmb3JjZSkge1xuICAgIGlmICghZm9yY2UgJiYgIWNvbmZpZ3VyYXRpb24udHJhbnNmb3JtTG9jYWxFbGVtZW50cyAmJiAhZWxlbVtjb25maWd1cmF0aW9uLnJlc3Rhbmd1bGFyRmllbGRzLmZyb21TZXJ2ZXJdKSB7XG4gICAgICByZXR1cm4gZWxlbTtcbiAgICB9XG4gICAgY29uc3QgdHlwZVRyYW5zZm9ybWVycyA9IGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtZXJzW3JvdXRlXTtcbiAgICBsZXQgY2hhbmdlZEVsZW0gPSBlbGVtO1xuICAgIGlmICh0eXBlVHJhbnNmb3JtZXJzKSB7XG4gICAgICBlYWNoKHR5cGVUcmFuc2Zvcm1lcnMsIGZ1bmN0aW9uICh0cmFuc2Zvcm1lcjogKGlzQ29sbGVjdGlvbjogYm9vbGVhbiwgY2hhbmdlZEVsZW06IGFueSkgPT4gYW55KSB7XG4gICAgICAgIGNoYW5nZWRFbGVtID0gdHJhbnNmb3JtZXIoaXNDb2xsZWN0aW9uLCBjaGFuZ2VkRWxlbSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbmZpZ3VyYXRpb24ub25FbGVtUmVzdGFuZ3VsYXJpemVkKGNoYW5nZWRFbGVtLCBpc0NvbGxlY3Rpb24sIHJvdXRlLCBSZXN0YW5ndWxhcik7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi50cmFuc2Zvcm1Mb2NhbEVsZW1lbnRzID0gaXNVbmRlZmluZWQoY29uZmlndXJhdGlvbi50cmFuc2Zvcm1Mb2NhbEVsZW1lbnRzKSA/XG4gICAgZmFsc2UgOlxuICAgIGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtTG9jYWxFbGVtZW50cztcblxuICBvYmplY3Quc2V0VHJhbnNmb3JtT25seVNlcnZlckVsZW1lbnRzID0gZnVuY3Rpb24gKGFjdGl2ZSkge1xuICAgIGNvbmZpZ3VyYXRpb24udHJhbnNmb3JtTG9jYWxFbGVtZW50cyA9ICFhY3RpdmU7XG4gIH07XG5cbiAgY29uZmlndXJhdGlvbi5mdWxsUmVzcG9uc2UgPSBpc1VuZGVmaW5lZChjb25maWd1cmF0aW9uLmZ1bGxSZXNwb25zZSkgPyBmYWxzZSA6IGNvbmZpZ3VyYXRpb24uZnVsbFJlc3BvbnNlO1xuICBvYmplY3Quc2V0RnVsbFJlc3BvbnNlID0gZnVuY3Rpb24gKGZ1bGwpIHtcbiAgICBjb25maWd1cmF0aW9uLmZ1bGxSZXNwb25zZSA9IGZ1bGw7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cblxuICAvLyBJbnRlcm5hbCB2YWx1ZXMgYW5kIGZ1bmN0aW9uc1xuICBjb25maWd1cmF0aW9uLnVybENyZWF0b3JGYWN0b3J5ID0ge307XG5cbiAgLyoqXG4gICAqIEJhc2UgVVJMIENyZWF0b3IuIEJhc2UgcHJvdG90eXBlIGZvciBldmVyeXRoaW5nIHJlbGF0ZWQgdG8gaXRcbiAgICoqL1xuXG4gIGNvbnN0IEJhc2VDcmVhdG9yID0gZnVuY3Rpb24gKCkge1xuICB9O1xuXG4gIEJhc2VDcmVhdG9yLnByb3RvdHlwZS5zZXRDb25maWcgPSBmdW5jdGlvbiAoY29uZmlnKSB7XG4gICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH07XG5cbiAgQmFzZUNyZWF0b3IucHJvdG90eXBlLnBhcmVudHNBcnJheSA9IGZ1bmN0aW9uIChjdXJyZW50KSB7XG4gICAgY29uc3QgcGFyZW50cyA9IFtdO1xuICAgIHdoaWxlIChjdXJyZW50KSB7XG4gICAgICBwYXJlbnRzLnB1c2goY3VycmVudCk7XG4gICAgICBjdXJyZW50ID0gY3VycmVudFt0aGlzLmNvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV07XG4gICAgfVxuICAgIHJldHVybiBwYXJlbnRzLnJldmVyc2UoKTtcbiAgfTtcblxuICBmdW5jdGlvbiBSZXN0YW5ndWxhclJlc291cmNlKGNvbmZpZywgJGh0dHAsIHVybCwgY29uZmlndXJlcikge1xuICAgIGNvbnN0IHJlc291cmNlID0ge307XG4gICAgZWFjaChrZXlzKGNvbmZpZ3VyZXIpLCBmdW5jdGlvbiAoa2V5KSB7XG4gICAgICBjb25zdCB2YWx1ZSA9IGNvbmZpZ3VyZXJba2V5XTtcblxuICAgICAgLy8gQWRkIGRlZmF1bHQgcGFyYW1ldGVyc1xuICAgICAgdmFsdWUucGFyYW1zID0gZXh0ZW5kKHt9LCB2YWx1ZS5wYXJhbXMsIGNvbmZpZy5kZWZhdWx0UmVxdWVzdFBhcmFtc1t2YWx1ZS5tZXRob2QudG9Mb3dlckNhc2UoKV0pO1xuICAgICAgLy8gV2UgZG9uJ3Qgd2FudCB0aGUgPyBpZiBubyBwYXJhbXMgYXJlIHRoZXJlXG4gICAgICBpZiAoaXNFbXB0eSh2YWx1ZS5wYXJhbXMpKSB7XG4gICAgICAgIGRlbGV0ZSB2YWx1ZS5wYXJhbXM7XG4gICAgICB9XG5cbiAgICAgIGlmIChjb25maWcuaXNTYWZlKHZhbHVlLm1ldGhvZCkpIHtcblxuICAgICAgICByZXNvdXJjZVtrZXldID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdENvbmZpZyA9IGV4dGVuZCh2YWx1ZSwge1xuICAgICAgICAgICAgdXJsOiB1cmxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gJGh0dHAuY3JlYXRlUmVxdWVzdChyZXN1bHRDb25maWcpO1xuICAgICAgICB9O1xuXG4gICAgICB9IGVsc2Uge1xuXG4gICAgICAgIHJlc291cmNlW2tleV0gPSBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdENvbmZpZyA9IGV4dGVuZCh2YWx1ZSwge1xuICAgICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgICBkYXRhOiBkYXRhXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuICRodHRwLmNyZWF0ZVJlcXVlc3QocmVzdWx0Q29uZmlnKTtcbiAgICAgICAgfTtcblxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIHJlc291cmNlO1xuICB9XG5cbiAgQmFzZUNyZWF0b3IucHJvdG90eXBlLnJlc291cmNlID0gZnVuY3Rpb24gKGN1cnJlbnQsICRodHRwLCBsb2NhbEh0dHBDb25maWcsIGNhbGxIZWFkZXJzLCBjYWxsUGFyYW1zLCB3aGF0LCBldGFnLCBvcGVyYXRpb24pIHtcbiAgICBjb25zdCBwYXJhbXMgPSBkZWZhdWx0cyhjYWxsUGFyYW1zIHx8IHt9LCB0aGlzLmNvbmZpZy5kZWZhdWx0UmVxdWVzdFBhcmFtcy5jb21tb24pO1xuICAgIGNvbnN0IGhlYWRlcnMgPSBkZWZhdWx0cyhjYWxsSGVhZGVycyB8fCB7fSwgdGhpcy5jb25maWcuZGVmYXVsdEhlYWRlcnMpO1xuXG4gICAgaWYgKGV0YWcpIHtcbiAgICAgIGlmICghY29uZmlndXJhdGlvbi5pc1NhZmUob3BlcmF0aW9uKSkge1xuICAgICAgICBoZWFkZXJzWydJZi1NYXRjaCddID0gZXRhZztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGhlYWRlcnNbJ0lmLU5vbmUtTWF0Y2gnXSA9IGV0YWc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgbGV0IHVybCA9IHRoaXMuYmFzZShjdXJyZW50KTtcblxuICAgIGlmICh3aGF0KSB7XG4gICAgICBsZXQgYWRkID0gJyc7XG4gICAgICBpZiAoIS9cXC8kLy50ZXN0KHVybCkpIHtcbiAgICAgICAgYWRkICs9ICcvJztcbiAgICAgIH1cbiAgICAgIGFkZCArPSB3aGF0O1xuICAgICAgdXJsICs9IGFkZDtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5jb25maWcuc3VmZml4ICYmXG4gICAgICB1cmwuaW5kZXhPZih0aGlzLmNvbmZpZy5zdWZmaXgsIHVybC5sZW5ndGggLSB0aGlzLmNvbmZpZy5zdWZmaXgubGVuZ3RoKSA9PT0gLTEgJiYgIXRoaXMuY29uZmlnLmdldFVybEZyb21FbGVtKGN1cnJlbnQpKSB7XG4gICAgICB1cmwgKz0gdGhpcy5jb25maWcuc3VmZml4O1xuICAgIH1cblxuICAgIGN1cnJlbnRbdGhpcy5jb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaHR0cENvbmZpZ10gPSB1bmRlZmluZWQ7XG5cbiAgICByZXR1cm4gUmVzdGFuZ3VsYXJSZXNvdXJjZSh0aGlzLmNvbmZpZywgJGh0dHAsIHVybCwge1xuICAgICAgZ2V0TGlzdDogdGhpcy5jb25maWcud2l0aEh0dHBWYWx1ZXMobG9jYWxIdHRwQ29uZmlnLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXG4gICAgICAgIH0pLFxuXG4gICAgICBnZXQ6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAganNvbnA6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ2pzb25wJyxcbiAgICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXG4gICAgICAgIH0pLFxuXG4gICAgICBwdXQ6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgcG9zdDogdGhpcy5jb25maWcud2l0aEh0dHBWYWx1ZXMobG9jYWxIdHRwQ29uZmlnLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgcmVtb3ZlOiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIGhlYWQ6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ0hFQUQnLFxuICAgICAgICAgIHBhcmFtczogcGFyYW1zLFxuICAgICAgICAgIGhlYWRlcnM6IGhlYWRlcnNcbiAgICAgICAgfSksXG5cbiAgICAgIHRyYWNlOiB0aGlzLmNvbmZpZy53aXRoSHR0cFZhbHVlcyhsb2NhbEh0dHBDb25maWcsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6ICdUUkFDRScsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgb3B0aW9uczogdGhpcy5jb25maWcud2l0aEh0dHBWYWx1ZXMobG9jYWxIdHRwQ29uZmlnLFxuICAgICAgICB7XG4gICAgICAgICAgbWV0aG9kOiAnT1BUSU9OUycsXG4gICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgaGVhZGVyczogaGVhZGVyc1xuICAgICAgICB9KSxcblxuICAgICAgcGF0Y2g6IHRoaXMuY29uZmlnLndpdGhIdHRwVmFsdWVzKGxvY2FsSHR0cENvbmZpZyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgICBwYXJhbXM6IHBhcmFtcyxcbiAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzXG4gICAgICAgIH0pXG4gICAgfSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIFBhdGggVVJMIGNyZWF0b3IuIEl0IHVzZXMgUGF0aCB0byBzaG93IEhpZXJhcmNoeSBpbiB0aGUgUmVzdCBBUEkuXG4gICAqIFRoaXMgbWVhbnMgdGhhdCBpZiB5b3UgaGF2ZSBhbiBBY2NvdW50IHRoYXQgdGhlbiBoYXMgYSBzZXQgb2YgQnVpbGRpbmdzLCBhIFVSTCB0byBhIGJ1aWxkaW5nXG4gICAqIHdvdWxkIGJlIC9hY2NvdW50cy8xMjMvYnVpbGRpbmdzLzQ1NlxuICAgKiovXG4gIGNvbnN0IFBhdGggPSBmdW5jdGlvbiAoKSB7XG4gIH07XG5cbiAgUGF0aC5wcm90b3R5cGUgPSBuZXcgQmFzZUNyZWF0b3IoKTtcblxuICBQYXRoLnByb3RvdHlwZS5ub3JtYWxpemVVcmwgPSBmdW5jdGlvbiAodXJsKSB7XG4gICAgY29uc3QgcGFydHMgPSAvKCg/Omh0dHBbc10/Oik/XFwvXFwvKT8oLiopPy8uZXhlYyh1cmwpO1xuICAgIHBhcnRzWzJdID0gcGFydHNbMl0ucmVwbGFjZSgvW1xcXFxcXC9dKy9nLCAnLycpO1xuICAgIHJldHVybiAodHlwZW9mIHBhcnRzWzFdICE9PSAndW5kZWZpbmVkJykgPyBwYXJ0c1sxXSArIHBhcnRzWzJdIDogcGFydHNbMl07XG4gIH07XG5cbiAgUGF0aC5wcm90b3R5cGUuYmFzZSA9IGZ1bmN0aW9uIChjdXJyZW50KSB7XG4gICAgY29uc3QgX190aGlzID0gdGhpcztcbiAgICByZXR1cm4gcmVkdWNlKHRoaXMucGFyZW50c0FycmF5KGN1cnJlbnQpLCBmdW5jdGlvbiAoYWN1bTogYW55LCBlbGVtOiBhbnkpIHtcbiAgICAgIGxldCBlbGVtVXJsO1xuICAgICAgY29uc3QgZWxlbVNlbGZMaW5rID0gX190aGlzLmNvbmZpZy5nZXRVcmxGcm9tRWxlbShlbGVtKTtcbiAgICAgIGlmIChlbGVtU2VsZkxpbmspIHtcbiAgICAgICAgaWYgKF9fdGhpcy5jb25maWcuaXNBYnNvbHV0ZVVybChlbGVtU2VsZkxpbmspKSB7XG4gICAgICAgICAgcmV0dXJuIGVsZW1TZWxmTGluaztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBlbGVtVXJsID0gZWxlbVNlbGZMaW5rO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbGVtVXJsID0gZWxlbVtfX3RoaXMuY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXTtcblxuICAgICAgICBpZiAoZWxlbVtfX3RoaXMuY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlc3Rhbmd1bGFyQ29sbGVjdGlvbl0pIHtcbiAgICAgICAgICBjb25zdCBpZHMgPSBlbGVtW19fdGhpcy5jb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaWRzXTtcbiAgICAgICAgICBpZiAoaWRzKSB7XG4gICAgICAgICAgICBlbGVtVXJsICs9ICcvJyArIGlkcy5qb2luKCcsJyk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxldCBlbGVtSWQ6IGFueTtcbiAgICAgICAgICBpZiAoX190aGlzLmNvbmZpZy51c2VDYW5ub25pY2FsSWQpIHtcbiAgICAgICAgICAgIGVsZW1JZCA9IF9fdGhpcy5jb25maWcuZ2V0Q2Fubm9uaWNhbElkRnJvbUVsZW0oZWxlbSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGVsZW1JZCA9IF9fdGhpcy5jb25maWcuZ2V0SWRGcm9tRWxlbShlbGVtKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoY29uZmlndXJhdGlvbi5pc1ZhbGlkSWQoZWxlbUlkKSAmJiAhZWxlbS5zaW5nbGVPbmUpIHtcbiAgICAgICAgICAgIGVsZW1VcmwgKz0gJy8nICsgKF9fdGhpcy5jb25maWcuZW5jb2RlSWRzID8gZW5jb2RlVVJJQ29tcG9uZW50KGVsZW1JZCkgOiBlbGVtSWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgYWN1bSA9IGFjdW0ucmVwbGFjZSgvXFwvJC8sICcnKSArICcvJyArIGVsZW1Vcmw7XG4gICAgICByZXR1cm4gX190aGlzLm5vcm1hbGl6ZVVybChhY3VtKTtcblxuICAgIH0sIHRoaXMuY29uZmlnLmJhc2VVcmwpO1xuICB9O1xuXG5cbiAgUGF0aC5wcm90b3R5cGUuZmV0Y2hVcmwgPSBmdW5jdGlvbiAoY3VycmVudCwgd2hhdCkge1xuICAgIGxldCBiYXNlVXJsID0gdGhpcy5iYXNlKGN1cnJlbnQpO1xuICAgIGlmICh3aGF0KSB7XG4gICAgICBiYXNlVXJsICs9ICcvJyArIHdoYXQ7XG4gICAgfVxuICAgIHJldHVybiBiYXNlVXJsO1xuICB9O1xuXG4gIFBhdGgucHJvdG90eXBlLmZldGNoUmVxdWVzdGVkVXJsID0gZnVuY3Rpb24gKGN1cnJlbnQsIHdoYXQpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLmZldGNoVXJsKGN1cnJlbnQsIHdoYXQpO1xuICAgIGNvbnN0IHBhcmFtcyA9IGN1cnJlbnRbY29uZmlndXJhdGlvbi5yZXN0YW5ndWxhckZpZWxkcy5yZXFQYXJhbXNdO1xuXG4gICAgLy8gRnJvbSBoZXJlIG9uIGFuZCB1bnRpbCB0aGUgZW5kIG9mIGZldGNoUmVxdWVzdGVkVXJsLFxuICAgIC8vIHRoZSBjb2RlIGhhcyBiZWVuIGtpbmRseSBib3Jyb3dlZCBmcm9tIGFuZ3VsYXIuanNcbiAgICAvLyBUaGUgcmVhc29uIGZvciBzdWNoIGNvZGUgYmxvYXRpbmcgaXMgY29oZXJlbmNlOlxuICAgIC8vICAgSWYgdGhlIHVzZXIgd2VyZSB0byB1c2UgdGhpcyBmb3IgY2FjaGUgbWFuYWdlbWVudCwgdGhlXG4gICAgLy8gICBzZXJpYWxpemF0aW9uIG9mIHBhcmFtZXRlcnMgd291bGQgbmVlZCB0byBiZSBpZGVudGljYWxcbiAgICAvLyAgIHRvIHRoZSBvbmUgZG9uZSBieSBhbmd1bGFyIGZvciBjYWNoZSBrZXlzIHRvIG1hdGNoLlxuICAgIGZ1bmN0aW9uIHNvcnRlZEtleXMob2JqKSB7XG4gICAgICBjb25zdCByZXN1bHRLZXlzID0gW107XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICAgICAgaWYgKG9iai5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgICAgcmVzdWx0S2V5cy5wdXNoKGtleSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHRLZXlzLnNvcnQoKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBmb3JFYWNoU29ydGVkKG9iaiwgaXRlcmF0b3I/LCBjb250ZXh0Pykge1xuICAgICAgY29uc3Qgc29ydGVkS2V5c0FycmF5ID0gc29ydGVkS2V5cyhvYmopO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzb3J0ZWRLZXlzQXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaXRlcmF0b3IuY2FsbChjb250ZXh0LCBvYmpbc29ydGVkS2V5c0FycmF5W2ldXSwgc29ydGVkS2V5c0FycmF5W2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzb3J0ZWRLZXlzQXJyYXk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gZW5jb2RlVXJpUXVlcnkodmFsLCBwY3RFbmNvZGVTcGFjZXM/KSB7XG4gICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbClcbiAgICAgIC5yZXBsYWNlKC8lNDAvZ2ksICdAJylcbiAgICAgIC5yZXBsYWNlKC8lM0EvZ2ksICc6JylcbiAgICAgIC5yZXBsYWNlKC8lMjQvZywgJyQnKVxuICAgICAgLnJlcGxhY2UoLyUyQy9naSwgJywnKVxuICAgICAgLnJlcGxhY2UoLyUyMC9nLCAocGN0RW5jb2RlU3BhY2VzID8gJyUyMCcgOiAnKycpKTtcbiAgICB9XG5cbiAgICBpZiAoIXBhcmFtcykge1xuICAgICAgcmV0dXJuIHVybCArICh0aGlzLmNvbmZpZy5zdWZmaXggfHwgJycpO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcnRzID0gW107XG4gICAgZm9yRWFjaFNvcnRlZChwYXJhbXMsIGZ1bmN0aW9uICh2YWx1ZSwga2V5KSB7XG4gICAgICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIWlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHZhbHVlID0gW3ZhbHVlXTtcbiAgICAgIH1cblxuICAgICAgZm9yRWFjaCh2YWx1ZSwgZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgaWYgKGlzT2JqZWN0KHYpKSB7XG4gICAgICAgICAgdiA9IEpTT04uc3RyaW5naWZ5KHYpO1xuICAgICAgICB9XG4gICAgICAgIHBhcnRzLnB1c2goZW5jb2RlVXJpUXVlcnkoa2V5KSArICc9JyArIGVuY29kZVVyaVF1ZXJ5KHYpKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHVybCArICh0aGlzLmNvbmZpZy5zdWZmaXggfHwgJycpICsgKCh1cmwuaW5kZXhPZignPycpID09PSAtMSkgPyAnPycgOiAnJicpICsgcGFydHMuam9pbignJicpO1xuICB9O1xuXG4gIGNvbmZpZ3VyYXRpb24udXJsQ3JlYXRvckZhY3RvcnkucGF0aCA9IFBhdGg7XG59XG4iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBJbmplY3QsIEluamVjdG9yLCBPcHRpb25hbCwgVHlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgYXNzaWduIH0gZnJvbSAnY29yZS1qcy9mbi9vYmplY3QnO1xuaW1wb3J0IHtcbiAgbWFwLFxuICBiaW5kLFxuICB1bmlvbixcbiAgdmFsdWVzLFxuICBwaWNrLFxuICBpc0VtcHR5LFxuICBpc0Z1bmN0aW9uLFxuICBpc051bWJlcixcbiAgaXNVbmRlZmluZWQsXG4gIGlzQXJyYXksXG4gIGlzT2JqZWN0LFxuICBleHRlbmQsXG4gIGVhY2gsXG4gIGV2ZXJ5LFxuICBvbWl0LFxuICBnZXQsXG4gIGRlZmF1bHRzLFxuICBjbG9uZSxcbiAgaW5jbHVkZXNcbn0gZnJvbSAnbG9kYXNoJztcblxuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmaWx0ZXIgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbmltcG9ydCB7IFJFU1RBTkdVTEFSIH0gZnJvbSAnLi9uZ3gtcmVzdGFuZ3VsYXIuY29uZmlnJztcbmltcG9ydCB7IFJlc3Rhbmd1bGFySHR0cCB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLWh0dHAnO1xuaW1wb3J0IHsgUmVzdGFuZ3VsYXJDb25maWd1cmVyIH0gZnJvbSAnLi9uZ3gtcmVzdGFuZ3VsYXItY29uZmlnLmZhY3RvcnknO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgUmVzdGFuZ3VsYXIge1xuICBwcm92aWRlcjoge1xuICAgIHNldEJhc2VVcmw6IGFueSxcbiAgICBzZXREZWZhdWx0SGVhZGVyczogYW55LFxuICAgIGNvbmZpZ3VyYXRpb246IGFueSxcbiAgICBzZXRTZWxmTGlua0Fic29sdXRlVXJsOiBhbnksXG4gICAgc2V0RXh0cmFGaWVsZHM6IGFueSxcbiAgICBzZXREZWZhdWx0SHR0cEZpZWxkczogYW55LFxuICAgIHNldFBsYWluQnlEZWZhdWx0OiBhbnksXG4gICAgc2V0RW5jb2RlSWRzOiBhbnksXG4gICAgc2V0RGVmYXVsdFJlcXVlc3RQYXJhbXM6IGFueSxcbiAgICByZXF1ZXN0UGFyYW1zOiBhbnksXG4gICAgZGVmYXVsdEhlYWRlcnM6IGFueSxcbiAgICBzZXREZWZhdWx0UmVzcG9uc2VNZXRob2Q6IGFueSxcbiAgICBkZWZhdWx0UmVzcG9uc2VNZXRob2Q6IGFueSxcbiAgICBzZXRNZXRob2RPdmVycmlkZXJzOiBhbnksXG4gICAgc2V0SnNvbnA6IGFueSxcbiAgICBzZXRVcmxDcmVhdG9yOiBhbnksXG4gICAgc2V0UmVzdGFuZ3VsYXJGaWVsZHM6IGFueSxcbiAgICBzZXRVc2VDYW5ub25pY2FsSWQ6IGFueSxcbiAgICBhZGRSZXNwb25zZUludGVyY2VwdG9yOiBhbnksXG4gICAgYWRkRXJyb3JJbnRlcmNlcHRvcjogYW55LFxuICAgIHNldFJlc3BvbnNlSW50ZXJjZXB0b3I6IGFueSxcbiAgICBzZXRSZXNwb25zZUV4dHJhY3RvcjogYW55LFxuICAgIHNldEVycm9ySW50ZXJjZXB0b3I6IGFueSxcbiAgICBhZGRSZXF1ZXN0SW50ZXJjZXB0b3I6IGFueSxcbiAgICBzZXRSZXF1ZXN0SW50ZXJjZXB0b3I6IGFueSxcbiAgICBzZXRGdWxsUmVxdWVzdEludGVyY2VwdG9yOiBhbnksXG4gICAgYWRkRnVsbFJlcXVlc3RJbnRlcmNlcHRvcjogYW55LFxuICAgIHNldE9uQmVmb3JlRWxlbVJlc3Rhbmd1bGFyaXplZDogYW55LFxuICAgIHNldFJlc3Rhbmd1bGFyaXplUHJvbWlzZUludGVyY2VwdG9yOiBhbnksXG4gICAgc2V0T25FbGVtUmVzdGFuZ3VsYXJpemVkOiBhbnksXG4gICAgc2V0UGFyZW50bGVzczogYW55LFxuICAgIHNldFJlcXVlc3RTdWZmaXg6IGFueSxcbiAgICBhZGRFbGVtZW50VHJhbnNmb3JtZXI6IGFueSxcbiAgICBleHRlbmRDb2xsZWN0aW9uOiBhbnksXG4gICAgZXh0ZW5kTW9kZWw6IGFueSxcbiAgICBzZXRUcmFuc2Zvcm1Pbmx5U2VydmVyRWxlbWVudHM6IGFueSxcbiAgICBzZXRGdWxsUmVzcG9uc2U6IGFueSxcbiAgICAkZ2V0OiBhbnlcbiAgfTtcbiAgYWRkRWxlbWVudFRyYW5zZm9ybWVyOiBhbnk7XG4gIGV4dGVuZENvbGxlY3Rpb246IGFueTtcbiAgZXh0ZW5kTW9kZWw6IGFueTtcbiAgY29weTtcbiAgY29uZmlndXJhdGlvbjtcbiAgc2VydmljZTtcbiAgaWQ7XG4gIHJvdXRlO1xuICBwYXJlbnRSZXNvdXJjZTtcbiAgcmVzdGFuZ3VsYXJDb2xsZWN0aW9uO1xuICBjYW5ub25pY2FsSWQ7XG4gIGV0YWc7XG4gIHNlbGZMaW5rO1xuICBnZXQ7XG4gIGdldExpc3Q7XG4gIHB1dDtcbiAgcG9zdDtcbiAgcmVtb3ZlO1xuICBoZWFkO1xuICB0cmFjZTtcbiAgb3B0aW9ucztcbiAgcGF0Y2g7XG4gIGdldFJlc3Rhbmd1bGFyVXJsO1xuICBnZXRSZXF1ZXN0ZWRVcmw7XG4gIHB1dEVsZW1lbnQ7XG4gIGFkZFJlc3Rhbmd1bGFyTWV0aG9kO1xuICBnZXRQYXJlbnRMaXN0O1xuICBjbG9uZTtcbiAgaWRzO1xuICBodHRwQ29uZmlnO1xuICByZXFQYXJhbXM7XG4gIG9uZTtcbiAgYWxsO1xuICBzZXZlcmFsO1xuICBvbmVVcmw7XG4gIGFsbFVybDtcbiAgY3VzdG9tUFVUO1xuICBjdXN0b21QQVRDSDtcbiAgY3VzdG9tUE9TVDtcbiAgY3VzdG9tREVMRVRFO1xuICBjdXN0b21HRVQ7XG4gIGN1c3RvbUdFVExJU1Q7XG4gIGN1c3RvbU9wZXJhdGlvbjtcbiAgZG9QVVQ7XG4gIGRvUEFUQ0g7XG4gIGRvUE9TVDtcbiAgZG9ERUxFVEU7XG4gIGRvR0VUO1xuICBkb0dFVExJU1Q7XG4gIGZyb21TZXJ2ZXI7XG4gIHdpdGhDb25maWc7XG4gIHdpdGhIdHRwQ29uZmlnO1xuICBzaW5nbGVPbmU7XG4gIHBsYWluO1xuICBzYXZlO1xuICByZXN0YW5ndWxhcml6ZWQ7XG4gIHJlc3Rhbmd1bGFyaXplRWxlbWVudDtcbiAgcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIEBPcHRpb25hbCgpIEBJbmplY3QoUkVTVEFOR1VMQVIpIHB1YmxpYyBjb25maWdPYmosXG4gICAgcHJpdmF0ZSBpbmplY3RvcjogSW5qZWN0b3IsXG4gICAgcHJpdmF0ZSBodHRwOiBSZXN0YW5ndWxhckh0dHBcbiAgKSB7XG4gICAgdGhpcy5wcm92aWRlciA9IG5ldyBwcm92aWRlckNvbmZpZyhodHRwKTtcbiAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5wcm92aWRlci4kZ2V0KCk7XG4gICAgYXNzaWduKHRoaXMsIGVsZW1lbnQpO1xuXG4gICAgdGhpcy5zZXREZWZhdWx0Q29uZmlnKCk7XG4gIH1cblxuICBzZXREZWZhdWx0Q29uZmlnKCkge1xuICAgIGlmICghdGhpcy5jb25maWdPYmogfHwgIWlzRnVuY3Rpb24odGhpcy5jb25maWdPYmouZm4pKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgYXJyREkgPSBtYXAodGhpcy5jb25maWdPYmouYXJyU2VydmljZXMsIChzZXJ2aWNlczogVHlwZTxhbnk+KSA9PiB7XG4gICAgICByZXR1cm4gdGhpcy5pbmplY3Rvci5nZXQoc2VydmljZXMpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5jb25maWdPYmouZm4oLi4uW3RoaXMucHJvdmlkZXIsIC4uLmFyckRJXSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcHJvdmlkZXJDb25maWcoJGh0dHApIHtcbiAgY29uc3QgZ2xvYmFsQ29uZmlndXJhdGlvbiA9IHt9O1xuXG4gIFJlc3Rhbmd1bGFyQ29uZmlndXJlcih0aGlzLCBnbG9iYWxDb25maWd1cmF0aW9uKTtcblxuICB0aGlzLiRnZXQgPSAkZ2V0O1xuXG4gIGZ1bmN0aW9uICRnZXQoKSB7XG5cbiAgICBmdW5jdGlvbiBjcmVhdGVTZXJ2aWNlRm9yQ29uZmlndXJhdGlvbihjb25maWcpIHtcbiAgICAgIGNvbnN0IHNlcnZpY2U6IGFueSA9IHt9O1xuXG4gICAgICBjb25zdCB1cmxIYW5kbGVyID0gbmV3IGNvbmZpZy51cmxDcmVhdG9yRmFjdG9yeVtjb25maWcudXJsQ3JlYXRvcl0oKTtcbiAgICAgIHVybEhhbmRsZXIuc2V0Q29uZmlnKGNvbmZpZyk7XG5cbiAgICAgIGZ1bmN0aW9uIHJlc3Rhbmd1bGFyaXplQmFzZShwYXJlbnQsIGVsZW0sIHJvdXRlLCByZXFQYXJhbXMsIGZyb21TZXJ2ZXIpIHtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdID0gcm91dGU7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmdldFJlc3Rhbmd1bGFyVXJsXSA9IGJpbmQodXJsSGFuZGxlci5mZXRjaFVybCwgdXJsSGFuZGxlciwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmdldFJlcXVlc3RlZFVybF0gPSBiaW5kKHVybEhhbmRsZXIuZmV0Y2hSZXF1ZXN0ZWRVcmwsIHVybEhhbmRsZXIsIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5hZGRSZXN0YW5ndWxhck1ldGhvZF0gPSBiaW5kKGFkZFJlc3Rhbmd1bGFyTWV0aG9kRnVuY3Rpb24sIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5jbG9uZV0gPSBiaW5kKGNvcHlSZXN0YW5ndWxhcml6ZWRFbGVtZW50LCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVxUGFyYW1zXSA9IGlzRW1wdHkocmVxUGFyYW1zKSA/IG51bGwgOiByZXFQYXJhbXM7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLndpdGhIdHRwQ29uZmlnXSA9IGJpbmQod2l0aEh0dHBDb25maWcsIGVsZW0pO1xuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wbGFpbl0gPSBiaW5kKHN0cmlwUmVzdGFuZ3VsYXIsIGVsZW0sIGVsZW0pO1xuXG4gICAgICAgIC8vIFRhZyBlbGVtZW50IGFzIHJlc3Rhbmd1bGFyaXplZFxuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhcml6ZWRdID0gdHJ1ZTtcblxuICAgICAgICAvLyBSZXF1ZXN0TGVzcyBjb25uZWN0aW9uXG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLm9uZV0gPSBiaW5kKG9uZSwgZWxlbSwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmFsbF0gPSBiaW5kKGFsbCwgZWxlbSwgZWxlbSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnNldmVyYWxdID0gYmluZChzZXZlcmFsLCBlbGVtLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMub25lVXJsXSA9IGJpbmQob25lVXJsLCBlbGVtLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuYWxsVXJsXSA9IGJpbmQoYWxsVXJsLCBlbGVtLCBlbGVtKTtcblxuICAgICAgICBlbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5mcm9tU2VydmVyXSA9ICEhZnJvbVNlcnZlcjtcblxuICAgICAgICBpZiAocGFyZW50ICYmIGNvbmZpZy5zaG91bGRTYXZlUGFyZW50KHJvdXRlKSkge1xuICAgICAgICAgIGNvbnN0IHBhcmVudElkID0gY29uZmlnLmdldElkRnJvbUVsZW0ocGFyZW50KTtcbiAgICAgICAgICBjb25zdCBwYXJlbnRVcmwgPSBjb25maWcuZ2V0VXJsRnJvbUVsZW0ocGFyZW50KTtcblxuICAgICAgICAgIGNvbnN0IHJlc3Rhbmd1bGFyRmllbGRzRm9yUGFyZW50ID0gdW5pb24oXG4gICAgICAgICAgICB2YWx1ZXMocGljayhjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMsIFsncm91dGUnLCAnc2luZ2xlT25lJywgJ3BhcmVudFJlc291cmNlJ10pKSxcbiAgICAgICAgICAgIGNvbmZpZy5leHRyYUZpZWxkc1xuICAgICAgICAgICk7XG4gICAgICAgICAgY29uc3QgcGFyZW50UmVzb3VyY2UgPSBwaWNrKHBhcmVudCwgcmVzdGFuZ3VsYXJGaWVsZHNGb3JQYXJlbnQpO1xuXG4gICAgICAgICAgaWYgKGNvbmZpZy5pc1ZhbGlkSWQocGFyZW50SWQpKSB7XG4gICAgICAgICAgICBjb25maWcuc2V0SWRUb0VsZW0ocGFyZW50UmVzb3VyY2UsIHBhcmVudElkLCByb3V0ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjb25maWcuaXNWYWxpZElkKHBhcmVudFVybCkpIHtcbiAgICAgICAgICAgIGNvbmZpZy5zZXRVcmxUb0VsZW0ocGFyZW50UmVzb3VyY2UsIHBhcmVudFVybCwgcm91dGUpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhcmVudFJlc291cmNlXSA9IHBhcmVudFJlc291cmNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhcmVudFJlc291cmNlXSA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGVsZW07XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIG9uZShwYXJlbnQsIHJvdXRlLCBpZCwgc2luZ2xlT25lKSB7XG4gICAgICAgIGxldCBlcnJvcjtcbiAgICAgICAgaWYgKGlzTnVtYmVyKHJvdXRlKSB8fCBpc051bWJlcihwYXJlbnQpKSB7XG4gICAgICAgICAgZXJyb3IgPSAnWW91XFwncmUgY3JlYXRpbmcgYSBSZXN0YW5ndWxhciBlbnRpdHkgd2l0aCB0aGUgbnVtYmVyICc7XG4gICAgICAgICAgZXJyb3IgKz0gJ2luc3RlYWQgb2YgdGhlIHJvdXRlIG9yIHRoZSBwYXJlbnQuIEZvciBleGFtcGxlLCB5b3UgY2FuXFwndCBjYWxsIC5vbmUoMTIpLic7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNVbmRlZmluZWQocm91dGUpKSB7XG4gICAgICAgICAgZXJyb3IgPSAnWW91XFwncmUgY3JlYXRpbmcgYSBSZXN0YW5ndWxhciBlbnRpdHkgZWl0aGVyIHdpdGhvdXQgdGhlIHBhdGguICc7XG4gICAgICAgICAgZXJyb3IgKz0gJ0ZvciBleGFtcGxlIHlvdSBjYW5cXCd0IGNhbGwgLm9uZSgpLiBQbGVhc2UgY2hlY2sgaWYgeW91ciBhcmd1bWVudHMgYXJlIHZhbGlkLic7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBlbGVtID0ge307XG4gICAgICAgIGNvbmZpZy5zZXRJZFRvRWxlbShlbGVtLCBpZCwgcm91dGUpO1xuICAgICAgICBjb25maWcuc2V0RmllbGRUb0VsZW0oY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnNpbmdsZU9uZSwgZWxlbSwgc2luZ2xlT25lKTtcbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplRWxlbShwYXJlbnQsIGVsZW0sIHJvdXRlLCBmYWxzZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGFsbChwYXJlbnQsIHJvdXRlKSB7XG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24ocGFyZW50LCBbXSwgcm91dGUsIGZhbHNlKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gc2V2ZXJhbChwYXJlbnQsIHJvdXRlIC8qLCBpZHMgKi8pIHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IFtdO1xuICAgICAgICBjb2xsZWN0aW9uW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5pZHNdID0gQXJyYXkucHJvdG90eXBlLnNwbGljZS5jYWxsKGFyZ3VtZW50cywgMik7XG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24ocGFyZW50LCBjb2xsZWN0aW9uLCByb3V0ZSwgZmFsc2UpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBvbmVVcmwocGFyZW50LCByb3V0ZSwgdXJsKSB7XG4gICAgICAgIGlmICghcm91dGUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JvdXRlIGlzIG1hbmRhdG9yeSB3aGVuIGNyZWF0aW5nIG5ldyBSZXN0YW5ndWxhciBvYmplY3RzLicpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGVsZW0gPSB7fTtcbiAgICAgICAgY29uZmlnLnNldFVybFRvRWxlbShlbGVtLCB1cmwsIHJvdXRlKTtcbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplRWxlbShwYXJlbnQsIGVsZW0sIHJvdXRlLCBmYWxzZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGFsbFVybChwYXJlbnQsIHJvdXRlLCB1cmwpIHtcbiAgICAgICAgaWYgKCFyb3V0ZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignUm91dGUgaXMgbWFuZGF0b3J5IHdoZW4gY3JlYXRpbmcgbmV3IFJlc3Rhbmd1bGFyIG9iamVjdHMuJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZWxlbSA9IHt9O1xuICAgICAgICBjb25maWcuc2V0VXJsVG9FbGVtKGVsZW0sIHVybCwgcm91dGUpO1xuICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVDb2xsZWN0aW9uKHBhcmVudCwgZWxlbSwgcm91dGUsIGZhbHNlKTtcbiAgICAgIH1cblxuICAgICAgLy8gUHJvbWlzZXNcbiAgICAgIGZ1bmN0aW9uIHJlc3Rhbmd1bGFyaXplUmVzcG9uc2Uoc3ViamVjdCwgaXNDb2xsZWN0aW9uLCB2YWx1ZVRvRmlsbCkge1xuICAgICAgICByZXR1cm4gc3ViamVjdC5waXBlKGZpbHRlcihyZXMgPT4gISFyZXMpKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcmVzb2x2ZVByb21pc2Uoc3ViamVjdCwgcmVzcG9uc2UsIGRhdGEsIGZpbGxlZFZhbHVlKSB7XG4gICAgICAgIGV4dGVuZChmaWxsZWRWYWx1ZSwgZGF0YSk7XG5cbiAgICAgICAgLy8gVHJpZ2dlciB0aGUgZnVsbCByZXNwb25zZSBpbnRlcmNlcHRvci5cbiAgICAgICAgaWYgKGNvbmZpZy5mdWxsUmVzcG9uc2UpIHtcbiAgICAgICAgICBzdWJqZWN0Lm5leHQoZXh0ZW5kKHJlc3BvbnNlLCB7XG4gICAgICAgICAgICBkYXRhOiBkYXRhXG4gICAgICAgICAgfSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN1YmplY3QubmV4dChkYXRhKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHN1YmplY3QuY29tcGxldGUoKTtcbiAgICAgIH1cblxuICAgICAgLy8gRWxlbWVudHNcbiAgICAgIGZ1bmN0aW9uIHN0cmlwUmVzdGFuZ3VsYXIoZWxlbSkge1xuICAgICAgICBpZiAoaXNBcnJheShlbGVtKSkge1xuICAgICAgICAgIGNvbnN0IGFycmF5ID0gW107XG4gICAgICAgICAgZWFjaChlbGVtLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGFycmF5LnB1c2goY29uZmlnLmlzUmVzdGFuZ3VsYXJpemVkKHZhbHVlKSA/IHN0cmlwUmVzdGFuZ3VsYXIodmFsdWUpIDogdmFsdWUpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBhcnJheTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gb21pdChlbGVtLCB2YWx1ZXMob21pdChjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMsICdpZCcpKSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gYWRkQ3VzdG9tT3BlcmF0aW9uKGVsZW0pIHtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuY3VzdG9tT3BlcmF0aW9uXSA9IGJpbmQoY3VzdG9tRnVuY3Rpb24sIGVsZW0pO1xuICAgICAgICBjb25zdCByZXF1ZXN0TWV0aG9kcyA9IHtnZXQ6IGN1c3RvbUZ1bmN0aW9uLCBkZWxldGU6IGN1c3RvbUZ1bmN0aW9ufTtcbiAgICAgICAgZWFjaChbJ3B1dCcsICdwYXRjaCcsICdwb3N0J10sIGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgICAgICAgcmVxdWVzdE1ldGhvZHNbbmFtZV0gPSBmdW5jdGlvbiAob3BlcmF0aW9uLCBlbGVtZW50LCBwYXRoLCBwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgICAgIHJldHVybiBiaW5kKGN1c3RvbUZ1bmN0aW9uLCB0aGlzKShvcGVyYXRpb24sIHBhdGgsIHBhcmFtcywgaGVhZGVycywgZWxlbWVudCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICAgIGVhY2gocmVxdWVzdE1ldGhvZHMsIGZ1bmN0aW9uIChyZXF1ZXN0RnVuYywgbmFtZSkge1xuICAgICAgICAgIGNvbnN0IGNhbGxPcGVyYXRpb24gPSBuYW1lID09PSAnZGVsZXRlJyA/ICdyZW1vdmUnIDogbmFtZTtcbiAgICAgICAgICBlYWNoKFsnZG8nLCAnY3VzdG9tJ10sIGZ1bmN0aW9uIChhbGlhcykge1xuICAgICAgICAgICAgZWxlbVthbGlhcyArIG5hbWUudG9VcHBlckNhc2UoKV0gPSBiaW5kKHJlcXVlc3RGdW5jLCBlbGVtLCBjYWxsT3BlcmF0aW9uKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICAgIGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmN1c3RvbUdFVExJU1RdID0gYmluZChmZXRjaEZ1bmN0aW9uLCBlbGVtKTtcbiAgICAgICAgZWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZG9HRVRMSVNUXSA9IGVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmN1c3RvbUdFVExJU1RdO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBjb3B5UmVzdGFuZ3VsYXJpemVkRWxlbWVudChmcm9tRWxlbWVudCwgdG9FbGVtZW50ID0ge30pIHtcbiAgICAgICAgY29uc3QgY29waWVkRWxlbWVudCA9IGFzc2lnbih0b0VsZW1lbnQsIGZyb21FbGVtZW50KTtcbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplRWxlbShjb3BpZWRFbGVtZW50W2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV0sXG4gICAgICAgICAgY29waWVkRWxlbWVudCwgY29waWVkRWxlbWVudFtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdLCB0cnVlKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcmVzdGFuZ3VsYXJpemVFbGVtKHBhcmVudCwgZWxlbWVudCwgcm91dGUsIGZyb21TZXJ2ZXI/LCBjb2xsZWN0aW9uPywgcmVxUGFyYW1zPykge1xuICAgICAgICBjb25zdCBlbGVtID0gY29uZmlnLm9uQmVmb3JlRWxlbVJlc3Rhbmd1bGFyaXplZChlbGVtZW50LCBmYWxzZSwgcm91dGUpO1xuXG4gICAgICAgIGNvbnN0IGxvY2FsRWxlbSA9IHJlc3Rhbmd1bGFyaXplQmFzZShwYXJlbnQsIGVsZW0sIHJvdXRlLCByZXFQYXJhbXMsIGZyb21TZXJ2ZXIpO1xuXG4gICAgICAgIGlmIChjb25maWcudXNlQ2Fubm9uaWNhbElkKSB7XG4gICAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5jYW5ub25pY2FsSWRdID0gY29uZmlnLmdldElkRnJvbUVsZW0obG9jYWxFbGVtKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb2xsZWN0aW9uKSB7XG4gICAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRQYXJlbnRMaXN0XSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBjb2xsZWN0aW9uO1xuICAgICAgICAgIH07XG4gICAgICAgIH1cblxuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlc3Rhbmd1bGFyQ29sbGVjdGlvbl0gPSBmYWxzZTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRdID0gYmluZChnZXRGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRMaXN0XSA9IGJpbmQoZmV0Y2hGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wdXRdID0gYmluZChwdXRGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wb3N0XSA9IGJpbmQocG9zdEZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlbW92ZV0gPSBiaW5kKGRlbGV0ZUZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmhlYWRdID0gYmluZChoZWFkRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMudHJhY2VdID0gYmluZCh0cmFjZUZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLm9wdGlvbnNdID0gYmluZChvcHRpb25zRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGF0Y2hdID0gYmluZChwYXRjaEZ1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnNhdmVdID0gYmluZChzYXZlLCBsb2NhbEVsZW0pO1xuXG4gICAgICAgIGFkZEN1c3RvbU9wZXJhdGlvbihsb2NhbEVsZW0pO1xuICAgICAgICByZXR1cm4gY29uZmlnLnRyYW5zZm9ybUVsZW0obG9jYWxFbGVtLCBmYWxzZSwgcm91dGUsIHNlcnZpY2UsIHRydWUpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24ocGFyZW50LCBlbGVtZW50LCByb3V0ZSwgZnJvbVNlcnZlcj8sIHJlcVBhcmFtcz8pIHtcbiAgICAgICAgY29uc3QgZWxlbSA9IGNvbmZpZy5vbkJlZm9yZUVsZW1SZXN0YW5ndWxhcml6ZWQoZWxlbWVudCwgdHJ1ZSwgcm91dGUpO1xuXG4gICAgICAgIGNvbnN0IGxvY2FsRWxlbSA9IHJlc3Rhbmd1bGFyaXplQmFzZShwYXJlbnQsIGVsZW0sIHJvdXRlLCByZXFQYXJhbXMsIGZyb21TZXJ2ZXIpO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlc3Rhbmd1bGFyQ29sbGVjdGlvbl0gPSB0cnVlO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBvc3RdID0gYmluZChwb3N0RnVuY3Rpb24sIGxvY2FsRWxlbSwgbnVsbCk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVtb3ZlXSA9IGJpbmQoZGVsZXRlRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaGVhZF0gPSBiaW5kKGhlYWRGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy50cmFjZV0gPSBiaW5kKHRyYWNlRnVuY3Rpb24sIGxvY2FsRWxlbSk7XG4gICAgICAgIGxvY2FsRWxlbVtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucHV0RWxlbWVudF0gPSBiaW5kKHB1dEVsZW1lbnRGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5vcHRpb25zXSA9IGJpbmQob3B0aW9uc0Z1bmN0aW9uLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnBhdGNoXSA9IGJpbmQocGF0Y2hGdW5jdGlvbiwgbG9jYWxFbGVtKTtcbiAgICAgICAgbG9jYWxFbGVtW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5nZXRdID0gYmluZChnZXRCeUlkLCBsb2NhbEVsZW0pO1xuICAgICAgICBsb2NhbEVsZW1bY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLmdldExpc3RdID0gYmluZChmZXRjaEZ1bmN0aW9uLCBsb2NhbEVsZW0sIG51bGwpO1xuXG4gICAgICAgIGFkZEN1c3RvbU9wZXJhdGlvbihsb2NhbEVsZW0pO1xuICAgICAgICByZXR1cm4gY29uZmlnLnRyYW5zZm9ybUVsZW0obG9jYWxFbGVtLCB0cnVlLCByb3V0ZSwgc2VydmljZSwgdHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbkFuZEVsZW1lbnRzKHBhcmVudCwgZWxlbWVudCwgcm91dGUpIHtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbihwYXJlbnQsIGVsZW1lbnQsIHJvdXRlLCBmYWxzZSk7XG4gICAgICAgIGVhY2goY29sbGVjdGlvbiwgZnVuY3Rpb24gKGVsZW0pIHtcbiAgICAgICAgICBpZiAoZWxlbSkge1xuICAgICAgICAgICAgcmVzdGFuZ3VsYXJpemVFbGVtKHBhcmVudCwgZWxlbSwgcm91dGUsIGZhbHNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gY29sbGVjdGlvbjtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gZ2V0QnlJZChpZCwgcmVxUGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmN1c3RvbUdFVChpZC50b1N0cmluZygpLCByZXFQYXJhbXMsIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBwdXRFbGVtZW50RnVuY3Rpb24oaWR4LCBwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgY29uc3QgX190aGlzID0gdGhpcztcbiAgICAgICAgY29uc3QgZWxlbVRvUHV0ID0gdGhpc1tpZHhdO1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdChudWxsKTtcbiAgICAgICAgbGV0IGZpbGxlZEFycmF5ID0gW107XG4gICAgICAgIGZpbGxlZEFycmF5ID0gY29uZmlnLnRyYW5zZm9ybUVsZW0oZmlsbGVkQXJyYXksIHRydWUsIGVsZW1Ub1B1dFtjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdLCBzZXJ2aWNlKTtcblxuICAgICAgICBlbGVtVG9QdXQucHV0KHBhcmFtcywgaGVhZGVycylcbiAgICAgICAgLnN1YnNjcmliZShmdW5jdGlvbiAoc2VydmVyRWxlbSkge1xuICAgICAgICAgIGNvbnN0IG5ld0FycmF5ID0gY29weVJlc3Rhbmd1bGFyaXplZEVsZW1lbnQoX190aGlzKTtcbiAgICAgICAgICBuZXdBcnJheVtpZHhdID0gc2VydmVyRWxlbTtcbiAgICAgICAgICBmaWxsZWRBcnJheSA9IG5ld0FycmF5O1xuICAgICAgICAgIHN1YmplY3QubmV4dChuZXdBcnJheSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgIHN1YmplY3QuZXJyb3IocmVzcG9uc2UpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgc3ViamVjdC5jb21wbGV0ZSgpO1xuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzdGFuZ3VsYXJpemVSZXNwb25zZShzdWJqZWN0LCB0cnVlLCBmaWxsZWRBcnJheSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHBhcnNlUmVzcG9uc2UocmVzRGF0YSwgb3BlcmF0aW9uLCByb3V0ZSwgZmV0Y2hVcmwsIHJlc3BvbnNlLCBzdWJqZWN0KSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBjb25maWcucmVzcG9uc2VFeHRyYWN0b3IocmVzRGF0YSwgb3BlcmF0aW9uLCByb3V0ZSwgZmV0Y2hVcmwsIHJlc3BvbnNlLCBzdWJqZWN0KTtcbiAgICAgICAgY29uc3QgZXRhZyA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdFVGFnJyk7XG4gICAgICAgIGlmIChkYXRhICYmIGV0YWcpIHtcbiAgICAgICAgICBkYXRhW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5ldGFnXSA9IGV0YWc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGZldGNoRnVuY3Rpb24od2hhdCwgcmVxUGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIGNvbnN0IF9fdGhpcyA9IHRoaXM7XG4gICAgICAgIGNvbnN0IHN1YmplY3QgPSBuZXcgQmVoYXZpb3JTdWJqZWN0KG51bGwpO1xuICAgICAgICBjb25zdCBvcGVyYXRpb24gPSAnZ2V0TGlzdCc7XG4gICAgICAgIGNvbnN0IHVybCA9IHVybEhhbmRsZXIuZmV0Y2hVcmwodGhpcywgd2hhdCk7XG4gICAgICAgIGNvbnN0IHdoYXRGZXRjaGVkID0gd2hhdCB8fCBfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXTtcblxuICAgICAgICBjb25zdCByZXF1ZXN0ID0gY29uZmlnLmZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3IobnVsbCwgb3BlcmF0aW9uLFxuICAgICAgICAgIHdoYXRGZXRjaGVkLCB1cmwsIGhlYWRlcnMgfHwge30sIHJlcVBhcmFtcyB8fCB7fSwgdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaHR0cENvbmZpZ10gfHwge30pO1xuXG4gICAgICAgIGxldCBmaWxsZWRBcnJheSA9IFtdO1xuICAgICAgICBmaWxsZWRBcnJheSA9IGNvbmZpZy50cmFuc2Zvcm1FbGVtKGZpbGxlZEFycmF5LCB0cnVlLCB3aGF0RmV0Y2hlZCwgc2VydmljZSk7XG5cbiAgICAgICAgbGV0IG1ldGhvZCA9ICdnZXRMaXN0JztcblxuICAgICAgICBpZiAoY29uZmlnLmpzb25wKSB7XG4gICAgICAgICAgbWV0aG9kID0gJ2pzb25wJztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG9rQ2FsbGJhY2sgPSBmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICBjb25zdCByZXNEYXRhID0gcmVzcG9uc2UuYm9keTtcbiAgICAgICAgICBjb25zdCBmdWxsUGFyYW1zID0gcmVzcG9uc2UuY29uZmlnLnBhcmFtcztcbiAgICAgICAgICBsZXQgZGF0YSA9IHBhcnNlUmVzcG9uc2UocmVzRGF0YSwgb3BlcmF0aW9uLCB3aGF0RmV0Y2hlZCwgdXJsLCByZXNwb25zZSwgc3ViamVjdCk7XG5cbiAgICAgICAgICAvLyBzdXBwb3J0IGVtcHR5IHJlc3BvbnNlIGZvciBnZXRMaXN0KCkgY2FsbHMgKHNvbWUgQVBJcyByZXNwb25kIHdpdGggMjA0IGFuZCBlbXB0eSBib2R5KVxuICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChkYXRhKSB8fCAnJyA9PT0gZGF0YSkge1xuICAgICAgICAgICAgZGF0YSA9IFtdO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIWlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignUmVzcG9uc2UgZm9yIGdldExpc3QgU0hPVUxEIGJlIGFuIGFycmF5IGFuZCBub3QgYW4gb2JqZWN0IG9yIHNvbWV0aGluZyBlbHNlJyk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHRydWUgPT09IGNvbmZpZy5wbGFpbkJ5RGVmYXVsdCkge1xuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBkYXRhLCBmaWxsZWRBcnJheSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IHByb2Nlc3NlZERhdGEgPSBtYXAoZGF0YSwgZnVuY3Rpb24gKGVsZW0pIHtcbiAgICAgICAgICAgIGlmICghX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUVsZW0oX190aGlzLCBlbGVtLCB3aGF0LCB0cnVlLCBkYXRhKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZUVsZW0oX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV0sXG4gICAgICAgICAgICAgICAgZWxlbSwgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yb3V0ZV0sIHRydWUsIGRhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgcHJvY2Vzc2VkRGF0YSA9IGV4dGVuZChkYXRhLCBwcm9jZXNzZWREYXRhKTtcblxuICAgICAgICAgIGlmICghX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yZXN0YW5ndWxhckNvbGxlY3Rpb25dKSB7XG4gICAgICAgICAgICByZXNvbHZlUHJvbWlzZShcbiAgICAgICAgICAgICAgc3ViamVjdCxcbiAgICAgICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgICAgIHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbihcbiAgICAgICAgICAgICAgICBfX3RoaXMsXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YSxcbiAgICAgICAgICAgICAgICB3aGF0LFxuICAgICAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICAgICAgZnVsbFBhcmFtc1xuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICBmaWxsZWRBcnJheVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZVByb21pc2UoXG4gICAgICAgICAgICAgIHN1YmplY3QsXG4gICAgICAgICAgICAgIHJlc3BvbnNlLFxuICAgICAgICAgICAgICByZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24oXG4gICAgICAgICAgICAgICAgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5wYXJlbnRSZXNvdXJjZV0sXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YSxcbiAgICAgICAgICAgICAgICBfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJvdXRlXSxcbiAgICAgICAgICAgICAgICB0cnVlLFxuICAgICAgICAgICAgICAgIGZ1bGxQYXJhbXNcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgZmlsbGVkQXJyYXlcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHVybEhhbmRsZXIucmVzb3VyY2UodGhpcywgJGh0dHAsIHJlcXVlc3QuaHR0cENvbmZpZywgcmVxdWVzdC5oZWFkZXJzLCByZXF1ZXN0LnBhcmFtcywgd2hhdCxcbiAgICAgICAgICB0aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5ldGFnXSwgb3BlcmF0aW9uKVttZXRob2RdKClcbiAgICAgICAgLnN1YnNjcmliZShva0NhbGxiYWNrLCBmdW5jdGlvbiBlcnJvcihyZXNwb25zZSkge1xuICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDMwNCAmJiBfX3RoaXNbY29uZmlnLnJlc3Rhbmd1bGFyRmllbGRzLnJlc3Rhbmd1bGFyQ29sbGVjdGlvbl0pIHtcbiAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBfX3RoaXMsIGZpbGxlZEFycmF5KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGV2ZXJ5KGNvbmZpZy5lcnJvckludGVyY2VwdG9ycywgZnVuY3Rpb24gKGNiOiBhbnkpIHtcblxuICAgICAgICAgICAgcmV0dXJuIGNiKHJlc3BvbnNlLCBzdWJqZWN0LCBva0NhbGxiYWNrKSAhPT0gZmFsc2U7XG4gICAgICAgICAgfSkpIHtcbiAgICAgICAgICAgIC8vIHRyaWdnZXJlZCBpZiBubyBjYWxsYmFjayByZXR1cm5zIGZhbHNlXG4gICAgICAgICAgICBzdWJqZWN0LmVycm9yKHJlc3BvbnNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXN0YW5ndWxhcml6ZVJlc3BvbnNlKHN1YmplY3QsIHRydWUsIGZpbGxlZEFycmF5KTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gd2l0aEh0dHBDb25maWcoaHR0cENvbmZpZykge1xuICAgICAgICB0aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5odHRwQ29uZmlnXSA9IGh0dHBDb25maWc7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBzYXZlKHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICBpZiAodGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuZnJvbVNlcnZlcl0pIHtcbiAgICAgICAgICByZXR1cm4gdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucHV0XShwYXJhbXMsIGhlYWRlcnMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ3Bvc3QnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBlbGVtRnVuY3Rpb24ob3BlcmF0aW9uLCB3aGF0LCBwYXJhbXMsIG9iaiwgaGVhZGVycykge1xuICAgICAgICBjb25zdCBfX3RoaXMgPSB0aGlzO1xuICAgICAgICBjb25zdCBzdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdChudWxsKTtcbiAgICAgICAgY29uc3QgcmVzUGFyYW1zID0gcGFyYW1zIHx8IHt9O1xuICAgICAgICBjb25zdCByb3V0ZSA9IHdoYXQgfHwgdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucm91dGVdO1xuICAgICAgICBjb25zdCBmZXRjaFVybCA9IHVybEhhbmRsZXIuZmV0Y2hVcmwodGhpcywgd2hhdCk7XG5cbiAgICAgICAgbGV0IGNhbGxPYmogPSBvYmogfHwgdGhpcztcbiAgICAgICAgLy8gZmFsbGJhY2sgdG8gZXRhZyBvbiByZXN0YW5ndWxhciBvYmplY3QgKHNpbmNlIGZvciBjdXN0b20gbWV0aG9kcyB3ZSBwcm9iYWJseSBkb24ndCBleHBsaWNpdGx5IHNwZWNpZnkgdGhlIGV0YWcgZmllbGQpXG4gICAgICAgIGNvbnN0IGV0YWcgPSBjYWxsT2JqW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5ldGFnXSB8fCAob3BlcmF0aW9uICE9PSAncG9zdCcgPyB0aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5ldGFnXSA6IG51bGwpO1xuXG4gICAgICAgIGlmIChpc09iamVjdChjYWxsT2JqKSAmJiBjb25maWcuaXNSZXN0YW5ndWxhcml6ZWQoY2FsbE9iaikpIHtcbiAgICAgICAgICBjYWxsT2JqID0gc3RyaXBSZXN0YW5ndWxhcihjYWxsT2JqKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXF1ZXN0ID0gY29uZmlnLmZ1bGxSZXF1ZXN0SW50ZXJjZXB0b3IoXG4gICAgICAgICAgY2FsbE9iaixcbiAgICAgICAgICBvcGVyYXRpb24sXG4gICAgICAgICAgcm91dGUsXG4gICAgICAgICAgZmV0Y2hVcmwsXG4gICAgICAgICAgaGVhZGVycyB8fCB7fSxcbiAgICAgICAgICByZXNQYXJhbXMgfHwge30sXG4gICAgICAgICAgdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMuaHR0cENvbmZpZ10gfHwge31cbiAgICAgICAgKTtcblxuICAgICAgICBsZXQgZmlsbGVkT2JqZWN0ID0ge307XG4gICAgICAgIGZpbGxlZE9iamVjdCA9IGNvbmZpZy50cmFuc2Zvcm1FbGVtKGZpbGxlZE9iamVjdCwgZmFsc2UsIHJvdXRlLCBzZXJ2aWNlKTtcblxuICAgICAgICBjb25zdCBva0NhbGxiYWNrID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgY29uc3QgcmVzRGF0YSA9IGdldChyZXNwb25zZSwgJ2JvZHknKTtcbiAgICAgICAgICBjb25zdCBmdWxsUGFyYW1zID0gZ2V0KHJlc3BvbnNlLCAnY29uZmlnLnBhcmFtcycpO1xuXG4gICAgICAgICAgY29uc3QgZWxlbSA9IHBhcnNlUmVzcG9uc2UocmVzRGF0YSwgb3BlcmF0aW9uLCByb3V0ZSwgZmV0Y2hVcmwsIHJlc3BvbnNlLCBzdWJqZWN0KTtcblxuICAgICAgICAgIGlmIChlbGVtKSB7XG4gICAgICAgICAgICBsZXQgZGF0YTtcbiAgICAgICAgICAgIGlmICh0cnVlID09PSBjb25maWcucGxhaW5CeURlZmF1bHQpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVQcm9taXNlKHN1YmplY3QsIHJlc3BvbnNlLCBlbGVtLCBmaWxsZWRPYmplY3QpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAob3BlcmF0aW9uID09PSAncG9zdCcgJiYgIV9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucmVzdGFuZ3VsYXJDb2xsZWN0aW9uXSkge1xuICAgICAgICAgICAgICBkYXRhID0gcmVzdGFuZ3VsYXJpemVFbGVtKFxuICAgICAgICAgICAgICAgIF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdLFxuICAgICAgICAgICAgICAgIGVsZW0sXG4gICAgICAgICAgICAgICAgcm91dGUsXG4gICAgICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICAgIGZ1bGxQYXJhbXNcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgcmVzb2x2ZVByb21pc2Uoc3ViamVjdCwgcmVzcG9uc2UsIGRhdGEsIGZpbGxlZE9iamVjdCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBkYXRhID0gcmVzdGFuZ3VsYXJpemVFbGVtKFxuICAgICAgICAgICAgICAgIF9fdGhpc1tjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMucGFyZW50UmVzb3VyY2VdLFxuICAgICAgICAgICAgICAgIGVsZW0sXG4gICAgICAgICAgICAgICAgX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5yb3V0ZV0sXG4gICAgICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICAgIGZ1bGxQYXJhbXNcbiAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICBkYXRhW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5zaW5nbGVPbmVdID0gX190aGlzW2NvbmZpZy5yZXN0YW5ndWxhckZpZWxkcy5zaW5nbGVPbmVdO1xuICAgICAgICAgICAgICByZXNvbHZlUHJvbWlzZShzdWJqZWN0LCByZXNwb25zZSwgZGF0YSwgZmlsbGVkT2JqZWN0KTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlUHJvbWlzZShzdWJqZWN0LCByZXNwb25zZSwgdW5kZWZpbmVkLCBmaWxsZWRPYmplY3QpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCBlcnJvckNhbGxiYWNrID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMzA0ICYmIGNvbmZpZy5pc1NhZmUob3BlcmF0aW9uKSkge1xuICAgICAgICAgICAgcmVzb2x2ZVByb21pc2Uoc3ViamVjdCwgcmVzcG9uc2UsIF9fdGhpcywgZmlsbGVkT2JqZWN0KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGV2ZXJ5KGNvbmZpZy5lcnJvckludGVyY2VwdG9ycywgZnVuY3Rpb24gKGNiOiBhbnkpIHtcbiAgICAgICAgICAgIHJldHVybiBjYihyZXNwb25zZSwgc3ViamVjdCwgb2tDYWxsYmFjaykgIT09IGZhbHNlO1xuICAgICAgICAgIH0pKSB7XG4gICAgICAgICAgICAvLyB0cmlnZ2VyZWQgaWYgbm8gY2FsbGJhY2sgcmV0dXJucyBmYWxzZVxuICAgICAgICAgICAgc3ViamVjdC5lcnJvcihyZXNwb25zZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICAvLyBPdmVycmlkaW5nIEhUVFAgTWV0aG9kXG4gICAgICAgIGxldCBjYWxsT3BlcmF0aW9uID0gb3BlcmF0aW9uO1xuICAgICAgICBsZXQgY2FsbEhlYWRlcnMgPSBleHRlbmQoe30sIHJlcXVlc3QuaGVhZGVycyk7XG4gICAgICAgIGNvbnN0IGlzT3ZlcnJpZGVPcGVyYXRpb24gPSBjb25maWcuaXNPdmVycmlkZW5NZXRob2Qob3BlcmF0aW9uKTtcbiAgICAgICAgaWYgKGlzT3ZlcnJpZGVPcGVyYXRpb24pIHtcbiAgICAgICAgICBjYWxsT3BlcmF0aW9uID0gJ3Bvc3QnO1xuICAgICAgICAgIGNhbGxIZWFkZXJzID0gZXh0ZW5kKGNhbGxIZWFkZXJzLCB7J1gtSFRUUC1NZXRob2QtT3ZlcnJpZGUnOiBvcGVyYXRpb24gPT09ICdyZW1vdmUnID8gJ0RFTEVURScgOiBvcGVyYXRpb24udG9VcHBlckNhc2UoKX0pO1xuICAgICAgICB9IGVsc2UgaWYgKGNvbmZpZy5qc29ucCAmJiBjYWxsT3BlcmF0aW9uID09PSAnZ2V0Jykge1xuICAgICAgICAgIGNhbGxPcGVyYXRpb24gPSAnanNvbnAnO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvbmZpZy5pc1NhZmUob3BlcmF0aW9uKSkge1xuICAgICAgICAgIGlmIChpc092ZXJyaWRlT3BlcmF0aW9uKSB7XG4gICAgICAgICAgICB1cmxIYW5kbGVyLnJlc291cmNlKHRoaXMsICRodHRwLCByZXF1ZXN0Lmh0dHBDb25maWcsIGNhbGxIZWFkZXJzLCByZXF1ZXN0LnBhcmFtcyxcbiAgICAgICAgICAgICAgd2hhdCwgZXRhZywgY2FsbE9wZXJhdGlvbilbY2FsbE9wZXJhdGlvbl0oe30pLnN1YnNjcmliZShva0NhbGxiYWNrLCBlcnJvckNhbGxiYWNrKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdXJsSGFuZGxlci5yZXNvdXJjZSh0aGlzLCAkaHR0cCwgcmVxdWVzdC5odHRwQ29uZmlnLCBjYWxsSGVhZGVycywgcmVxdWVzdC5wYXJhbXMsXG4gICAgICAgICAgICAgIHdoYXQsIGV0YWcsIGNhbGxPcGVyYXRpb24pW2NhbGxPcGVyYXRpb25dKCkuc3Vic2NyaWJlKG9rQ2FsbGJhY2ssIGVycm9yQ2FsbGJhY2spO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB1cmxIYW5kbGVyLnJlc291cmNlKHRoaXMsICRodHRwLCByZXF1ZXN0Lmh0dHBDb25maWcsIGNhbGxIZWFkZXJzLCByZXF1ZXN0LnBhcmFtcyxcbiAgICAgICAgICAgIHdoYXQsIGV0YWcsIGNhbGxPcGVyYXRpb24pW2NhbGxPcGVyYXRpb25dKHJlcXVlc3QuZWxlbWVudCkuc3Vic2NyaWJlKG9rQ2FsbGJhY2ssIGVycm9yQ2FsbGJhY2spO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHJlc3Rhbmd1bGFyaXplUmVzcG9uc2Uoc3ViamVjdCwgZmFsc2UsIGZpbGxlZE9iamVjdCk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGdldEZ1bmN0aW9uKHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKCdnZXQnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gZGVsZXRlRnVuY3Rpb24ocGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ3JlbW92ZScsIHVuZGVmaW5lZCwgcGFyYW1zLCB1bmRlZmluZWQsIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBwdXRGdW5jdGlvbihwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgncHV0JywgdW5kZWZpbmVkLCBwYXJhbXMsIHVuZGVmaW5lZCwgaGVhZGVycyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIHBvc3RGdW5jdGlvbih3aGF0LCBlbGVtLCBwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgncG9zdCcsIHdoYXQsIHBhcmFtcywgZWxlbSwgaGVhZGVycyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGhlYWRGdW5jdGlvbihwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgnaGVhZCcsIHVuZGVmaW5lZCwgcGFyYW1zLCB1bmRlZmluZWQsIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiB0cmFjZUZ1bmN0aW9uKHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICByZXR1cm4gYmluZChlbGVtRnVuY3Rpb24sIHRoaXMpKCd0cmFjZScsIHVuZGVmaW5lZCwgcGFyYW1zLCB1bmRlZmluZWQsIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBvcHRpb25zRnVuY3Rpb24ocGFyYW1zLCBoZWFkZXJzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykoJ29wdGlvbnMnLCB1bmRlZmluZWQsIHBhcmFtcywgdW5kZWZpbmVkLCBoZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcGF0Y2hGdW5jdGlvbihlbGVtLCBwYXJhbXMsIGhlYWRlcnMpIHtcbiAgICAgICAgcmV0dXJuIGJpbmQoZWxlbUZ1bmN0aW9uLCB0aGlzKSgncGF0Y2gnLCB1bmRlZmluZWQsIHBhcmFtcywgZWxlbSwgaGVhZGVycyk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGN1c3RvbUZ1bmN0aW9uKG9wZXJhdGlvbiwgcGF0aCwgcGFyYW1zLCBoZWFkZXJzLCBlbGVtKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGVsZW1GdW5jdGlvbiwgdGhpcykob3BlcmF0aW9uLCBwYXRoLCBwYXJhbXMsIGVsZW0sIGhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBhZGRSZXN0YW5ndWxhck1ldGhvZEZ1bmN0aW9uKG5hbWUsIG9wZXJhdGlvbiwgcGF0aCwgZGVmYXVsdFBhcmFtcywgZGVmYXVsdEhlYWRlcnMsIGRlZmF1bHRFbGVtKSB7XG4gICAgICAgIGxldCBiaW5kZWRGdW5jdGlvbjtcbiAgICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ2dldExpc3QnKSB7XG4gICAgICAgICAgYmluZGVkRnVuY3Rpb24gPSBiaW5kKGZldGNoRnVuY3Rpb24sIHRoaXMsIHBhdGgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJpbmRlZEZ1bmN0aW9uID0gYmluZChjdXN0b21GdW5jdGlvbiwgdGhpcywgb3BlcmF0aW9uLCBwYXRoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNyZWF0ZWRGdW5jdGlvbiA9IGZ1bmN0aW9uIChwYXJhbXMsIGhlYWRlcnMsIGVsZW0pIHtcbiAgICAgICAgICBjb25zdCBjYWxsUGFyYW1zID0gZGVmYXVsdHMoe1xuICAgICAgICAgICAgcGFyYW1zOiBwYXJhbXMsXG4gICAgICAgICAgICBoZWFkZXJzOiBoZWFkZXJzLFxuICAgICAgICAgICAgZWxlbTogZWxlbVxuICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgIHBhcmFtczogZGVmYXVsdFBhcmFtcyxcbiAgICAgICAgICAgIGhlYWRlcnM6IGRlZmF1bHRIZWFkZXJzLFxuICAgICAgICAgICAgZWxlbTogZGVmYXVsdEVsZW1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gYmluZGVkRnVuY3Rpb24oY2FsbFBhcmFtcy5wYXJhbXMsIGNhbGxQYXJhbXMuaGVhZGVycywgY2FsbFBhcmFtcy5lbGVtKTtcbiAgICAgICAgfTtcblxuICAgICAgICBpZiAoY29uZmlnLmlzU2FmZShvcGVyYXRpb24pKSB7XG4gICAgICAgICAgdGhpc1tuYW1lXSA9IGNyZWF0ZWRGdW5jdGlvbjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzW25hbWVdID0gZnVuY3Rpb24gKGVsZW0sIHBhcmFtcywgaGVhZGVycykge1xuICAgICAgICAgICAgcmV0dXJuIGNyZWF0ZWRGdW5jdGlvbihwYXJhbXMsIGhlYWRlcnMsIGVsZW0pO1xuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gd2l0aENvbmZpZ3VyYXRpb25GdW5jdGlvbihjb25maWd1cmVyKSB7XG4gICAgICAgIGNvbnN0IG5ld0NvbmZpZyA9IGNsb25lKG9taXQoY29uZmlnLCAnY29uZmlndXJhdGlvbicpKTtcbiAgICAgICAgUmVzdGFuZ3VsYXJDb25maWd1cmVyKG5ld0NvbmZpZywgbmV3Q29uZmlnKTtcbiAgICAgICAgY29uZmlndXJlcihuZXdDb25maWcpO1xuICAgICAgICByZXR1cm4gY3JlYXRlU2VydmljZUZvckNvbmZpZ3VyYXRpb24obmV3Q29uZmlnKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gdG9TZXJ2aWNlKHJvdXRlLCBwYXJlbnQpIHtcbiAgICAgICAgY29uc3Qga25vd25Db2xsZWN0aW9uTWV0aG9kcyA9IHZhbHVlcyhjb25maWcucmVzdGFuZ3VsYXJGaWVsZHMpO1xuICAgICAgICBjb25zdCBzZXJ2OiBhbnkgPSB7fTtcbiAgICAgICAgY29uc3QgY29sbGVjdGlvbiA9IChwYXJlbnQgfHwgc2VydmljZSkuYWxsKHJvdXRlKTtcbiAgICAgICAgc2Vydi5vbmUgPSBiaW5kKG9uZSwgKHBhcmVudCB8fCBzZXJ2aWNlKSwgcGFyZW50LCByb3V0ZSk7XG4gICAgICAgIHNlcnYuYWxsID0gYmluZChjb2xsZWN0aW9uLmFsbCwgY29sbGVjdGlvbik7XG4gICAgICAgIHNlcnYucG9zdCA9IGJpbmQoY29sbGVjdGlvbi5wb3N0LCBjb2xsZWN0aW9uKTtcbiAgICAgICAgc2Vydi5nZXRMaXN0ID0gYmluZChjb2xsZWN0aW9uLmdldExpc3QsIGNvbGxlY3Rpb24pO1xuICAgICAgICBzZXJ2LndpdGhIdHRwQ29uZmlnID0gYmluZChjb2xsZWN0aW9uLndpdGhIdHRwQ29uZmlnLCBjb2xsZWN0aW9uKTtcbiAgICAgICAgc2Vydi5nZXQgPSBiaW5kKGNvbGxlY3Rpb24uZ2V0LCBjb2xsZWN0aW9uKTtcblxuICAgICAgICBmb3IgKGNvbnN0IHByb3AgaW4gY29sbGVjdGlvbikge1xuICAgICAgICAgIGlmIChjb2xsZWN0aW9uLmhhc093blByb3BlcnR5KHByb3ApICYmIGlzRnVuY3Rpb24oY29sbGVjdGlvbltwcm9wXSkgJiYgIWluY2x1ZGVzKGtub3duQ29sbGVjdGlvbk1ldGhvZHMsIHByb3ApKSB7XG4gICAgICAgICAgICBzZXJ2W3Byb3BdID0gYmluZChjb2xsZWN0aW9uW3Byb3BdLCBjb2xsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gc2VydjtcbiAgICAgIH1cblxuICAgICAgUmVzdGFuZ3VsYXJDb25maWd1cmVyKHNlcnZpY2UsIGNvbmZpZyk7XG5cbiAgICAgIHNlcnZpY2UuY29weSA9IGJpbmQoY29weVJlc3Rhbmd1bGFyaXplZEVsZW1lbnQsIHNlcnZpY2UpO1xuXG4gICAgICBzZXJ2aWNlLnNlcnZpY2UgPSBiaW5kKHRvU2VydmljZSwgc2VydmljZSk7XG5cbiAgICAgIHNlcnZpY2Uud2l0aENvbmZpZyA9IGJpbmQod2l0aENvbmZpZ3VyYXRpb25GdW5jdGlvbiwgc2VydmljZSk7XG5cbiAgICAgIHNlcnZpY2Uub25lID0gYmluZChvbmUsIHNlcnZpY2UsIG51bGwpO1xuXG4gICAgICBzZXJ2aWNlLmFsbCA9IGJpbmQoYWxsLCBzZXJ2aWNlLCBudWxsKTtcblxuICAgICAgc2VydmljZS5zZXZlcmFsID0gYmluZChzZXZlcmFsLCBzZXJ2aWNlLCBudWxsKTtcblxuICAgICAgc2VydmljZS5vbmVVcmwgPSBiaW5kKG9uZVVybCwgc2VydmljZSwgbnVsbCk7XG5cbiAgICAgIHNlcnZpY2UuYWxsVXJsID0gYmluZChhbGxVcmwsIHNlcnZpY2UsIG51bGwpO1xuXG4gICAgICBzZXJ2aWNlLnN0cmlwUmVzdGFuZ3VsYXIgPSBiaW5kKHN0cmlwUmVzdGFuZ3VsYXIsIHNlcnZpY2UpO1xuXG4gICAgICBzZXJ2aWNlLnJlc3Rhbmd1bGFyaXplRWxlbWVudCA9IGJpbmQocmVzdGFuZ3VsYXJpemVFbGVtLCBzZXJ2aWNlKTtcblxuICAgICAgc2VydmljZS5yZXN0YW5ndWxhcml6ZUNvbGxlY3Rpb24gPSBiaW5kKHJlc3Rhbmd1bGFyaXplQ29sbGVjdGlvbkFuZEVsZW1lbnRzLCBzZXJ2aWNlKTtcblxuICAgICAgcmV0dXJuIHNlcnZpY2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNyZWF0ZVNlcnZpY2VGb3JDb25maWd1cmF0aW9uKGdsb2JhbENvbmZpZ3VyYXRpb24pO1xuICB9XG5cbn1cbiIsImltcG9ydCB7IE1vZHVsZVdpdGhQcm92aWRlcnMsIE5nTW9kdWxlLCBPcHRpb25hbCwgU2tpcFNlbGYsIEluamVjdGlvblRva2VuIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBIdHRwQ2xpZW50TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xuaW1wb3J0IHsgUkVTVEFOR1VMQVIsIFJlc3Rhbmd1bGFyRmFjdG9yeSB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLmNvbmZpZyc7XG5pbXBvcnQgeyBSZXN0YW5ndWxhciB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyJztcbmltcG9ydCB7IFJlc3Rhbmd1bGFySHR0cCB9IGZyb20gJy4vbmd4LXJlc3Rhbmd1bGFyLWh0dHAnO1xuXG5leHBvcnQgY29uc3QgQ09ORklHX09CSiA9IG5ldyBJbmplY3Rpb25Ub2tlbjxzdHJpbmc+KCdjb25maWdPYmonKTtcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW0h0dHBDbGllbnRNb2R1bGVdLFxuICBwcm92aWRlcnM6IFtSZXN0YW5ndWxhckh0dHAsIFJlc3Rhbmd1bGFyXVxufSlcbmV4cG9ydCBjbGFzcyBSZXN0YW5ndWxhck1vZHVsZSB7XG5cbiAgY29uc3RydWN0b3IoQE9wdGlvbmFsKCkgQFNraXBTZWxmKCkgcGFyZW50TW9kdWxlOiBSZXN0YW5ndWxhck1vZHVsZSkge1xuICAgIGlmIChwYXJlbnRNb2R1bGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ1Jlc3Rhbmd1bGFyTW9kdWxlIGlzIGFscmVhZHkgbG9hZGVkLiBJbXBvcnQgaXQgaW4gdGhlIEFwcE1vZHVsZSBvbmx5Jyk7XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIGZvclJvb3QoY29uZmlnRnVuY3Rpb24/OiAocHJvdmlkZXI6IGFueSwgLi4uYXJnOiBhbnlbXSkgPT4gdm9pZCk6IE1vZHVsZVdpdGhQcm92aWRlcnM7XG4gIHN0YXRpYyBmb3JSb290KHByb3ZpZGVycz86IGFueVtdLCBjb25maWdGdW5jdGlvbj86IChwcm92aWRlcjogYW55LCAuLi5hcmc6IGFueVtdKSA9PiB2b2lkKTogTW9kdWxlV2l0aFByb3ZpZGVycztcbiAgc3RhdGljIGZvclJvb3QoY29uZmlnMT8sIGNvbmZpZzI/KTogTW9kdWxlV2l0aFByb3ZpZGVycyB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5nTW9kdWxlOiBSZXN0YW5ndWxhck1vZHVsZSxcbiAgICAgIHByb3ZpZGVyczogW1xuICAgICAgICB7cHJvdmlkZTogQ09ORklHX09CSiwgdXNlVmFsdWU6IFtjb25maWcxLCBjb25maWcyXX0sXG4gICAgICAgIHtwcm92aWRlOiBSRVNUQU5HVUxBUiwgdXNlRmFjdG9yeTogUmVzdGFuZ3VsYXJGYWN0b3J5LCBkZXBzOiBbQ09ORklHX09CSl19LFxuICAgICAgXVxuICAgIH07XG4gIH1cblxufVxuIl0sIm5hbWVzIjpbIkluamVjdGlvblRva2VuIiwiaXNBcnJheSIsIkh0dHBSZXF1ZXN0IiwiYXNzaWduIiwiSHR0cFBhcmFtcyIsIkh0dHBIZWFkZXJzIiwiaHR0cCIsImZpbHRlciIsIkh0dHBSZXNwb25zZSIsIm1hcCIsInRocm93RXJyb3IiLCJIdHRwRXJyb3JSZXNwb25zZSIsImNhdGNoRXJyb3IiLCJJbmplY3RhYmxlIiwiSHR0cEJhY2tlbmQiLCJvYmplY3QiLCJpbmNsdWRlcyIsImlzVW5kZWZpbmVkIiwiaXNOdWxsIiwiZGVmYXVsdHMiLCJlYWNoIiwiZXh0ZW5kIiwiZmluZCIsImhhcyIsImluaXRpYWwiLCJsYXN0IiwiY2xvbmUiLCJyZWR1Y2UiLCJpc0Jvb2xlYW4iLCJrZXlzIiwiaXNFbXB0eSIsImZvckVhY2giLCJpc09iamVjdCIsImlzRnVuY3Rpb24iLCJPcHRpb25hbCIsIkluamVjdCIsIkluamVjdG9yIiwiYmluZCIsInVuaW9uIiwidmFsdWVzIiwicGljayIsImlzTnVtYmVyIiwib21pdCIsIkJlaGF2aW9yU3ViamVjdCIsImV2ZXJ5IiwiZ2V0IiwiTmdNb2R1bGUiLCJIdHRwQ2xpZW50TW9kdWxlIiwiU2tpcFNlbGYiXSwibWFwcGluZ3MiOiI7Ozs7OztJQUFBOzs7Ozs7Ozs7Ozs7OztBQWNBLGFBdUdnQixNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLEdBQUcsT0FBTyxNQUFNLEtBQUssVUFBVSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLENBQUM7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUNqQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqQyxJQUFJO1lBQ0EsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSTtnQkFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5RTtRQUNELE9BQU8sS0FBSyxFQUFFO1lBQUUsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO1NBQUU7Z0JBQy9CO1lBQ0osSUFBSTtnQkFDQSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO29CQUNPO2dCQUFFLElBQUksQ0FBQztvQkFBRSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFBRTtTQUNwQztRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztBQUVELGFBQWdCLFFBQVE7UUFDcEIsS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7WUFDOUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekMsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDOzs7Ozs7O0FDcklELFFBQWEsV0FBVyxHQUFHLElBQUlBLG1CQUFjLENBQVMsdUJBQXVCLENBQUM7Ozs7O0FBRTlFLGFBQWdCLGtCQUFrQixDQUFDLEVBQThCO1lBQTlCLGtCQUE4QixFQUE3QiwwQkFBa0IsRUFBRSxnQkFBUTs7WUFDMUQsV0FBVyxHQUFHLEVBQUU7O1lBQ2hCLEVBQUUsR0FBRyxrQkFBa0I7UUFFM0IsSUFBSUMsY0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDL0IsV0FBVyxHQUFHLGtCQUFrQixDQUFDO1lBQ2pDLEVBQUUsR0FBRyxRQUFRLENBQUM7U0FDZjtRQUVELE9BQU8sRUFBQyxFQUFFLElBQUEsRUFBRSxXQUFXLGFBQUEsRUFBQyxDQUFDO0lBQzNCLENBQUM7Ozs7OztBQ2pCRCxJQUlBO1FBQUE7U0FtRUM7Ozs7O1FBakVRLCtCQUFhOzs7O1lBQXBCLFVBQXFCLE9BQU87O29CQUNwQixrQkFBa0IsR0FBRyxpQkFBaUIsQ0FBQyx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDOztvQkFDL0UsY0FBYyxHQUFHLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7O29CQUN4RSxVQUFVLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7O29CQUN6QyxlQUFlLEdBQUcsT0FBTyxDQUFDLGVBQWUsSUFBSSxLQUFLOztvQkFFcEQsT0FBTyxHQUFHLElBQUlDLGdCQUFXLENBQzNCLFVBQVUsRUFDVixPQUFPLENBQUMsR0FBRyxFQUNYLE9BQU8sQ0FBQyxJQUFJLEVBQ1o7b0JBQ0UsT0FBTyxFQUFFLGNBQWM7b0JBQ3ZCLE1BQU0sRUFBRSxrQkFBa0I7b0JBQzFCLFlBQVksRUFBRSxPQUFPLENBQUMsWUFBWTtvQkFDbEMsZUFBZSxpQkFBQTtpQkFDaEIsQ0FDRjtnQkFFRCxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQzFFLE9BQU8sR0FBRyxJQUFJQSxnQkFBVyxDQUN2QixVQUFVLEVBQ1YsT0FBTyxDQUFDLEdBQUcsRUFDWDt3QkFDRSxPQUFPLEVBQUUsY0FBYzt3QkFDdkIsTUFBTSxFQUFFLGtCQUFrQjt3QkFDMUIsWUFBWSxFQUFFLE9BQU8sQ0FBQyxZQUFZO3dCQUNsQyxlQUFlLGlCQUFBO3FCQUNoQixDQUNGLENBQUM7aUJBQ0g7Z0JBQ0QsT0FBTyxPQUFPLENBQUM7YUFDaEI7Ozs7O1FBRU0sMENBQXdCOzs7O1lBQS9CLFVBQWdDLFdBQVc7O29CQUNuQyxrQkFBa0IsR0FBR0MsYUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUM7O29CQUM5QyxNQUFNLEdBQWUsSUFBSUMsZUFBVSxFQUFFO3dDQUU5QixHQUFHOzt3QkFDUixLQUFLLEdBQVEsa0JBQWtCLENBQUMsR0FBRyxDQUFDO29CQUV4QyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ3hCLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHOzRCQUN6QixNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7eUJBQ2xDLENBQUMsQ0FBQztxQkFDSjt5QkFBTTt3QkFDTCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTs0QkFDN0IsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7eUJBQy9CO3dCQUNELE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDcEM7aUJBQ0Y7Z0JBYkQsS0FBSyxJQUFNLEdBQUcsSUFBSSxrQkFBa0I7NEJBQXpCLEdBQUc7aUJBYWI7Z0JBRUQsT0FBTyxNQUFNLENBQUM7YUFDZjs7Ozs7UUFFTSxzQ0FBb0I7Ozs7WUFBM0IsVUFBNEIsT0FBTztnQkFDakMsS0FBSyxJQUFNLEdBQUcsSUFBSSxPQUFPLEVBQUU7O3dCQUNuQixLQUFLLEdBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBQztvQkFDL0IsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7d0JBQ2hDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNyQjtpQkFDRjtnQkFFRCxPQUFPLElBQUlDLGdCQUFXLENBQUNGLGFBQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUM3QztRQUNILHdCQUFDO0lBQUQsQ0FBQyxJQUFBOzs7Ozs7QUN2RUQ7UUFZRSx5QkFBbUJHLE9BQWlCO1lBQWpCLFNBQUksR0FBSkEsT0FBSSxDQUFhO1NBQ25DOzs7OztRQUVELHVDQUFhOzs7O1lBQWIsVUFBYyxPQUFPOztvQkFDYixPQUFPLEdBQUcsaUJBQWlCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQztnQkFFeEQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQzlCOzs7OztRQUVELGlDQUFPOzs7O1lBQVAsVUFBUSxPQUF5QjtnQkFBakMsaUJBd0JDO2dCQXZCQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztxQkFDL0IsSUFBSSxDQUNIQyxnQkFBTSxDQUFDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSyxZQUFZQyxpQkFBWSxHQUFBLENBQUMsRUFDOUNDLGFBQUcsQ0FBQyxVQUFDLFFBQWE7b0JBQ2hCLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFO3dCQUNoQixPQUFPQyxlQUFVLENBQUMsSUFBSUMsc0JBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztxQkFDcEQ7b0JBQ0QsT0FBTyxRQUFRLENBQUM7aUJBQ2pCLENBQUMsRUFDRkYsYUFBRyxDQUFDLFVBQUEsUUFBUTtvQkFDVixRQUFRLENBQUMsTUFBTSxHQUFHLEVBQUMsTUFBTSxFQUFFLE9BQU8sRUFBQyxDQUFDO29CQUNwQyxPQUFPLFFBQVEsQ0FBQztpQkFDakIsQ0FBQyxFQUNGRyxvQkFBVSxDQUFDLFVBQUEsR0FBRztvQkFDWixHQUFHLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztvQkFDdEIsR0FBRyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO29CQUNyQixHQUFHLENBQUMsYUFBYSxHQUFHLFVBQUMsVUFBVzt3QkFDOUIsT0FBTyxLQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsQ0FBQztxQkFDNUMsQ0FBQztvQkFFRixPQUFPRixlQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3hCLENBQUMsQ0FDSCxDQUFDO2FBQ0g7O29CQXBDRkcsZUFBVTs7Ozs7d0JBUkZDLGdCQUFXOzs7UUE2Q3BCLHNCQUFDO0tBQUE7Ozs7Ozs7Ozs7O0FDekJELGFBQWdCLHFCQUFxQixDQUFDQyxTQUFNLEVBQUUsYUFBYTtRQUN6REEsU0FBTSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7Ozs7O1lBSy9CLFdBQVcsR0FBRyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUM7UUFDbEUsYUFBYSxDQUFDLE1BQU0sR0FBRyxVQUFVLFNBQVM7WUFDeEMsT0FBT0MsZUFBUSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztTQUN2RCxDQUFDOztZQUVJLGVBQWUsR0FBRyxlQUFlO1FBQ3ZDLGFBQWEsQ0FBQyxhQUFhLEdBQUcsVUFBVSxNQUFNO1lBQzVDLE9BQU9DLGtCQUFXLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxJQUFJQyxhQUFNLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQztnQkFDaEYsTUFBTSxJQUFJLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO2dCQUN0QyxhQUFhLENBQUMsV0FBVyxDQUFDO1NBQzdCLENBQUM7UUFFRixhQUFhLENBQUMsV0FBVyxHQUFHRCxrQkFBVyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQztRQUN0R0YsU0FBTSxDQUFDLHNCQUFzQixHQUFHLFVBQVUsS0FBSztZQUM3QyxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUNuQyxDQUFDOzs7O1FBSUYsYUFBYSxDQUFDLE9BQU8sR0FBR0Usa0JBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFDeEZGLFNBQU0sQ0FBQyxVQUFVLEdBQUcsVUFBVSxVQUFVO1lBQ3RDLGFBQWEsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7Z0JBQzVDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUM5QyxVQUFVLENBQUM7WUFDYixPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7Ozs7UUFLRixhQUFhLENBQUMsV0FBVyxHQUFHLGFBQWEsQ0FBQyxXQUFXLElBQUksRUFBRSxDQUFDO1FBQzVEQSxTQUFNLENBQUMsY0FBYyxHQUFHLFVBQVUsY0FBYztZQUM5QyxhQUFhLENBQUMsV0FBVyxHQUFHLGNBQWMsQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7Ozs7UUFLRixhQUFhLENBQUMsaUJBQWlCLEdBQUcsYUFBYSxDQUFDLGlCQUFpQixJQUFJLEVBQUUsQ0FBQztRQUN4RUEsU0FBTSxDQUFDLG9CQUFvQixHQUFHLFVBQVUsTUFBTTtZQUM1QyxhQUFhLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO1lBQ3pDLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQzs7OztRQUtGLGFBQWEsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDLGNBQWMsSUFBSSxLQUFLLENBQUM7UUFDckVBLFNBQU0sQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLEtBQUs7WUFDeEMsYUFBYSxDQUFDLGNBQWMsR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLENBQUM7WUFDN0QsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDO1FBRUYsYUFBYSxDQUFDLGNBQWMsR0FBRyxVQUFVLGVBQWUsRUFBRSxHQUFHO1lBQzNELE9BQU9JLGVBQVEsQ0FBQyxHQUFHLEVBQUUsZUFBZSxFQUFFLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQ3hFLENBQUM7UUFFRixhQUFhLENBQUMsU0FBUyxHQUFHRixrQkFBVyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDLFNBQVMsQ0FBQztRQUNoR0YsU0FBTSxDQUFDLFlBQVksR0FBRyxVQUFVLE1BQU07WUFDcEMsYUFBYSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7U0FDbEMsQ0FBQztRQUVGLGFBQWEsQ0FBQyxvQkFBb0IsR0FBRyxhQUFhLENBQUMsb0JBQW9CLElBQUk7WUFDekUsR0FBRyxFQUFFLEVBQUU7WUFDUCxJQUFJLEVBQUUsRUFBRTtZQUNSLEdBQUcsRUFBRSxFQUFFO1lBQ1AsTUFBTSxFQUFFLEVBQUU7WUFDVixNQUFNLEVBQUUsRUFBRTtTQUNYLENBQUM7UUFFRkEsU0FBTSxDQUFDLHVCQUF1QixHQUFHLFVBQVUsTUFBTSxFQUFFLE1BQU07O2dCQUNuRCxPQUFPLEdBQUcsRUFBRTs7Z0JBQ1YsTUFBTSxHQUFHLE1BQU0sSUFBSSxNQUFNO1lBQy9CLElBQUksQ0FBQ0Usa0JBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDeEIsSUFBSWhCLGNBQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDbkIsT0FBTyxHQUFHLE1BQU0sQ0FBQztpQkFDbEI7cUJBQU07b0JBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDdEI7YUFDRjtpQkFBTTtnQkFDTCxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3hCO1lBRURtQixXQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsTUFBTTtnQkFDNUIsYUFBYSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQzthQUNyRCxDQUFDLENBQUM7WUFDSCxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFFRkwsU0FBTSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUM7UUFFMUQsYUFBYSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUMsY0FBYyxJQUFJLEVBQUUsQ0FBQztRQUNsRUEsU0FBTSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsT0FBTztZQUMxQyxhQUFhLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQztZQUN2Q0EsU0FBTSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUMsY0FBYyxDQUFDO1lBQ3JELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGQSxTQUFNLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQyxjQUFjLENBQUM7Ozs7UUFNckQsYUFBYSxDQUFDLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsSUFBSSxTQUFTLENBQUM7UUFDdkZBLFNBQU0sQ0FBQyx3QkFBd0IsR0FBRyxVQUFVLE1BQU07WUFDaEQsYUFBYSxDQUFDLHFCQUFxQixHQUFHLE1BQU0sQ0FBQztZQUM3Q0EsU0FBTSxDQUFDLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQztZQUNuRSxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFDRkEsU0FBTSxDQUFDLHFCQUFxQixHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQzs7OztRQUtuRSxhQUFhLENBQUMsZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQztRQUN0RUEsU0FBTSxDQUFDLG1CQUFtQixHQUFHLFVBQVUsTUFBTTs7Z0JBQ3JDLFVBQVUsR0FBR00sYUFBTSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUM7WUFDckMsSUFBSSxhQUFhLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxFQUFFO2dCQUN6RCxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzNCO1lBQ0QsYUFBYSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsQ0FBQztZQUM1QyxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFFRixhQUFhLENBQUMsS0FBSyxHQUFHSixrQkFBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNyRkYsU0FBTSxDQUFDLFFBQVEsR0FBRyxVQUFVLE1BQU07WUFDaEMsYUFBYSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDOUIsQ0FBQztRQUVGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLE1BQU0sRUFBRSxNQUFNOztnQkFDbEQsTUFBTSxHQUFHLE1BQU0sSUFBSSxhQUFhLENBQUMsZ0JBQWdCO1lBQ3ZELE9BQU8sQ0FBQ0Usa0JBQVcsQ0FBQ0ssV0FBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEdBQVc7Z0JBQ3BELE9BQU8sR0FBRyxDQUFDLFdBQVcsRUFBRSxLQUFLLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNuRCxDQUFDLENBQUMsQ0FBQztTQUNMLENBQUM7Ozs7UUFLRixhQUFhLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDO1FBQzlEUCxTQUFNLENBQUMsYUFBYSxHQUFHLFVBQVUsSUFBSTtZQUNuQyxJQUFJLENBQUNRLFVBQUcsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEVBQUU7Z0JBQy9DLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0NBQWdDLENBQUMsQ0FBQzthQUNuRDtZQUVELGFBQWEsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ2hDLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7UUFZRixhQUFhLENBQUMsaUJBQWlCLEdBQUcsYUFBYSxDQUFDLGlCQUFpQixJQUFJO1lBQ25FLEVBQUUsRUFBRSxJQUFJO1lBQ1IsS0FBSyxFQUFFLE9BQU87WUFDZCxjQUFjLEVBQUUsZ0JBQWdCO1lBQ2hDLHFCQUFxQixFQUFFLHVCQUF1QjtZQUM5QyxZQUFZLEVBQUUsZ0JBQWdCO1lBQzlCLElBQUksRUFBRSxpQkFBaUI7WUFDdkIsUUFBUSxFQUFFLE1BQU07WUFDaEIsR0FBRyxFQUFFLEtBQUs7WUFDVixPQUFPLEVBQUUsU0FBUztZQUNsQixHQUFHLEVBQUUsS0FBSztZQUNWLElBQUksRUFBRSxNQUFNO1lBQ1osTUFBTSxFQUFFLFFBQVE7WUFDaEIsSUFBSSxFQUFFLE1BQU07WUFDWixLQUFLLEVBQUUsT0FBTztZQUNkLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLEtBQUssRUFBRSxPQUFPO1lBQ2QsaUJBQWlCLEVBQUUsbUJBQW1CO1lBQ3RDLGVBQWUsRUFBRSxpQkFBaUI7WUFDbEMsVUFBVSxFQUFFLFlBQVk7WUFDeEIsb0JBQW9CLEVBQUUsc0JBQXNCO1lBQzVDLGFBQWEsRUFBRSxlQUFlO1lBQzlCLEtBQUssRUFBRSxPQUFPO1lBQ2QsR0FBRyxFQUFFLEtBQUs7WUFDVixVQUFVLEVBQUUsY0FBYztZQUMxQixTQUFTLEVBQUUsV0FBVztZQUN0QixHQUFHLEVBQUUsS0FBSztZQUNWLEdBQUcsRUFBRSxLQUFLO1lBQ1YsT0FBTyxFQUFFLFNBQVM7WUFDbEIsTUFBTSxFQUFFLFFBQVE7WUFDaEIsTUFBTSxFQUFFLFFBQVE7WUFDaEIsU0FBUyxFQUFFLFdBQVc7WUFDdEIsV0FBVyxFQUFFLGFBQWE7WUFDMUIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsWUFBWSxFQUFFLGNBQWM7WUFDNUIsU0FBUyxFQUFFLFdBQVc7WUFDdEIsYUFBYSxFQUFFLGVBQWU7WUFDOUIsZUFBZSxFQUFFLGlCQUFpQjtZQUNsQyxLQUFLLEVBQUUsT0FBTztZQUNkLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLEtBQUssRUFBRSxPQUFPO1lBQ2QsU0FBUyxFQUFFLFdBQVc7WUFDdEIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsVUFBVSxFQUFFLFlBQVk7WUFDeEIsY0FBYyxFQUFFLGdCQUFnQjtZQUNoQyxTQUFTLEVBQUUsV0FBVztZQUN0QixLQUFLLEVBQUUsT0FBTztZQUNkLElBQUksRUFBRSxNQUFNO1lBQ1osZUFBZSxFQUFFLGlCQUFpQjtTQUNuQyxDQUFDO1FBQ0ZSLFNBQU0sQ0FBQyxvQkFBb0IsR0FBRyxVQUFVLFNBQVM7WUFDL0MsYUFBYSxDQUFDLGlCQUFpQjtnQkFDN0JNLGFBQU0sQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLEdBQUc7WUFDN0MsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztTQUMvRCxDQUFDO1FBRUYsYUFBYSxDQUFDLGNBQWMsR0FBRyxVQUFVLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSzs7Z0JBQ25ELFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7Z0JBQy9CLE9BQU8sR0FBRyxJQUFJO1lBQ2xCRCxXQUFJLENBQUNJLGNBQU8sQ0FBQyxVQUFVLENBQUMsRUFBRSxVQUFVLElBQVM7Z0JBQzNDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ25CLE9BQU8sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDekIsQ0FBQyxDQUFDOztnQkFDRyxLQUFLLEdBQVFDLFdBQUksQ0FBQyxVQUFVLENBQUM7WUFDbkMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFFRixhQUFhLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxLQUFLLEVBQUUsSUFBSTs7Z0JBQzlDLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7Z0JBQy9CLE9BQU8sR0FBUSxJQUFJO1lBQ3ZCTCxXQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsSUFBSTtnQkFDN0IsSUFBSSxPQUFPLEVBQUU7b0JBQ1gsT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDekI7YUFDRixDQUFDLENBQUM7WUFDSCxPQUFPTSxZQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDdkIsQ0FBQztRQUVGLGFBQWEsQ0FBQyxXQUFXLEdBQUcsVUFBVSxJQUFJLEVBQUUsRUFBRTtZQUM1QyxhQUFhLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzNFLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGLGFBQWEsQ0FBQyxhQUFhLEdBQUcsVUFBVSxJQUFJO1lBQzFDLE9BQU8sYUFBYSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDakYsQ0FBQztRQUVGLGFBQWEsQ0FBQyxTQUFTLEdBQUcsVUFBVSxNQUFNO1lBQ3hDLE9BQU8sRUFBRSxLQUFLLE1BQU0sSUFBSSxDQUFDVCxrQkFBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUNDLGFBQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNqRSxDQUFDO1FBRUYsYUFBYSxDQUFDLFlBQVksR0FBRyxVQUFVLElBQUksRUFBRSxHQUFHO1lBQzlDLGFBQWEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDbEYsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDO1FBRUYsYUFBYSxDQUFDLGNBQWMsR0FBRyxVQUFVLElBQUk7WUFDM0MsT0FBTyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUN2RixDQUFDO1FBRUYsYUFBYSxDQUFDLGVBQWUsR0FBR0Qsa0JBQVcsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLEdBQUcsS0FBSyxHQUFHLGFBQWEsQ0FBQyxlQUFlLENBQUM7UUFDbkhGLFNBQU0sQ0FBQyxrQkFBa0IsR0FBRyxVQUFVLEtBQUs7WUFDekMsYUFBYSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7WUFDdEMsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDO1FBRUYsYUFBYSxDQUFDLHVCQUF1QixHQUFHLFVBQVUsSUFBSTs7Z0JBQzlDLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQzs7Z0JBQ2pFLFFBQVEsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLFlBQVksR0FBRyxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUN6RyxPQUFPLFFBQVEsQ0FBQztTQUNqQixDQUFDOzs7Ozs7OztRQVVGLGFBQWEsQ0FBQyxvQkFBb0IsR0FBRyxhQUFhLENBQUMsb0JBQW9CLFlBQU8sYUFBYSxDQUFDLG9CQUFvQixJQUFJLEVBQUUsQ0FBQztRQUV2SCxhQUFhLENBQUMsMEJBQTBCLEdBQUcsVUFBVSxJQUFJO1lBQ3ZELE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQztTQUNuQixDQUFDO1FBRUYsYUFBYSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPOztnQkFDakYsWUFBWSxHQUFHVyxZQUFLLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDO1lBQzlELFlBQVksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLDBCQUEwQixDQUFDLENBQUM7O2dCQUN4RCxPQUFPLEdBQUcsSUFBSTtZQUNsQk4sV0FBSSxDQUFDLFlBQVksRUFBRSxVQUFVLFdBQWdCO2dCQUMzQyxPQUFPLEdBQUcsV0FBVyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQ3RDLElBQUksRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQ2pDLENBQUMsQ0FBQztZQUNILE9BQU8sT0FBTyxDQUFDO1NBQ2hCLENBQUM7UUFFRkwsU0FBTSxDQUFDLHNCQUFzQixHQUFHLFVBQVUsU0FBUztZQUNqRCxhQUFhLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ25ELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxhQUFhLENBQUMsaUJBQWlCLFlBQU8sYUFBYSxDQUFDLGlCQUFpQixJQUFJLEVBQUUsQ0FBQztRQUM5R0EsU0FBTSxDQUFDLG1CQUFtQixHQUFHLFVBQVUsV0FBVztZQUNoRCxhQUFhLENBQUMsaUJBQWlCLGFBQUksV0FBVyxHQUFLLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3BGLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGQSxTQUFNLENBQUMsc0JBQXNCLEdBQUdBLFNBQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM5REEsU0FBTSxDQUFDLG9CQUFvQixHQUFHQSxTQUFNLENBQUMsc0JBQXNCLENBQUM7UUFDNURBLFNBQU0sQ0FBQyxtQkFBbUIsR0FBR0EsU0FBTSxDQUFDLG1CQUFtQixDQUFDOzs7Ozs7O1FBVXhELGFBQWEsQ0FBQyxtQkFBbUIsR0FBRyxhQUFhLENBQUMsbUJBQW1CLFlBQU8sYUFBYSxDQUFDLG1CQUFtQixJQUFJLEVBQUUsQ0FBQztRQUVwSCxhQUFhLENBQUMsa0JBQWtCLEdBQUcsVUFBVSxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxVQUFVO1lBQ3JHLE9BQU87Z0JBQ0wsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixNQUFNLEVBQUUsTUFBTTtnQkFDZCxVQUFVLEVBQUUsVUFBVTthQUN2QixDQUFDO1NBQ0gsQ0FBQztRQUVGLGFBQWEsQ0FBQyxzQkFBc0IsR0FBRyxVQUFVLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVU7O2dCQUNuRyxZQUFZLEdBQUdXLFlBQUssQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUM7O2dCQUN2RCxjQUFjLEdBQUcsYUFBYSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsQ0FBQztZQUNuSCxPQUFPQyxhQUFNLENBQUMsWUFBWSxFQUFFLFVBQVUsT0FBWSxFQUFFLFdBQWdCOztvQkFFNUQsaUJBQWlCLEdBQVEsV0FBVyxDQUN4QyxPQUFPLENBQUMsT0FBTyxFQUNmLFNBQVMsRUFDVCxJQUFJLEVBQ0osR0FBRyxFQUNILE9BQU8sQ0FBQyxPQUFPLEVBQ2YsT0FBTyxDQUFDLE1BQU0sRUFDZCxPQUFPLENBQUMsVUFBVSxDQUNuQjtnQkFDRCxPQUFPTixhQUFNLENBQUMsT0FBTyxFQUFFLGlCQUFpQixDQUFDLENBQUM7YUFDM0MsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUNwQixDQUFDO1FBRUZOLFNBQU0sQ0FBQyxxQkFBcUIsR0FBRyxVQUFVLFdBQVc7WUFDbEQsYUFBYSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVU7Z0JBQ3RHLE9BQU87b0JBQ0wsT0FBTyxFQUFFLE9BQU87b0JBQ2hCLE1BQU0sRUFBRSxNQUFNO29CQUNkLE9BQU8sRUFBRSxXQUFXLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDO29CQUNoRCxVQUFVLEVBQUUsVUFBVTtpQkFDdkIsQ0FBQzthQUNILENBQUMsQ0FBQztZQUNILE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGQSxTQUFNLENBQUMscUJBQXFCLEdBQUdBLFNBQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUU1REEsU0FBTSxDQUFDLHlCQUF5QixHQUFHLFVBQVUsV0FBVztZQUN0RCxhQUFhLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGQSxTQUFNLENBQUMseUJBQXlCLEdBQUdBLFNBQU0sQ0FBQyx5QkFBeUIsQ0FBQztRQUVwRSxhQUFhLENBQUMsMkJBQTJCLEdBQUcsYUFBYSxDQUFDLDJCQUEyQixJQUFJLFVBQVUsSUFBSTtZQUNyRyxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFDRkEsU0FBTSxDQUFDLDhCQUE4QixHQUFHLFVBQVUsSUFBSTtZQUNwRCxhQUFhLENBQUMsMkJBQTJCLEdBQUcsSUFBSSxDQUFDO1lBQ2pELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUVGQSxTQUFNLENBQUMsbUNBQW1DLEdBQUcsVUFBVSxXQUFXO1lBQ2hFLGFBQWEsQ0FBQyxnQ0FBZ0MsR0FBRyxXQUFXLENBQUM7WUFDN0QsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDOzs7Ozs7OztRQVNGLGFBQWEsQ0FBQyxxQkFBcUIsR0FBRyxhQUFhLENBQUMscUJBQXFCLElBQUksVUFBVSxJQUFJO1lBQ3pGLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQztRQUNGQSxTQUFNLENBQUMsd0JBQXdCLEdBQUcsVUFBVSxJQUFJO1lBQzlDLGFBQWEsQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7WUFDM0MsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDO1FBRUYsYUFBYSxDQUFDLGdCQUFnQixHQUFHLGFBQWEsQ0FBQyxnQkFBZ0IsSUFBSTtZQUNqRSxPQUFPLElBQUksQ0FBQztTQUNiLENBQUM7UUFDRkEsU0FBTSxDQUFDLGFBQWEsR0FBRyxVQUFVLE1BQU07WUFDckMsSUFBSWQsY0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQixhQUFhLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxLQUFLO29CQUM5QyxPQUFPLENBQUNlLGVBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQ2pDLENBQUM7YUFDSDtpQkFBTSxJQUFJWSxnQkFBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUM1QixhQUFhLENBQUMsZ0JBQWdCLEdBQUc7b0JBQy9CLE9BQU8sQ0FBQyxNQUFNLENBQUM7aUJBQ2hCLENBQUM7YUFDSDtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQzs7Ozs7Ozs7OztRQVdGLGFBQWEsQ0FBQyxNQUFNLEdBQUdYLGtCQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDO1FBQ3ZGRixTQUFNLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxTQUFTO1lBQzNDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1lBQ2pDLE9BQU8sSUFBSSxDQUFDO1NBQ2IsQ0FBQzs7OztRQUtGLGFBQWEsQ0FBQyxZQUFZLEdBQUcsYUFBYSxDQUFDLFlBQVksSUFBSSxFQUFFLENBQUM7UUFDOURBLFNBQU0sQ0FBQyxxQkFBcUIsR0FBRyxVQUFVLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUTs7Z0JBQzVELFlBQVksR0FBRyxJQUFJOztnQkFDbkIsV0FBVyxHQUFHLElBQUk7WUFDdEIsSUFBSSxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDMUIsV0FBVyxHQUFHLFNBQVMsQ0FBQzthQUN6QjtpQkFBTTtnQkFDTCxXQUFXLEdBQUcsUUFBUSxDQUFDO2dCQUN2QixZQUFZLEdBQUcsU0FBUyxDQUFDO2FBQzFCOztnQkFFRyxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztZQUN2RCxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3JCLGdCQUFnQixHQUFHLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2FBQzFEO1lBRUQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLElBQUk7Z0JBQ3hDLElBQUlHLGFBQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxJQUFJLEtBQUssWUFBWSxDQUFDLEVBQUU7b0JBQ25ELE9BQU8sV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUMxQjtnQkFDRCxPQUFPLElBQUksQ0FBQzthQUNiLENBQUMsQ0FBQztZQUVILE9BQU9ILFNBQU0sQ0FBQztTQUNmLENBQUM7UUFFRkEsU0FBTSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsS0FBSyxFQUFFLEVBQUU7WUFDM0MsT0FBT0EsU0FBTSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDdEQsQ0FBQztRQUVGQSxTQUFNLENBQUMsV0FBVyxHQUFHLFVBQVUsS0FBSyxFQUFFLEVBQUU7WUFDdEMsT0FBT0EsU0FBTSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDdkQsQ0FBQztRQUVGLGFBQWEsQ0FBQyxhQUFhLEdBQUcsVUFBVSxJQUFJLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSztZQUNuRixJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLHNCQUFzQixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDeEcsT0FBTyxJQUFJLENBQUM7YUFDYjs7Z0JBQ0ssZ0JBQWdCLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7O2dCQUN0RCxXQUFXLEdBQUcsSUFBSTtZQUN0QixJQUFJLGdCQUFnQixFQUFFO2dCQUNwQkssV0FBSSxDQUFDLGdCQUFnQixFQUFFLFVBQVUsV0FBNkQ7b0JBQzVGLFdBQVcsR0FBRyxXQUFXLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2lCQUN0RCxDQUFDLENBQUM7YUFDSjtZQUNELE9BQU8sYUFBYSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQzNGLENBQUM7UUFFRixhQUFhLENBQUMsc0JBQXNCLEdBQUdILGtCQUFXLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDO1lBQ3RGLEtBQUs7WUFDTCxhQUFhLENBQUMsc0JBQXNCLENBQUM7UUFFdkNGLFNBQU0sQ0FBQyw4QkFBOEIsR0FBRyxVQUFVLE1BQU07WUFDdEQsYUFBYSxDQUFDLHNCQUFzQixHQUFHLENBQUMsTUFBTSxDQUFDO1NBQ2hELENBQUM7UUFFRixhQUFhLENBQUMsWUFBWSxHQUFHRSxrQkFBVyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsR0FBRyxLQUFLLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQztRQUMxR0YsU0FBTSxDQUFDLGVBQWUsR0FBRyxVQUFVLElBQUk7WUFDckMsYUFBYSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDbEMsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDOztRQUlGLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7Ozs7OztZQU0vQixXQUFXLEdBQUc7U0FDbkI7UUFFRCxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQU07WUFDaEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7WUFDckIsT0FBTyxJQUFJLENBQUM7U0FDYixDQUFDO1FBRUYsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLEdBQUcsVUFBVSxPQUFPOztnQkFDOUMsT0FBTyxHQUFHLEVBQUU7WUFDbEIsT0FBTyxPQUFPLEVBQUU7Z0JBQ2QsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDdEIsT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxDQUFDO2FBQ2pFO1lBQ0QsT0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDMUIsQ0FBQzs7Ozs7Ozs7UUFFRixTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFVBQVU7O2dCQUNuRCxRQUFRLEdBQUcsRUFBRTtZQUNuQkssV0FBSSxDQUFDUyxXQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsVUFBVSxHQUFHOztvQkFDNUIsS0FBSyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUM7O2dCQUc3QixLQUFLLENBQUMsTUFBTSxHQUFHUixhQUFNLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDOztnQkFFakcsSUFBSVMsY0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDekIsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDO2lCQUNyQjtnQkFFRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUUvQixRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUc7OzRCQUNSLFlBQVksR0FBR1QsYUFBTSxDQUFDLEtBQUssRUFBRTs0QkFDakMsR0FBRyxFQUFFLEdBQUc7eUJBQ1QsQ0FBQzt3QkFDRixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7cUJBQzFDLENBQUM7aUJBRUg7cUJBQU07b0JBRUwsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsSUFBSTs7NEJBQ3RCLFlBQVksR0FBR0EsYUFBTSxDQUFDLEtBQUssRUFBRTs0QkFDakMsR0FBRyxFQUFFLEdBQUc7NEJBQ1IsSUFBSSxFQUFFLElBQUk7eUJBQ1gsQ0FBQzt3QkFDRixPQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7cUJBQzFDLENBQUM7aUJBRUg7YUFDRixDQUFDLENBQUM7WUFFSCxPQUFPLFFBQVEsQ0FBQztTQUNqQjtRQUVELFdBQVcsQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLFVBQVUsT0FBTyxFQUFFLEtBQUssRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFNBQVM7O2dCQUNsSCxNQUFNLEdBQUdGLGVBQVEsQ0FBQyxVQUFVLElBQUksRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDOztnQkFDNUUsT0FBTyxHQUFHQSxlQUFRLENBQUMsV0FBVyxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQztZQUV2RSxJQUFJLElBQUksRUFBRTtnQkFDUixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDcEMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFDNUI7cUJBQU07b0JBQ0wsT0FBTyxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFDakM7YUFDRjs7Z0JBRUcsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBRTVCLElBQUksSUFBSSxFQUFFOztvQkFDSixHQUFHLEdBQUcsRUFBRTtnQkFDWixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDcEIsR0FBRyxJQUFJLEdBQUcsQ0FBQztpQkFDWjtnQkFDRCxHQUFHLElBQUksSUFBSSxDQUFDO2dCQUNaLEdBQUcsSUFBSSxHQUFHLENBQUM7YUFDWjtZQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNO2dCQUNwQixHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDeEgsR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQzNCO1lBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUcsU0FBUyxDQUFDO1lBRTlELE9BQU8sbUJBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO2dCQUNsRCxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUNqRDtvQkFDRSxNQUFNLEVBQUUsS0FBSztvQkFDYixNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFFSixHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM3QztvQkFDRSxNQUFNLEVBQUUsS0FBSztvQkFDYixNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFFSixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUMvQztvQkFDRSxNQUFNLEVBQUUsT0FBTztvQkFDZixNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFFSixHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM3QztvQkFDRSxNQUFNLEVBQUUsS0FBSztvQkFDYixNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFFSixJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUM5QztvQkFDRSxNQUFNLEVBQUUsTUFBTTtvQkFDZCxNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsT0FBTztpQkFDakIsQ0FBQztnQkFFSixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUNoRDtvQkFDRSxNQUFNLEVBQUUsUUFBUTtvQkFDaEIsTUFBTSxFQUFFLE1BQU07b0JBQ2QsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBRUosSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDOUM7b0JBQ0UsTUFBTSxFQUFFLE1BQU07b0JBQ2QsTUFBTSxFQUFFLE1BQU07b0JBQ2QsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBRUosS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDL0M7b0JBQ0UsTUFBTSxFQUFFLE9BQU87b0JBQ2YsTUFBTSxFQUFFLE1BQU07b0JBQ2QsT0FBTyxFQUFFLE9BQU87aUJBQ2pCLENBQUM7Z0JBRUosT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFDakQ7b0JBQ0UsTUFBTSxFQUFFLFNBQVM7b0JBQ2pCLE1BQU0sRUFBRSxNQUFNO29CQUNkLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2dCQUVKLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQy9DO29CQUNFLE1BQU0sRUFBRSxPQUFPO29CQUNmLE1BQU0sRUFBRSxNQUFNO29CQUNkLE9BQU8sRUFBRSxPQUFPO2lCQUNqQixDQUFDO2FBQ0wsQ0FBQyxDQUFDO1NBQ0osQ0FBQzs7Ozs7Ozs7WUFPSSxJQUFJLEdBQUc7U0FDWjtRQUVELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUVuQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksR0FBRyxVQUFVLEdBQUc7O2dCQUNuQyxLQUFLLEdBQUcsNEJBQTRCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUNwRCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDN0MsT0FBTyxDQUFDLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMzRSxDQUFDO1FBRUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsVUFBVSxPQUFPOztnQkFDL0IsTUFBTSxHQUFHLElBQUk7WUFDbkIsT0FBT1EsYUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBVSxJQUFTLEVBQUUsSUFBUzs7b0JBQ2xFLE9BQU87O29CQUNMLFlBQVksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7Z0JBQ3ZELElBQUksWUFBWSxFQUFFO29CQUNoQixJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFO3dCQUM3QyxPQUFPLFlBQVksQ0FBQztxQkFDckI7eUJBQU07d0JBQ0wsT0FBTyxHQUFHLFlBQVksQ0FBQztxQkFDeEI7aUJBQ0Y7cUJBQU07b0JBQ0wsT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUV0RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLEVBQUU7OzRCQUN6RCxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO3dCQUNyRCxJQUFJLEdBQUcsRUFBRTs0QkFDUCxPQUFPLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQ2hDO3FCQUNGO3lCQUFNOzs0QkFDRCxNQUFNLFNBQUs7d0JBQ2YsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRTs0QkFDakMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7eUJBQ3REOzZCQUFNOzRCQUNMLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQzt5QkFDNUM7d0JBRUQsSUFBSSxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTs0QkFDdEQsT0FBTyxJQUFJLEdBQUcsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQzt5QkFDbEY7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUM7Z0JBQy9DLE9BQU8sTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUVsQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDekIsQ0FBQztRQUdGLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLFVBQVUsT0FBTyxFQUFFLElBQUk7O2dCQUMzQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDaEMsSUFBSSxJQUFJLEVBQUU7Z0JBQ1IsT0FBTyxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUM7YUFDdkI7WUFDRCxPQUFPLE9BQU8sQ0FBQztTQUNoQixDQUFDO1FBRUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLE9BQU8sRUFBRSxJQUFJOztnQkFDbEQsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQzs7Z0JBQ2xDLE1BQU0sR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQzs7Ozs7Ozs7Ozs7WUFRakUsU0FBUyxVQUFVLENBQUMsR0FBRzs7b0JBQ2YsVUFBVSxHQUFHLEVBQUU7Z0JBQ3JCLEtBQUssSUFBTSxHQUFHLElBQUksR0FBRyxFQUFFO29CQUNyQixJQUFJLEdBQUcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzNCLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ3RCO2lCQUNGO2dCQUNELE9BQU8sVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQzFCOzs7Ozs7O1lBRUQsU0FBUyxhQUFhLENBQUMsR0FBRyxFQUFFLFFBQVMsRUFBRSxPQUFROztvQkFDdkMsZUFBZSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUM7Z0JBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUMvQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3JFO2dCQUNELE9BQU8sZUFBZSxDQUFDO2FBQ3hCOzs7Ozs7WUFFRCxTQUFTLGNBQWMsQ0FBQyxHQUFHLEVBQUUsZUFBZ0I7Z0JBQzNDLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxDQUFDO3FCQUM3QixPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQztxQkFDckIsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7cUJBQ3JCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDO3FCQUNwQixPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQztxQkFDckIsT0FBTyxDQUFDLE1BQU0sR0FBRyxlQUFlLEdBQUcsS0FBSyxHQUFHLEdBQUcsRUFBRSxDQUFDO2FBQ25EO1lBRUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDWCxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQzthQUN6Qzs7Z0JBRUssS0FBSyxHQUFHLEVBQUU7WUFDaEIsYUFBYSxDQUFDLE1BQU0sRUFBRSxVQUFVLEtBQUssRUFBRSxHQUFHO2dCQUN4QyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRTtvQkFDekMsT0FBTztpQkFDUjtnQkFDRCxJQUFJLENBQUMxQixjQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ25CLEtBQUssR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUNqQjtnQkFFRDhCLGNBQU8sQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDO29CQUN4QixJQUFJQyxlQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ2YsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3ZCO29CQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDM0QsQ0FBQyxDQUFDO2FBQ0osQ0FBQyxDQUFDO1lBRUgsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3JHLENBQUM7UUFFRixhQUFhLENBQUMsaUJBQWlCLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztJQUM5QyxDQUFDOzs7Ozs7O1FDL3FCQyxxQkFDMEMsU0FBUyxFQUN6QyxRQUFrQixFQUNsQjFCLE9BQXFCO1lBRlcsY0FBUyxHQUFULFNBQVMsQ0FBQTtZQUN6QyxhQUFRLEdBQVIsUUFBUSxDQUFVO1lBQ2xCLFNBQUksR0FBSkEsT0FBSSxDQUFpQjtZQUU3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksY0FBYyxDQUFDQSxPQUFJLENBQUMsQ0FBQzs7Z0JBQ25DLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtZQUNwQ0gsYUFBTSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUV0QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztTQUN6Qjs7OztRQUVELHNDQUFnQjs7O1lBQWhCO2dCQUFBLGlCQVVDOztnQkFUQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDOEIsaUJBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxFQUFFO29CQUNyRCxPQUFPO2lCQUNSOztvQkFFSyxLQUFLLEdBQUd4QixVQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBQyxRQUFtQjtvQkFDaEUsT0FBTyxLQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDcEMsQ0FBQztnQkFFRixDQUFBLEtBQUEsSUFBSSxDQUFDLFNBQVMsRUFBQyxFQUFFLHFCQUFLLElBQUksQ0FBQyxRQUFRLEdBQUssS0FBSyxHQUFHO2FBQ2pEOztvQkEzSEZJLGVBQVU7Ozs7O3dEQXNHTnFCLGFBQVEsWUFBSUMsV0FBTSxTQUFDLFdBQVc7d0JBcklOQyxhQUFRO3dCQTRCNUIsZUFBZTs7O1FBK0h4QixrQkFBQztLQUFBLElBQUE7Ozs7O0lBRUQsU0FBUyxjQUFjLENBQUMsS0FBSzs7WUFDckIsbUJBQW1CLEdBQUcsRUFBRTtRQUU5QixxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUVqRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzs7OztRQUVqQixTQUFTLElBQUk7Ozs7O1lBRVgsU0FBUyw2QkFBNkIsQ0FBQyxNQUFNOztvQkFDckMsT0FBTyxHQUFRLEVBQUU7O29CQUVqQixVQUFVLEdBQUcsSUFBSSxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNwRSxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7Ozs7Z0JBRTdCLFNBQVMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFVBQVU7b0JBQ3BFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO29CQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLEdBQUdDLFdBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDL0YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsR0FBR0EsV0FBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3RHLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsb0JBQW9CLENBQUMsR0FBR0EsV0FBSSxDQUFDLDRCQUE0QixFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMvRixJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHQSxXQUFJLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzlFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUdQLGNBQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLEdBQUcsU0FBUyxDQUFDO29CQUNqRixJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxHQUFHTyxXQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUMzRSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHQSxXQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDOztvQkFHMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUM7O29CQUd0RCxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHQSxXQUFJLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDM0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBR0EsV0FBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzNELElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLEdBQUdBLFdBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNuRSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxHQUFHQSxXQUFJLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDakUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsR0FBR0EsV0FBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRWpFLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQztvQkFFekQsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxFQUFFOzs0QkFDdEMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDOzs0QkFDdkMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDOzs0QkFFekMsMEJBQTBCLEdBQUdDLFlBQUssQ0FDdENDLGFBQU0sQ0FBQ0MsV0FBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQ2hGLE1BQU0sQ0FBQyxXQUFXLENBQ25COzs0QkFDSyxjQUFjLEdBQUdBLFdBQUksQ0FBQyxNQUFNLEVBQUUsMEJBQTBCLENBQUM7d0JBRS9ELElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRTs0QkFDOUIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUNyRDt3QkFDRCxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEVBQUU7NEJBQy9CLE1BQU0sQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQzt5QkFDdkQ7d0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsR0FBRyxjQUFjLENBQUM7cUJBQ2hFO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEdBQUcsSUFBSSxDQUFDO3FCQUN0RDtvQkFDRCxPQUFPLElBQUksQ0FBQztpQkFDYjs7Ozs7Ozs7Z0JBRUQsU0FBUyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsU0FBUzs7d0JBQ25DLEtBQUs7b0JBQ1QsSUFBSUMsZUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJQSxlQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ3ZDLEtBQUssR0FBRyx3REFBd0QsQ0FBQzt3QkFDakUsS0FBSyxJQUFJLDRFQUE0RSxDQUFDO3dCQUN0RixNQUFNLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUN4QjtvQkFDRCxJQUFJeEIsa0JBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDdEIsS0FBSyxHQUFHLGlFQUFpRSxDQUFDO3dCQUMxRSxLQUFLLElBQUksK0VBQStFLENBQUM7d0JBQ3pGLE1BQU0sSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3hCOzt3QkFDSyxJQUFJLEdBQUcsRUFBRTtvQkFDZixNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ3BDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzNFLE9BQU8sa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQ3ZEOzs7Ozs7Z0JBRUQsU0FBUyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUs7b0JBQ3hCLE9BQU8sd0JBQXdCLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQzNEOzs7Ozs7Z0JBRUQsU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUs7O3dCQUN0QixVQUFVLEdBQUcsRUFBRTtvQkFDckIsVUFBVSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNyRixPQUFPLHdCQUF3QixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUNuRTs7Ozs7OztnQkFFRCxTQUFTLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUc7b0JBQ2hDLElBQUksQ0FBQyxLQUFLLEVBQUU7d0JBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQywyREFBMkQsQ0FBQyxDQUFDO3FCQUM5RTs7d0JBQ0ssSUFBSSxHQUFHLEVBQUU7b0JBQ2YsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUN0QyxPQUFPLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUN2RDs7Ozs7OztnQkFFRCxTQUFTLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUc7b0JBQ2hDLElBQUksQ0FBQyxLQUFLLEVBQUU7d0JBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQywyREFBMkQsQ0FBQyxDQUFDO3FCQUM5RTs7d0JBQ0ssSUFBSSxHQUFHLEVBQUU7b0JBQ2YsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUN0QyxPQUFPLHdCQUF3QixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUM3RDs7Ozs7Ozs7Z0JBR0QsU0FBUyxzQkFBc0IsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLFdBQVc7b0JBQ2hFLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQ1YsZ0JBQU0sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsQ0FBQyxHQUFHLEdBQUEsQ0FBQyxDQUFDLENBQUM7aUJBQzNDOzs7Ozs7OztnQkFFRCxTQUFTLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxXQUFXO29CQUMxRGMsYUFBTSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQzs7b0JBRzFCLElBQUksTUFBTSxDQUFDLFlBQVksRUFBRTt3QkFDdkIsT0FBTyxDQUFDLElBQUksQ0FBQ0EsYUFBTSxDQUFDLFFBQVEsRUFBRTs0QkFDNUIsSUFBSSxFQUFFLElBQUk7eUJBQ1gsQ0FBQyxDQUFDLENBQUM7cUJBQ0w7eUJBQU07d0JBQ0wsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDcEI7b0JBRUQsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO2lCQUNwQjs7Ozs7O2dCQUdELFNBQVMsZ0JBQWdCLENBQUMsSUFBSTtvQkFDNUIsSUFBSXBCLGNBQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTs7NEJBQ1gsT0FBSyxHQUFHLEVBQUU7d0JBQ2hCbUIsV0FBSSxDQUFDLElBQUksRUFBRSxVQUFVLEtBQUs7NEJBQ3hCLE9BQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO3lCQUMvRSxDQUFDLENBQUM7d0JBQ0gsT0FBTyxPQUFLLENBQUM7cUJBQ2Q7eUJBQU07d0JBQ0wsT0FBT3NCLFdBQUksQ0FBQyxJQUFJLEVBQUVILGFBQU0sQ0FBQ0csV0FBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2pFO2lCQUNGOzs7OztnQkFFRCxTQUFTLGtCQUFrQixDQUFDLElBQUk7b0JBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLEdBQUdMLFdBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7O3dCQUN0RSxjQUFjLEdBQUcsRUFBQyxHQUFHLEVBQUUsY0FBYyxFQUFFLE1BQU0sRUFBRSxjQUFjLEVBQUM7b0JBQ3BFakIsV0FBSSxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRSxVQUFVLElBQUk7d0JBQzNDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxVQUFVLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPOzRCQUN4RSxPQUFPaUIsV0FBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7eUJBQzlFLENBQUM7cUJBQ0gsQ0FBQyxDQUFDO29CQUNIakIsV0FBSSxDQUFDLGNBQWMsRUFBRSxVQUFVLFdBQVcsRUFBRSxJQUFJOzs0QkFDeEMsYUFBYSxHQUFHLElBQUksS0FBSyxRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUk7d0JBQ3pEQSxXQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUUsVUFBVSxLQUFLOzRCQUNwQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxHQUFHaUIsV0FBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7eUJBQzNFLENBQUMsQ0FBQztxQkFDSixDQUFDLENBQUM7b0JBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDekUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDO2lCQUN6Rjs7Ozs7O2dCQUVELFNBQVMsMEJBQTBCLENBQUMsV0FBVyxFQUFFLFNBQWM7b0JBQWQsMEJBQUE7d0JBQUEsY0FBYzs7O3dCQUN2RCxhQUFhLEdBQUdsQyxhQUFNLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQztvQkFDcEQsT0FBTyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyxFQUM5RSxhQUFhLEVBQUUsYUFBYSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDdkU7Ozs7Ozs7Ozs7Z0JBRUQsU0FBUyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFXLEVBQUUsVUFBVyxFQUFFLFNBQVU7O3dCQUNoRixJQUFJLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDOzt3QkFFaEUsU0FBUyxHQUFHLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxVQUFVLENBQUM7b0JBRWhGLElBQUksTUFBTSxDQUFDLGVBQWUsRUFBRTt3QkFDMUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3FCQUNwRjtvQkFFRCxJQUFJLFVBQVUsRUFBRTt3QkFDZCxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxHQUFHOzRCQUNsRCxPQUFPLFVBQVUsQ0FBQzt5QkFDbkIsQ0FBQztxQkFDSDtvQkFFRCxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLEdBQUcsS0FBSyxDQUFDO29CQUNsRSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxHQUFHa0MsV0FBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDdkUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDN0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBR0EsV0FBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDdkUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBR0EsV0FBSSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDekUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsR0FBR0EsV0FBSSxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDN0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBR0EsV0FBSSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDekUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDM0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBR0EsV0FBSSxDQUFDLGVBQWUsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDL0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDM0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBR0EsV0FBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFFakUsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQzlCLE9BQU8sTUFBTSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ3JFOzs7Ozs7Ozs7Z0JBRUQsU0FBUyx3QkFBd0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFXLEVBQUUsU0FBVTs7d0JBQ3pFLElBQUksR0FBRyxNQUFNLENBQUMsMkJBQTJCLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLENBQUM7O3dCQUUvRCxTQUFTLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQztvQkFDaEYsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLElBQUksQ0FBQztvQkFDakUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBR0EsV0FBSSxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQy9FLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUdBLFdBQUksQ0FBQyxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzdFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUdBLFdBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQ3pFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEdBQUdBLFdBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzNFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEdBQUdBLFdBQUksQ0FBQyxrQkFBa0IsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDckYsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBR0EsV0FBSSxDQUFDLGVBQWUsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDL0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDM0UsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBR0EsV0FBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDbkUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsR0FBR0EsV0FBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBRW5GLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUM5QixPQUFPLE1BQU0sQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUNwRTs7Ozs7OztnQkFFRCxTQUFTLG1DQUFtQyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSzs7d0JBQzNELFVBQVUsR0FBRyx3QkFBd0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7b0JBQzFFakIsV0FBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLElBQUk7d0JBQzdCLElBQUksSUFBSSxFQUFFOzRCQUNSLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUNoRDtxQkFDRixDQUFDLENBQUM7b0JBQ0gsT0FBTyxVQUFVLENBQUM7aUJBQ25COzs7Ozs7O2dCQUVELFNBQVMsT0FBTyxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUUsT0FBTztvQkFDckMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQzFEOzs7Ozs7O2dCQUVELFNBQVMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxPQUFPOzt3QkFDeEMsTUFBTSxHQUFHLElBQUk7O3dCQUNiLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDOzt3QkFDckIsT0FBTyxHQUFHLElBQUl1QixvQkFBZSxDQUFDLElBQUksQ0FBQzs7d0JBQ3JDLFdBQVcsR0FBRyxFQUFFO29CQUNwQixXQUFXLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBRTFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzt5QkFDN0IsU0FBUyxDQUFDLFVBQVUsVUFBVTs7NEJBQ3ZCLFFBQVEsR0FBRywwQkFBMEIsQ0FBQyxNQUFNLENBQUM7d0JBQ25ELFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUM7d0JBQzNCLFdBQVcsR0FBRyxRQUFRLENBQUM7d0JBQ3ZCLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ3hCLEVBQUUsVUFBVSxRQUFRO3dCQUNuQixPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUN6QixFQUFFO3dCQUNELE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDcEIsQ0FBQyxDQUFDO29CQUVILE9BQU8sc0JBQXNCLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztpQkFDM0Q7Ozs7Ozs7Ozs7Z0JBRUQsU0FBUyxhQUFhLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxPQUFPOzt3QkFDckUsSUFBSSxHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7d0JBQ3ZGLElBQUksR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7b0JBQ3pDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTt3QkFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7cUJBQzVDO29CQUNELE9BQU8sSUFBSSxDQUFDO2lCQUNiOzs7Ozs7O2dCQUVELFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTzs7d0JBQ3ZDLE1BQU0sR0FBRyxJQUFJOzt3QkFDYixPQUFPLEdBQUcsSUFBSUEsb0JBQWUsQ0FBQyxJQUFJLENBQUM7O3dCQUNuQyxTQUFTLEdBQUcsU0FBUzs7d0JBQ3JCLEdBQUcsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7O3dCQUNyQyxXQUFXLEdBQUcsSUFBSSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDOzt3QkFFNUQsT0FBTyxHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUMzRCxXQUFXLEVBQUUsR0FBRyxFQUFFLE9BQU8sSUFBSSxFQUFFLEVBQUUsU0FBUyxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs7d0JBRWhHLFdBQVcsR0FBRyxFQUFFO29CQUNwQixXQUFXLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQzs7d0JBRXhFLE1BQU0sR0FBRyxTQUFTO29CQUV0QixJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUU7d0JBQ2hCLE1BQU0sR0FBRyxPQUFPLENBQUM7cUJBQ2xCOzt3QkFFSyxVQUFVLEdBQUcsVUFBVSxRQUFROzs0QkFDN0IsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJOzs0QkFDdkIsVUFBVSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTTs7NEJBQ3JDLElBQUksR0FBRyxhQUFhLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUM7O3dCQUdqRixJQUFJMUIsa0JBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssSUFBSSxFQUFFOzRCQUNwQyxJQUFJLEdBQUcsRUFBRSxDQUFDO3lCQUNYO3dCQUNELElBQUksQ0FBQ2hCLGNBQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTs0QkFDbEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2RUFBNkUsQ0FBQyxDQUFDO3lCQUNoRzt3QkFFRCxJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsY0FBYyxFQUFFOzRCQUNsQyxPQUFPLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQzt5QkFDN0Q7OzRCQUVHLGFBQWEsR0FBR1EsVUFBRyxDQUFDLElBQUksRUFBRSxVQUFVLElBQUk7NEJBQzFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLEVBQUU7Z0NBQzNELE9BQU8sa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDOzZCQUMzRDtpQ0FBTTtnQ0FDTCxPQUFPLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEVBQ3ZFLElBQUksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzs2QkFDN0Q7eUJBQ0YsQ0FBQzt3QkFFRixhQUFhLEdBQUdZLGFBQU0sQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7d0JBRTVDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLEVBQUU7NEJBQzNELGNBQWMsQ0FDWixPQUFPLEVBQ1AsUUFBUSxFQUNSLHdCQUF3QixDQUN0QixNQUFNLEVBQ04sYUFBYSxFQUNiLElBQUksRUFDSixJQUFJLEVBQ0osVUFBVSxDQUNYLEVBQ0QsV0FBVyxDQUNaLENBQUM7eUJBQ0g7NkJBQU07NEJBQ0wsY0FBYyxDQUNaLE9BQU8sRUFDUCxRQUFRLEVBQ1Isd0JBQXdCLENBQ3RCLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEVBQy9DLGFBQWEsRUFDYixNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUN0QyxJQUFJLEVBQ0osVUFBVSxDQUNYLEVBQ0QsV0FBVyxDQUNaLENBQUM7eUJBQ0g7cUJBQ0Y7b0JBRUQsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksRUFDeEYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTt5QkFDMUQsU0FBUyxDQUFDLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxRQUFRO3dCQUM1QyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssR0FBRyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsRUFBRTs0QkFDckYsY0FBYyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDO3lCQUN4RDs2QkFBTSxJQUFJdUIsWUFBSyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRSxVQUFVLEVBQU87NEJBRTFELE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLEtBQUssS0FBSyxDQUFDO3lCQUNwRCxDQUFDLEVBQUU7OzRCQUVGLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7eUJBQ3pCO3FCQUNGLENBQUMsQ0FBQztvQkFFSCxPQUFPLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7aUJBQzNEOzs7OztnQkFFRCxTQUFTLGNBQWMsQ0FBQyxVQUFVO29CQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxHQUFHLFVBQVUsQ0FBQztvQkFDdkQsT0FBTyxJQUFJLENBQUM7aUJBQ2I7Ozs7OztnQkFFRCxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTztvQkFDM0IsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxFQUFFO3dCQUM3QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO3FCQUM1RDt5QkFBTTt3QkFDTCxPQUFPUCxXQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztxQkFDaEY7aUJBQ0Y7Ozs7Ozs7OztnQkFFRCxTQUFTLFlBQVksQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsT0FBTzs7d0JBQ25ELE1BQU0sR0FBRyxJQUFJOzt3QkFDYixPQUFPLEdBQUcsSUFBSU0sb0JBQWUsQ0FBQyxJQUFJLENBQUM7O3dCQUNuQyxTQUFTLEdBQUcsTUFBTSxJQUFJLEVBQUU7O3dCQUN4QixLQUFLLEdBQUcsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDOzt3QkFDcEQsUUFBUSxHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzs7d0JBRTVDLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSTs7O3dCQUVuQixJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO29CQUUxSCxJQUFJWCxlQUFRLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxFQUFFO3dCQUMxRCxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ3JDOzt3QkFDSyxPQUFPLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUMzQyxPQUFPLEVBQ1AsU0FBUyxFQUNULEtBQUssRUFDTCxRQUFRLEVBQ1IsT0FBTyxJQUFJLEVBQUUsRUFDYixTQUFTLElBQUksRUFBRSxFQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUNoRDs7d0JBRUcsWUFBWSxHQUFHLEVBQUU7b0JBQ3JCLFlBQVksR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDOzt3QkFFbkUsVUFBVSxHQUFHLFVBQVUsUUFBUTs7NEJBQzdCLE9BQU8sR0FBR2EsVUFBRyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7OzRCQUMvQixVQUFVLEdBQUdBLFVBQUcsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDOzs0QkFFM0MsSUFBSSxHQUFHLGFBQWEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzt3QkFFbEYsSUFBSSxJQUFJLEVBQUU7O2dDQUNKLElBQUksU0FBQTs0QkFDUixJQUFJLElBQUksS0FBSyxNQUFNLENBQUMsY0FBYyxFQUFFO2dDQUNsQyxPQUFPLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQzs2QkFDOUQ7NEJBRUQsSUFBSSxTQUFTLEtBQUssTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO2dDQUNuRixJQUFJLEdBQUcsa0JBQWtCLENBQ3ZCLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEVBQy9DLElBQUksRUFDSixLQUFLLEVBQ0wsSUFBSSxFQUNKLElBQUksRUFDSixVQUFVLENBQ1gsQ0FBQztnQ0FDRixjQUFjLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7NkJBQ3ZEO2lDQUFNO2dDQUNMLElBQUksR0FBRyxrQkFBa0IsQ0FDdkIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsRUFDL0MsSUFBSSxFQUNKLE1BQU0sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLEVBQ3RDLElBQUksRUFDSixJQUFJLEVBQ0osVUFBVSxDQUNYLENBQUM7Z0NBRUYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO2dDQUN0RixjQUFjLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7NkJBQ3ZEO3lCQUVGOzZCQUFNOzRCQUNMLGNBQWMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQzt5QkFDNUQ7cUJBQ0Y7O3dCQUVLLGFBQWEsR0FBRyxVQUFVLFFBQVE7d0JBQ3RDLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTs0QkFDdkQsY0FBYyxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO3lCQUN6RDs2QkFBTSxJQUFJRCxZQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLFVBQVUsRUFBTzs0QkFDMUQsT0FBTyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUMsS0FBSyxLQUFLLENBQUM7eUJBQ3BELENBQUMsRUFBRTs7NEJBRUYsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDekI7cUJBQ0Y7Ozt3QkFFRyxhQUFhLEdBQUcsU0FBUzs7d0JBQ3pCLFdBQVcsR0FBR3ZCLGFBQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQzs7d0JBQ3ZDLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLENBQUM7b0JBQy9ELElBQUksbUJBQW1CLEVBQUU7d0JBQ3ZCLGFBQWEsR0FBRyxNQUFNLENBQUM7d0JBQ3ZCLFdBQVcsR0FBR0EsYUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFDLHdCQUF3QixFQUFFLFNBQVMsS0FBSyxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsQ0FBQyxXQUFXLEVBQUUsRUFBQyxDQUFDLENBQUM7cUJBQzVIO3lCQUFNLElBQUksTUFBTSxDQUFDLEtBQUssSUFBSSxhQUFhLEtBQUssS0FBSyxFQUFFO3dCQUNsRCxhQUFhLEdBQUcsT0FBTyxDQUFDO3FCQUN6QjtvQkFFRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQzVCLElBQUksbUJBQW1CLEVBQUU7NEJBQ3ZCLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUM5RSxJQUFJLEVBQUUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsYUFBYSxDQUFDLENBQUM7eUJBQ3RGOzZCQUFNOzRCQUNMLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUM5RSxJQUFJLEVBQUUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQzt5QkFDcEY7cUJBQ0Y7eUJBQU07d0JBQ0wsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQzlFLElBQUksRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsYUFBYSxDQUFDLENBQUM7cUJBQ25HO29CQUVELE9BQU8sc0JBQXNCLENBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztpQkFDN0Q7Ozs7OztnQkFFRCxTQUFTLFdBQVcsQ0FBQyxNQUFNLEVBQUUsT0FBTztvQkFDbEMsT0FBT2dCLFdBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRTs7Ozs7O2dCQUVELFNBQVMsY0FBYyxDQUFDLE1BQU0sRUFBRSxPQUFPO29CQUNyQyxPQUFPQSxXQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDbEY7Ozs7OztnQkFFRCxTQUFTLFdBQVcsQ0FBQyxNQUFNLEVBQUUsT0FBTztvQkFDbEMsT0FBT0EsV0FBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQy9FOzs7Ozs7OztnQkFFRCxTQUFTLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPO29CQUMvQyxPQUFPQSxXQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDdEU7Ozs7OztnQkFFRCxTQUFTLFlBQVksQ0FBQyxNQUFNLEVBQUUsT0FBTztvQkFDbkMsT0FBT0EsV0FBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ2hGOzs7Ozs7Z0JBRUQsU0FBUyxhQUFhLENBQUMsTUFBTSxFQUFFLE9BQU87b0JBQ3BDLE9BQU9BLFdBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNqRjs7Ozs7O2dCQUVELFNBQVMsZUFBZSxDQUFDLE1BQU0sRUFBRSxPQUFPO29CQUN0QyxPQUFPQSxXQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDbkY7Ozs7Ozs7Z0JBRUQsU0FBUyxhQUFhLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPO29CQUMxQyxPQUFPQSxXQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDNUU7Ozs7Ozs7OztnQkFFRCxTQUFTLGNBQWMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTtvQkFDNUQsT0FBT0EsV0FBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7aUJBQ3pFOzs7Ozs7Ozs7O2dCQUVELFNBQVMsNEJBQTRCLENBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLGNBQWMsRUFBRSxXQUFXOzt3QkFDakcsY0FBYztvQkFDbEIsSUFBSSxTQUFTLEtBQUssU0FBUyxFQUFFO3dCQUMzQixjQUFjLEdBQUdBLFdBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNsRDt5QkFBTTt3QkFDTCxjQUFjLEdBQUdBLFdBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztxQkFDOUQ7O3dCQUVLLGVBQWUsR0FBRyxVQUFVLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSTs7NEJBQy9DLFVBQVUsR0FBR2xCLGVBQVEsQ0FBQzs0QkFDMUIsTUFBTSxFQUFFLE1BQU07NEJBQ2QsT0FBTyxFQUFFLE9BQU87NEJBQ2hCLElBQUksRUFBRSxJQUFJO3lCQUNYLEVBQUU7NEJBQ0QsTUFBTSxFQUFFLGFBQWE7NEJBQ3JCLE9BQU8sRUFBRSxjQUFjOzRCQUN2QixJQUFJLEVBQUUsV0FBVzt5QkFDbEIsQ0FBQzt3QkFDRixPQUFPLGNBQWMsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUMvRTtvQkFFRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxlQUFlLENBQUM7cUJBQzlCO3lCQUFNO3dCQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxVQUFVLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTzs0QkFDMUMsT0FBTyxlQUFlLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzt5QkFDL0MsQ0FBQztxQkFDSDtpQkFDRjs7Ozs7Z0JBRUQsU0FBUyx5QkFBeUIsQ0FBQyxVQUFVOzt3QkFDckMsU0FBUyxHQUFHTyxZQUFLLENBQUNnQixXQUFJLENBQUMsTUFBTSxFQUFFLGVBQWUsQ0FBQyxDQUFDO29CQUN0RCxxQkFBcUIsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzVDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDdEIsT0FBTyw2QkFBNkIsQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDakQ7Ozs7OztnQkFFRCxTQUFTLFNBQVMsQ0FBQyxLQUFLLEVBQUUsTUFBTTs7d0JBQ3hCLHNCQUFzQixHQUFHSCxhQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDOzt3QkFDekQsSUFBSSxHQUFRLEVBQUU7O3dCQUNkLFVBQVUsR0FBRyxDQUFDLE1BQU0sSUFBSSxPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQztvQkFDakQsSUFBSSxDQUFDLEdBQUcsR0FBR0YsV0FBSSxDQUFDLEdBQUcsR0FBRyxNQUFNLElBQUksT0FBTyxHQUFHLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDekQsSUFBSSxDQUFDLEdBQUcsR0FBR0EsV0FBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQyxJQUFJLEdBQUdBLFdBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUM5QyxJQUFJLENBQUMsT0FBTyxHQUFHQSxXQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDcEQsSUFBSSxDQUFDLGNBQWMsR0FBR0EsV0FBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQ2xFLElBQUksQ0FBQyxHQUFHLEdBQUdBLFdBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUU1QyxLQUFLLElBQU0sSUFBSSxJQUFJLFVBQVUsRUFBRTt3QkFDN0IsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJSixpQkFBVSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUNqQixlQUFRLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLEVBQUU7NEJBQzlHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBR3FCLFdBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7eUJBQ2pEO3FCQUNGO29CQUVELE9BQU8sSUFBSSxDQUFDO2lCQUNiO2dCQUVELHFCQUFxQixDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFFdkMsT0FBTyxDQUFDLElBQUksR0FBR0EsV0FBSSxDQUFDLDBCQUEwQixFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUV6RCxPQUFPLENBQUMsT0FBTyxHQUFHQSxXQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUUzQyxPQUFPLENBQUMsVUFBVSxHQUFHQSxXQUFJLENBQUMseUJBQXlCLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBRTlELE9BQU8sQ0FBQyxHQUFHLEdBQUdBLFdBQUksQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUV2QyxPQUFPLENBQUMsR0FBRyxHQUFHQSxXQUFJLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFdkMsT0FBTyxDQUFDLE9BQU8sR0FBR0EsV0FBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBRS9DLE9BQU8sQ0FBQyxNQUFNLEdBQUdBLFdBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUU3QyxPQUFPLENBQUMsTUFBTSxHQUFHQSxXQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFN0MsT0FBTyxDQUFDLGdCQUFnQixHQUFHQSxXQUFJLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBRTNELE9BQU8sQ0FBQyxxQkFBcUIsR0FBR0EsV0FBSSxDQUFDLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUVsRSxPQUFPLENBQUMsd0JBQXdCLEdBQUdBLFdBQUksQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFFdEYsT0FBTyxPQUFPLENBQUM7YUFDaEI7WUFFRCxPQUFPLDZCQUE2QixDQUFDLG1CQUFtQixDQUFDLENBQUM7U0FDM0Q7SUFFSCxDQUFDOzs7Ozs7QUM5dUJEO0FBTUEsUUFBYSxVQUFVLEdBQUcsSUFBSXJDLG1CQUFjLENBQVMsV0FBVyxDQUFDO0FBRWpFO1FBTUUsMkJBQW9DLFlBQStCO1lBQ2pFLElBQUksWUFBWSxFQUFFO2dCQUNoQixNQUFNLElBQUksS0FBSyxDQUNiLHNFQUFzRSxDQUFDLENBQUM7YUFDM0U7U0FDRjs7Ozs7O1FBSU0seUJBQU87Ozs7O1lBQWQsVUFBZSxPQUFRLEVBQUUsT0FBUTtnQkFDL0IsT0FBTztvQkFDTCxRQUFRLEVBQUUsaUJBQWlCO29CQUMzQixTQUFTLEVBQUU7d0JBQ1QsRUFBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsRUFBQzt3QkFDbkQsRUFBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBQztxQkFDM0U7aUJBQ0YsQ0FBQzthQUNIOztvQkF2QkY4QyxhQUFRLFNBQUM7d0JBQ1IsT0FBTyxFQUFFLENBQUNDLHFCQUFnQixDQUFDO3dCQUMzQixTQUFTLEVBQUUsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDO3FCQUMxQzs7Ozs7d0JBR21ELGlCQUFpQix1QkFBdERiLGFBQVEsWUFBSWMsYUFBUTs7O1FBbUJuQyx3QkFBQztLQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsifQ==