module.exports = require('../../es/number/min-safe-integer');
