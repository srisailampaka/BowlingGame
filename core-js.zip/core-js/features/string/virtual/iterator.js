module.exports = require('../../../es/string/virtual/iterator');
