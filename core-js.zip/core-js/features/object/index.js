module.exports = require('../../es/object');
