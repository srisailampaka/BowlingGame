module.exports = require('../../es/instance/last-index-of');
