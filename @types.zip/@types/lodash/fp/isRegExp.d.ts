import { isRegExp } from "../fp";
export = isRegExp;
