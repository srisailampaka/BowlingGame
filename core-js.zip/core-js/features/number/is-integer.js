module.exports = require('../../es/number/is-integer');
