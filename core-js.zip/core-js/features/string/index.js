module.exports = require('../../es/string');

require('../../modules/esnext.string.at');
// TODO: remove from `core-js@4`
require('../../modules/esnext.string.match-all');
require('../../modules/esnext.string.replace-all');
