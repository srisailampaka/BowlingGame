module.exports = require('../../es/string/starts-with');
