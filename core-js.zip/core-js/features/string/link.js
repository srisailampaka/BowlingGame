module.exports = require('../../es/string/link');
