require('../../modules/es.typed-array.map');
