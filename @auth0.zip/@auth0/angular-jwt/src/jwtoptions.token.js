import { InjectionToken } from '@angular/core';
export var JWT_OPTIONS = new InjectionToken('JWT_OPTIONS');
