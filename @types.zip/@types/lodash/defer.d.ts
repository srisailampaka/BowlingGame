import { defer } from "./index";
export = defer;
