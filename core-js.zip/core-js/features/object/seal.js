module.exports = require('../../es/object/seal');
