import { findKey } from "../fp";
export = findKey;
