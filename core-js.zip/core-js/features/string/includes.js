module.exports = require('../../es/string/includes');
