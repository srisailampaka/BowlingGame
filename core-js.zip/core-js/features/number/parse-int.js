module.exports = require('../../es/number/parse-int');
