module.exports = require('../../es/promise/finally');
