module.exports = require('../../../es/string/virtual/pad-end');
