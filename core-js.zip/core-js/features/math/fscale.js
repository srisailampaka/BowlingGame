require('../../modules/esnext.math.fscale');
var path = require('../../internals/path');

module.exports = path.Math.fscale;
