module.exports = require('../../es/reflect/get-own-property-descriptor');
