module.exports = require('../../es/string/anchor');
