module.exports = require('../stable/set-immediate');
