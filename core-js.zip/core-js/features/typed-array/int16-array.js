module.exports = require('../../es/typed-array/int16-array');
