module.exports = require('../../es/function/has-instance');
