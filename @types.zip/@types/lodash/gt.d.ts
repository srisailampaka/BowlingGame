import { gt } from "./index";
export = gt;
