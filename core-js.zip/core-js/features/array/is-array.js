module.exports = require('../../es/array/is-array');
