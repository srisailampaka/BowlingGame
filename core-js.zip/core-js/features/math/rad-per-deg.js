require('../../modules/esnext.math.rad-per-deg');

module.exports = 180 / Math.PI;
