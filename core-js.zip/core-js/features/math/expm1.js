module.exports = require('../../es/math/expm1');
