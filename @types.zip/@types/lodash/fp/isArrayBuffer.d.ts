import { isArrayBuffer } from "../fp";
export = isArrayBuffer;
