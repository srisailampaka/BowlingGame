module.exports = require('../../es/array/flat-map');
