module.exports = require('../../es/number/to-precision');
