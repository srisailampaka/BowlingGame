module.exports = require('../../es/regexp/to-string');
