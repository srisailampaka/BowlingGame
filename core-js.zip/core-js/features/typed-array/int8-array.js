module.exports = require('../../es/typed-array/int8-array');
