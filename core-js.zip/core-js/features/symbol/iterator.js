module.exports = require('../../es/symbol/iterator');
