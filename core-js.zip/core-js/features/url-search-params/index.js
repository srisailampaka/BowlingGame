module.exports = require('../../stable/url-search-params');
